#!/usr/bin/env python3
"""Aggregate statement export includes period/date and Arabic-Indic monetary digits."""
from pathlib import Path
R=Path(__file__).resolve().parents[1]
S=(R/'app/src/main/java/com/example/rentals/features/printing/MonthlyCollectionScreen.kt').read_text(encoding='utf-8')
assert 'aggregateExportMoney(it.amount)' in S
assert "('٠'.code + (ch - '0')).toChar()" in S
assert 'فترة الكشف' in S and 'تاريخ الإصدار' in S
assert 'it.templateId' in S
assert 'it.templateId.ifBlank { "T001" }' not in S
print('PASS: aggregate Excel export includes period/date and Arabic-Indic formatted amounts')
