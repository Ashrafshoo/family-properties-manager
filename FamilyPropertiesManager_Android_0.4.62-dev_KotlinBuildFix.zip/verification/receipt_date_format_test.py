from pathlib import Path
root = Path(__file__).resolve().parents[1]
formatter = root / 'app/src/main/java/com/example/rentals/printing/ReceiptDateFormat.kt'
s = formatter.read_text(encoding='utf-8')
assert 'DateTimeFormatter.ofPattern("yyyy/MM/dd"' in s
assert "replace('/', '-')" in s
assert 'arabicDigits[index]' in s
screen = (root / 'app/src/main/java/com/example/rentals/features/printing/MonthlyCollectionScreen.kt').read_text(encoding='utf-8')
assert 'ReceiptDateFormat.toSheet(java.time.LocalDate.now().toString())' in screen
assert 'ReceiptDateFormat.toStorage(issuedDate)' in screen
assert 'ReceiptDateFormat.toStorage(date)' in screen
assert 'ReceiptDateFormat.toSheet(it.paidDate)' in screen
for rel in ('app/src/main/java/com/example/rentals/printing/ReceiptPdfExporter.kt',
            'app/src/main/java/com/example/rentals/printing/ReceiptPrintAdapter.kt'):
    assert 'ReceiptDateFormat.toSheet' in (root / rel).read_text(encoding='utf-8')
gradle = (root / 'app/build.gradle.kts').read_text(encoding='utf-8')
assert 'versionCode = 86' in gradle and 'versionName = "0.4.62-dev"' in gradle
print('PASS: source-sheet date order yyyy/MM/dd; zero-padded month/day; Arabic display digits; ISO storage; UI, PDF, print and Excel wiring; version increment.')
