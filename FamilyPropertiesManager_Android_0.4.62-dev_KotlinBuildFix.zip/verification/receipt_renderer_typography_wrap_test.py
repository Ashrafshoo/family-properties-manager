from pathlib import Path
p = Path("app/src/main/java/com/example/rentals/printing/OriginalReceiptTemplateRenderer.kt")
s = p.read_text(encoding="utf-8")
assert "setMaxLines(maxLines)" in s
assert "coerceAtMost(24)" in s
assert "BREAK_STRATEGY_HIGH_QUALITY" in s
assert "HYPHENATION_FREQUENCY_NONE" in s
assert "sourceFont.contains(\"calibri\")" in s
assert "sourceFont.contains(\"arial\")" in s
print("PASS: workbook font-family fallback and height-aware RTL wrapping")
