# تقرير إصلاح فشل بناء Android — 0.4.63-dev

## سبب الفشل المثبت من سجل GitHub Actions

فشل تشغيل Android Native Build رقم 60 في مهمة `Kotlin / Jetpack Compose debug APK` أثناء تجميع Kotlin، بينما نجحت مهمة اختبارات المصدر. الأخطاء الأربعة في:

`app/src/main/java/com/example/rentals/io/AggregateStatementWorkbookExporter.kt`

- السطر 101: `XMLConstants.ACCESS_EXTERNAL_DTD` غير معروف.
- السطر 102: `XMLConstants.ACCESS_EXTERNAL_SCHEMA` غير معروف.
- السطر 109: `XMLConstants.ACCESS_EXTERNAL_DTD` غير معروف.
- السطر 110: `XMLConstants.ACCESS_EXTERNAL_STYLESHEET` غير معروف.

## الإصلاح

استبدلت مراجع ثوابت `javax.xml.XMLConstants` بمفاتيح الخصائص القياسية النصية المطابقة لها، مع الإبقاء على خصائص منع DOCTYPE والكيانات الخارجية وتعطيل الوصول الخارجي. ما زالت محاولات تعيين الخصائص محاطة بـ`runCatching` لتوافق تطبيقات XML المختلفة على Android.

لم يتم تغيير منطق التصدير أو قالب Excel أو قاعدة البيانات أو بيانات المستأجرين أو حالة السداد.

## التحقق

- أضيف اختبار مصدر `verification/android_xml_api_compatibility_test.py` للتحقق من مفاتيح الخصائص وإبقاء إعدادات الحماية.
- يجب تشغيل مجموعة اختبارات المصدر كاملة، ثم إعادة بناء APK في GitHub Actions لإثبات نجاح Android Gradle Build. لا يُعد نجاح اختبارات المصدر وحده إثباتًا لنجاح APK.
