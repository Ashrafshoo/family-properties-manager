# تقرير بناء ومراجعة ٠٫٤٫٦٤-dev

## ما تم تعديله
1. إصلاح ربط أزرار الطباعة وPDF في الدفعات السريعة: أصبحت تستخدم `OriginalReceiptTemplateRenderer` عبر `AggregateReceiptPrintAdapter` و`AggregateReceiptPdfExporter`.
2. إصلاح ربط تصدير Excel للدفعات السريعة: أصبح يستخدم `AggregateStatementWorkbookExporter` والقالب الأصلي بدل جدول عادي.
3. إضافة اختيار قالب نوفمبر لكل مستأجر وحفظه على صف الدفعة نفسه.
4. ترحيل SQLite من الإصدار ١٨ إلى ١٩ بإضافة `template_id` إلى `monthly_collection_items` بقيمة افتراضية فارغة. لم تُنشأ أي سجلات سداد أو قيود دفتر أستاذ، ولم تُعدّل السجلات السابقة.
5. منع الطباعة/PDF إذا لم يُحدد قالب صحيح أو كان مبلغ الإيجار غير معروف.
6. تحديث مسارات تشغيل CI لتشمل أصول التطبيق وموارده، وتحديث اسم Artifact.

## اختبارات منفذة وناجحة
- `quick_batch_original_template_wiring_test.py`
- `monthly_batch_template_migration_test.py` — اختبار SQLite فعلي يحاكي الترحيل ويحفظ الصفوف والملاحظات القديمة.
- `aggregate_receipt_statements_test.py`
- `collection_eligibility_parity_test.py`
- `entity_management_source_test.py`
- `aggregate_receipt_pdf_integrity_test.py`
- `receipt_renderer_template_safety_test.py` — فحص ٨٨ قالبًا، منها ٨١ قالبًا شهريًا.
- `receipt_overlay_font_fallback_test.py`
- `receipt_overlay_arabic_digits_test.py`
- `android_xml_api_compatibility_test.py`
- `receipt_pdf_integrity_test.py`
- `python -m compileall -q verification`

## ما لم يمكن إثباته في هذه البيئة
- لا يوجد Gradle executable أو Android SDK أو Android Gradle Wrapper في بيئة العمل؛ لذلك لم ينفذ `./gradlew assembleDebug` ولم ينتج APK.
- لم يتم تشغيل GitHub Actions من هنا، ولم يتم اختبار الترقية على نسخة قاعدة بيانات حية أو تجربة الطابعة الفعلية.
- يجب تشغيل Workflow بعد رفع المصدر، ثم تثبيت APK واختبار الترحيل والطباعة على الهاتف قبل اعتماد النسخة نهائيًا.

## حماية البيانات
- لا حذف أو استبدال لقاعدة البيانات.
- الترحيل يضيف عمودًا واحدًا فقط مع قيمة افتراضية فارغة للصفوف الموجودة.
- لا توجد كتابة إلى جدول `receipts` أو `ledger` من اختيار القالب أو الطباعة أو التصدير.
