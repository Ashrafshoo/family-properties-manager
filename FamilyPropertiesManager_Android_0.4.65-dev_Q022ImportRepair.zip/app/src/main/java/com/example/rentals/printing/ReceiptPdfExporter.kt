package com.example.rentals.printing

import android.content.ContentResolver
import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import android.net.Uri
import androidx.core.content.res.ResourcesCompat
import com.example.rentals.R
import com.example.rentals.data.ReceiptRecord
import java.util.Locale

/** Creates a standalone PDF containing the same original receipt artwork used by Android printing. */
object ReceiptPdfExporter {
    fun export(context: Context, resolver: ContentResolver, uri: Uri, receipts: List<ReceiptRecord>, perPage: Int = 3, marginMm: Float = 5f, oldLawTemplate: Boolean = true) {
        require(receipts.isNotEmpty()) { "لا توجد إيصالات في هذه الدفعة" }
        val count = perPage.coerceIn(1, 3)
        val document = PdfDocument()
        val bitmaps = mutableMapOf<Int, android.graphics.Bitmap>()
        val arabicTypeface = ResourcesCompat.getFont(context, R.font.noto_sans_arabic_regular) ?: Typeface.DEFAULT
        try {
            val pages = (receipts.size + count - 1) / count
            for (pageNo in 0 until pages) {
                val page = document.startPage(PdfDocument.PageInfo.Builder(595, 842, pageNo + 1).create())
                val margin = marginMm * 2.8346f
                val gap = 5f
                val slotHeight = (842f - 2f * margin - (count - 1) * gap) / count
                for (slot in 0 until count) {
                    val index = pageNo * count + slot
                    if (index >= receipts.size) break
                    val receipt = receipts[index]
                    val suffix = (slot + 1).coerceIn(1, 3)
                    val name = "receipt_${if (oldLawTemplate) "old" else "new"}_$suffix"
                    val drawableId = context.resources.getIdentifier(name, "drawable", context.packageName)
                    require(drawableId != 0) { "قالب الإيصال غير موجود: $name" }
                    val bitmap = bitmaps.getOrPut(slot) { BitmapFactory.decodeResource(context.resources, drawableId) ?: error("تعذر تحميل قالب الإيصال: $name") }
                    val rect = RectF(margin, margin + slot * (slotHeight + gap), 595f - margin, margin + slot * (slotHeight + gap) + slotHeight)
                    page.canvas.drawBitmap(bitmap, null, rect, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
                    drawRtl(arabicTypeface, page.canvas, receipt.amount?.let { ReceiptDateFormat.toArabicDigits(String.format(Locale.US, "%.2f", it)) }.orEmpty(), rect.left + rect.width()*.62f, rect.top+rect.height()*.205f, rect.width()*.16f, 12f, true)
                    drawRtl(arabicTypeface, page.canvas, ReceiptDateFormat.toArabicDigits(receipt.tenant), rect.right-rect.width()*.10f, rect.top+rect.height()*.315f, rect.width()*.80f, 11f, false)
                    drawRtl(arabicTypeface, page.canvas, ReceiptDateFormat.toArabicDigits("${receipt.property} • ${ReceiptDateFormat.toSheet(receipt.paidDate)}"), rect.right-rect.width()*.12f, rect.top+rect.height()*.505f, rect.width()*.53f, 9f, false)
                    val description = listOf("إيصال ${receipt.receiptNo}", "عن فترة ${receipt.period}", receipt.unitCode).filter { it.isNotBlank() }.joinToString(" – ")
                    drawRtl(arabicTypeface, page.canvas, ReceiptDateFormat.toArabicDigits(description), rect.right-rect.width()*.12f, rect.top+rect.height()*.585f, rect.width()*.58f, 9f, false)
                }
                document.finishPage(page)
            }
            resolver.openOutputStream(uri, "w")?.use { document.writeTo(it) } ?: error("تعذر فتح ملف PDF للحفظ")
        } finally {
            document.close()
            bitmaps.values.forEach { it.recycle() }
        }
        // A document provider may return a URI even when the saved payload is
        // empty or incomplete. Re-open the file and verify the PDF signature.
        val input = resolver.openInputStream(uri) ?: error("تعذر التحقق من ملف PDF بعد الحفظ")
        input.use { stream ->
            val header = ByteArray(5)
            var headerRead = 0
            while (headerRead < header.size) {
                val read = stream.read(header, headerRead, header.size - headerRead)
                if (read < 0) break
                headerRead += read
            }
            require(headerRead == 5 && String(header, Charsets.US_ASCII) == "%PDF-") { "الملف الناتج ليس مستند PDF صالحًا" }
            var total = headerRead.toLong()
            val buffer = ByteArray(8192)
            while (true) {
                val read = stream.read(buffer)
                if (read < 0) break
                total += read
            }
            require(total >= 512L) { "ملف PDF الناتج فارغ أو غير مكتمل" }
        }
    }

    private fun drawRtl(arabicTypeface: Typeface, canvas: Canvas, text: String, right: Float, top: Float, width: Float, size: Float, bold: Boolean) {
        if (text.isBlank()) return
        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xff111111.toInt(); textSize = size
            typeface = Typeface.create(arabicTypeface, if (bold) Typeface.BOLD else Typeface.NORMAL)
        }
        val safe = text.take(100)
        val layout = StaticLayout.Builder.obtain(safe, 0, safe.length, paint, width.toInt().coerceAtLeast(40))
            .setAlignment(Layout.Alignment.ALIGN_OPPOSITE).setTextDirection(TextDirectionHeuristics.RTL)
            .setIncludePad(false).setMaxLines(2).build()
        canvas.save(); canvas.translate(right-width, top); layout.draw(canvas); canvas.restore()
    }
}
