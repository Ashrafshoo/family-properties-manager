package com.example.rentals

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.SideEffect
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.fragment.app.FragmentActivity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import android.print.PrintAttributes
import android.print.PrintManager
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import android.provider.OpenableColumns
import java.io.File
import java.util.UUID
import com.example.rentals.backup.BackupManager
import com.example.rentals.backup.DatabaseTransfer
import com.example.rentals.backup.EncryptedBackup
import com.example.rentals.data.RentalsDb
import com.example.rentals.data.repository.SqliteUnitRepository
import com.example.rentals.data.repository.SqliteEntityRepository
import com.example.rentals.data.repository.SqliteFinanceRepository
import com.example.rentals.data.repository.SqliteContractRepository
import com.example.rentals.domain.contracts.ContractRepository
import com.example.rentals.domain.entities.EntityRepository
import com.example.rentals.data.repository.FinanceRepository
import com.example.rentals.data.repository.UnitRepository
import com.example.rentals.data.repository.toDashboardSnapshot
import com.example.rentals.data.LegacyUnitReviewAnalyzer
import com.example.rentals.data.LegacyReceiptMatchAnalyzer
import com.example.rentals.data.UnitRecord
import com.example.rentals.data.ReceiptRecord
import com.example.rentals.data.PropertyRecord
import com.example.rentals.data.TenantRecord
import com.example.rentals.io.XlsxManager
import com.example.rentals.io.WorkbookExporter
import com.example.rentals.io.WorkbookImporter
import com.example.rentals.printing.DatabasePdfExporter
import com.example.rentals.printing.ReceiptPrintAdapter
import com.example.rentals.security.AppSecurity
import com.example.rentals.ui.SettingsStore
import com.example.rentals.ui.components.AppField
import com.example.rentals.ui.components.MetricCard
import com.example.rentals.ui.components.BrandTopBar
import com.example.rentals.ui.components.SettingSwitchRow
import com.example.rentals.navigation.AppTab
import com.example.rentals.design.appColorScheme
import com.example.rentals.design.appTypography
import com.example.rentals.features.settings.SettingsScreen
import com.example.rentals.features.entities.EntityManagementScreen
import com.example.rentals.features.contracts.ContractsArchiveScreen
import com.example.rentals.features.review.ReviewScreen
import com.example.rentals.features.finance.FinanceScreen
import com.example.rentals.features.printing.MonthlyCollectionScreen
import com.example.rentals.data.repository.SqliteMonthlyCollectionRepository
import com.example.rentals.features.personal.PersonalRentNotebook
import com.example.rentals.features.units.UnitsScreen
import com.example.rentals.features.dashboard.Dashboard
import com.example.rentals.ui.UiSettings
import java.text.NumberFormat
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); window.statusBarColor=android.graphics.Color.rgb(244,247,248); setContent { RentalsRoot(this) } }
}

@Composable private fun RentalsRoot(activity:FragmentActivity){
    val context= LocalContext.current
    val db= remember { RentalsDb.get(context) }
    val unitRepository = remember(db) { SqliteUnitRepository(db) }
    val entityRepository = remember(db) { SqliteEntityRepository(db) }
    val financeRepository = remember(db) { SqliteFinanceRepository(db) }
    val contractRepository = remember(db) { SqliteContractRepository(db) }
    val monthlyCollectionRepository = remember(db) { SqliteMonthlyCollectionRepository(db) }
    val security= remember { AppSecurity(context) }
    val store= remember { SettingsStore(context) }
    var settings by remember { mutableStateOf(store.read()) }
    var unlocked by remember { mutableStateOf(!security.hasPin()) }
    // Android document pickers temporarily move this activity to the background.
    // Keep the session alive until the picker returns; otherwise ON_STOP hides and
    // discards the import confirmation state before the Activity Result is handled.
    var externalPickerInProgress by remember { mutableStateOf(false) }
    val pickerInProgressState = rememberUpdatedState(externalPickerInProgress)
    DisposableEffect(activity, settings.lockOnBackground, security.hasPin()) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP && !pickerInProgressState.value && settings.lockOnBackground && security.hasPin()) unlocked = false
        }
        activity.lifecycle.addObserver(observer)
        onDispose { activity.lifecycle.removeObserver(observer) }
    }
    var refresh by remember { mutableIntStateOf(0) }
    var units by remember { mutableStateOf<List<UnitRecord>>(emptyList()) }
    var unitsLoading by remember { mutableStateOf(true) }
    LaunchedEffect(unitRepository, refresh) {
        unitsLoading = true
        try { units = withContext(Dispatchers.IO) { unitRepository.getAll() } }
        finally { unitsLoading = false }
    }
    SideEffect {
        activity.window.statusBarColor = if (settings.dark) android.graphics.Color.rgb(13, 23, 34) else android.graphics.Color.rgb(243, 246, 249)
        activity.window.navigationBarColor = if (settings.dark) android.graphics.Color.rgb(13, 23, 34) else android.graphics.Color.rgb(243, 246, 249)
        @Suppress("DEPRECATION")
        run { activity.window.decorView.systemUiVisibility = if (settings.dark) 0 else android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR }
    }
    val baseDensity = LocalDensity.current
    CompositionLocalProvider(
      LocalLayoutDirection provides LayoutDirection.Rtl,
      LocalDensity provides Density(baseDensity.density, (baseDensity.fontScale * settings.fontScale).coerceIn(0.5f, 2.0f))
    ) {
      MaterialTheme(colorScheme=appColorScheme(settings),typography=appTypography(settings, Typography()),content={
        if(!unlocked){LockScreen(security,activity,onUnlock={unlocked=true})}
        else if(!security.hasPin()){PinSetup(security,onDone={unlocked=true})}
        else {
    if (unitsLoading) LinearProgressIndicator(Modifier.fillMaxWidth())
    MainShell(
        activity,
        db,
        unitRepository,
        entityRepository,
        financeRepository,
        contractRepository,
        monthlyCollectionRepository,
        units,
        settings,
        onSettings = { settings = it; store.save(it) },
        onRefresh = { refresh++ },
        setExternalPickerInProgress = { externalPickerInProgress = it }
    )
}      })
    }
}

@Composable private fun LockScreen(sec:AppSecurity,activity:FragmentActivity,onUnlock:()->Unit){
    var pin by remember{mutableStateOf("")};var error by remember{mutableStateOf("")};var checking by remember{mutableStateOf(false)}
    val ctx= LocalContext.current;val scope= rememberCoroutineScope()
    Column(Modifier.fillMaxSize().padding(28.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){
        Icon(Icons.Default.Lock,null,tint=MaterialTheme.colorScheme.primary,modifier=Modifier.size(56.dp));Text("أملاك العائلة",fontSize=23.sp,fontWeight=FontWeight.Bold);Text("أدخل رمز الدخول لفتح بياناتك",color=MaterialTheme.colorScheme.onSurfaceVariant);Spacer(Modifier.height(22.dp))
        OutlinedTextField(pin,{pin=it.filter(Char::isDigit).take(8)},label={Text("رمز الدخول")},visualTransformation=PasswordVisualTransformation(),keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.NumberPassword),singleLine=true,enabled=!checking)
        if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)
        Button(enabled=!checking && pin.isNotEmpty(),onClick={checking=true;error="";scope.launch{val valid=withContext(Dispatchers.Default){runCatching{sec.verifyPin(pin)}.getOrDefault(false)};checking=false;if(valid)onUnlock()else error="رمز الدخول غير صحيح"}},modifier=Modifier.fillMaxWidth()){if(checking)CircularProgressIndicator(Modifier.size(18.dp),strokeWidth=2.dp)else Text("فتح التطبيق")}
        if(sec.biometricEnabled()&&sec.biometricAvailable(ctx)){OutlinedButton(enabled=!checking,onClick={sec.prompt(activity,onUnlock,{error=it})},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.Fingerprint,null);Text("  استخدام البصمة")}}
    }
}
@Composable private fun PinSetup(sec:AppSecurity,onDone:()->Unit){
    var pin by remember{mutableStateOf("")};var confirm by remember{mutableStateOf("")};var error by remember{mutableStateOf("")};var saving by remember{mutableStateOf(false)}
    val scope= rememberCoroutineScope()
    Column(Modifier.fillMaxSize().padding(24.dp),verticalArrangement=Arrangement.Center,horizontalAlignment=Alignment.CenterHorizontally){
        Icon(Icons.Default.Security,null,modifier=Modifier.size(54.dp),tint=MaterialTheme.colorScheme.primary);Text("إنشاء رمز الدخول",fontSize=24.sp,fontWeight=FontWeight.Bold);Text("يُستخدم لحماية فتح التطبيق على هذا الهاتف.")
        OutlinedTextField(pin,{pin=it.filter(Char::isDigit).take(8)},label={Text("رمز جديد – 4 أرقام على الأقل")},visualTransformation=PasswordVisualTransformation(),keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.NumberPassword),enabled=!saving,singleLine=true)
        OutlinedTextField(confirm,{confirm=it.filter(Char::isDigit).take(8)},label={Text("تأكيد الرمز")},visualTransformation=PasswordVisualTransformation(),keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.NumberPassword),enabled=!saving,singleLine=true)
        if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)
        Button(enabled=!saving,onClick={
            when { pin.length<4->error="الرمز قصير جدًا";pin!=confirm->error="الرمزان غير متطابقين";else->{saving=true;error="";scope.launch{
                val result=withContext(Dispatchers.Default){runCatching{sec.setPin(pin)}}
                result.onSuccess{onDone()}.onFailure{error="تعذر حفظ رمز الدخول: ${it.message?:"خطأ غير معروف"}";saving=false}
            }}
        }},modifier=Modifier.fillMaxWidth()) {if(saving){CircularProgressIndicator(Modifier.size(18.dp),strokeWidth=2.dp);Text(" جارٍ حفظ الرمز...")}else Text("حفظ وبدء الاستخدام")}
    }
}

typealias Tab = AppTab
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MainShell(
    activity: FragmentActivity,
    db: RentalsDb,
    unitRepository: UnitRepository,
    entityRepository: EntityRepository,
    financeRepository: FinanceRepository,
    contractRepository: ContractRepository,
    monthlyCollectionRepository: com.example.rentals.domain.collection.MonthlyCollectionRepository,
    initial: List<UnitRecord>,
    settings: UiSettings,
    onSettings: (UiSettings) -> Unit,
    onRefresh: () -> Unit,
    setExternalPickerInProgress: (Boolean) -> Unit
) {
    var tab by rememberSaveable { mutableStateOf(Tab.Home) }
    var units by remember { mutableStateOf(initial) }
    var moreExpanded by rememberSaveable { mutableStateOf(false) }
    var confirmExit by remember { mutableStateOf(false) }
    var importSummary by remember { mutableStateOf("") }
    val menuState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    LaunchedEffect(tab) { units = unitRepository.getAll() }

    BackHandler(enabled = true) {
        when {
            moreExpanded -> moreExpanded = false
            tab != Tab.Home -> tab = Tab.Home
            else -> confirmExit = true
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = { BrandTopBar(onBack = { if (moreExpanded) moreExpanded = false else if (tab != Tab.Home) tab = Tab.Home else confirmExit = true }, onRefresh = { units = unitRepository.getAll(); onRefresh() }) },
        bottomBar = {
            NavigationBar(
                containerColor = Color(0xFF071B3B),
                contentColor = Color.White,
                tonalElevation = 12.dp,
                windowInsets = NavigationBarDefaults.windowInsets
            ) {
                listOf(Tab.Home, Tab.Units, Tab.Print, Tab.Personal).forEach { destination ->
                    NavigationBarItem(
                        selected = tab == destination,
                        onClick = { tab = destination },
                        icon = { Icon(destination.icon, contentDescription = destination.label) },
                        label = { Text(destination.label, maxLines = 1, softWrap = false, fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFFFFD36A),
                            selectedTextColor = Color(0xFFFFD36A),
                            unselectedIconColor = Color(0xFFCFD8E5),
                            unselectedTextColor = Color(0xFFCFD8E5),
                            indicatorColor = Color(0xFF294363)
                        )
                    )
                }
                NavigationBarItem(
                    selected = moreExpanded || tab in listOf(Tab.Finance, Tab.Review, Tab.Contracts, Tab.Entities, Tab.Settings),
                    onClick = { moreExpanded = true },
                    icon = { Icon(Icons.Default.MoreHoriz, contentDescription = "كل الأقسام") },
                    label = { Text("المزيد", maxLines = 1, softWrap = false, fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFFFFD36A), selectedTextColor = Color(0xFFFFD36A),
                        unselectedIconColor = Color(0xFFCFD8E5), unselectedTextColor = Color(0xFFCFD8E5),
                        indicatorColor = Color(0xFF294363)
                    )
                )
            }
        }
    ) { pad ->
        Box(Modifier.fillMaxSize().padding(pad)) {
            when (tab) {
                Tab.Home->Dashboard(units.map { it.toDashboardSnapshot() }){tab=it}
                Tab.Units->UnitsScreen(activity,db,units,settings.compact,{units=unitRepository.getAll();onRefresh()})
                Tab.Finance->FinanceScreen(financeRepository)
                Tab.Print->MonthlyCollectionScreen(activity,monthlyCollectionRepository,units,settings,setExternalPickerInProgress)
                Tab.Personal->PersonalRentNotebook(db)
                Tab.Review->ReviewScreen(db,units)
                Tab.Contracts->ContractsArchiveScreen(activity,contractRepository,units)
                Tab.Entities->EntityManagementScreen(entityRepository)
                Tab.Settings->SettingsScreen(activity,db,settings,onSettings,{units=unitRepository.getAll();onRefresh()},{summary->importSummary=summary;tab=Tab.Units;units=unitRepository.getAll();onRefresh()},setExternalPickerInProgress)
            }
            if (importSummary.isNotBlank()) {
                Card(Modifier.align(Alignment.TopCenter).fillMaxWidth().padding(10.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(importSummary, Modifier.weight(1f), color = MaterialTheme.colorScheme.onPrimaryContainer, fontSize = 12.sp)
                        TextButton(onClick = { importSummary = "" }) { Text("إغلاق") }
                    }
                }
            }
        }
    }

    if (confirmExit) {
        AlertDialog(
            onDismissRequest = { confirmExit = false },
            title = { Text("الخروج من التطبيق") },
            text = { Text("هل تريد إغلاق تطبيق أملاك العائلة؟ بياناتك المحفوظة لن تتأثر.") },
            confirmButton = { TextButton(onClick = { confirmExit = false; activity.finish() }) { Text("خروج") } },
            dismissButton = { TextButton(onClick = { confirmExit = false }) { Text("البقاء في التطبيق") } }
        )
    }

    if (moreExpanded) {
        ModalBottomSheet(
            onDismissRequest = { moreExpanded = false },
            sheetState = menuState,
            containerColor = MaterialTheme.colorScheme.surface,
            tonalElevation = 12.dp,
            dragHandle = { BottomSheetDefaults.DragHandle(color = MaterialTheme.colorScheme.primary.copy(alpha = .55f)) }
        ) {
            Column(Modifier.fillMaxWidth().fillMaxHeight().padding(horizontal = 18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                    Column(Modifier.weight(1f)) {
                        Text("كل أقسام أملاك العائلة", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Text("اختر القسم لفتح محتواه مباشرة", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Icon(Icons.Default.Apps, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(34.dp))
                }
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                val menuItems = listOf(
                    Triple(Tab.Finance, "الدفتر المالي", "الإيرادات والمصروفات والتحصيل والتوزيعات"),
                    Triple(Tab.Entities, "العقارات والمستأجرون", "إدارة الملاك والمستأجرين والكيانات"),
                    Triple(Tab.Contracts, "العقود والأرشيف", "العقود والملاحق والتجديدات والمستندات"),
                    Triple(Tab.Review, "مركز المراجعة", "مطابقة السجلات ومراجعة البيانات"),
                    Triple(Tab.Settings, "الإعدادات والتخصيص", "الألوان والخلفيات والخطوط والحماية والنسخ الاحتياطي")
                )
                androidx.compose.foundation.lazy.LazyColumn(
                    modifier = Modifier.fillMaxWidth().weight(1f),
                    contentPadding = PaddingValues(vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(9.dp)
                ) {
                    items(menuItems) { item ->
                        Card(
                            modifier = Modifier.fillMaxWidth().clickable { tab = item.first; moreExpanded = false },
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .55f)),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                        ) {
                            Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(13.dp)) {
                                Surface(shape = RoundedCornerShape(13.dp), color = MaterialTheme.colorScheme.primaryContainer) {
                                    Icon(item.first.icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(12.dp).size(24.dp))
                                }
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                    Text(item.second, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                    Text(item.third, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                                }
                                Icon(Icons.Default.ChevronLeft, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
                OutlinedButton(onClick = { moreExpanded = false }, modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)) { Text("إغلاق القائمة") }
            }
        }
    }
}



private fun excludedFromCurrent(status:String):Boolean { val s=status.lowercase(); return listOf("مغلقة","مباعة","متوقف","مكرر","مستبعد","غير محسومة").any{s.contains(it)} }
private fun money(v:Double)=NumberFormat.getNumberInstance(Locale("ar","EG")).format(v)+" ج.م"