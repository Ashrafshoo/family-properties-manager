package com.example.rentals.printing

import android.content.Context
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import com.example.rentals.data.AggregateReceiptItem

/** Prints selected aggregate rows as original workbook-style receipts; no payment/ledger state is created. */
internal class AggregateReceiptPrintAdapter(
    context: Context,
    private val items: List<AggregateReceiptItem>,
    private val issuedDate: String,
    private val perPage: Int = 3,
    private val marginMm: Float = 5f
) : PrintDocumentAdapter() {
    private val renderer = OriginalReceiptTemplateRenderer(context)
    private val normalizedIssuedDate = ReceiptDateFormat.toSheet(ReceiptDateFormat.toStorage(issuedDate))
    private var pageCount = 0

    override fun onLayout(oldAttributes: PrintAttributes?, newAttributes: PrintAttributes,
        cancellationSignal: CancellationSignal, callback: LayoutResultCallback, extras: Bundle?) {
        pageCount = (items.size + perPage.coerceIn(1, 3) - 1) / perPage.coerceIn(1, 3)
        callback.onLayoutFinished(PrintDocumentInfo.Builder("إيصالات الكشف المجمع.pdf")
            .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).setPageCount(pageCount).build(), true)
    }

    override fun onWrite(pages: Array<out PageRange>, destination: ParcelFileDescriptor,
        cancellationSignal: CancellationSignal, callback: WriteResultCallback) {
        val document = PdfDocument()
        try {
            for (pageNo in 0 until pageCount) {
                if (cancellationSignal.isCanceled) { callback.onWriteCancelled(); return }
                val page = document.startPage(PdfDocument.PageInfo.Builder(595, 842, pageNo + 1).create())
                val margin = marginMm * 2.8346f
                val count = perPage.coerceIn(1, 3)
                val gap = 5f
                val slotHeight = (842f - margin * 2f - gap * (count - 1)) / count
                for (slot in 0 until count) {
                    val index = pageNo * count + slot
                    if (index >= items.size) break
                    val rect = RectF(margin, margin + slot * (slotHeight + gap), 595f - margin,
                        margin + slot * (slotHeight + gap) + slotHeight)
                    renderer.draw(page.canvas, rect, items[index], normalizedIssuedDate)
                }
                document.finishPage(page)
            }
            java.io.FileOutputStream(destination.fileDescriptor).use { document.writeTo(it) }
            callback.onWriteFinished(arrayOf(PageRange(0, (pageCount - 1).coerceAtLeast(0))))
        } catch (e: Exception) {
            callback.onWriteFailed(e.message ?: "تعذر إنشاء إيصالات الكشف المجمع")
        } finally { document.close() }
    }
}
