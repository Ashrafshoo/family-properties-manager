package com.example.rentals.features.personal

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.rentals.data.RentalsDb
import com.example.rentals.ui.components.PremiumScreenHeader
import java.text.NumberFormat
import java.util.Locale

private fun personalMoney(value: Double): String = NumberFormat.getNumberInstance(Locale("ar", "EG")).format(value) + " ج.م"

@Composable
private fun PersonalNotebookHero() {
    Box(Modifier.fillMaxWidth().height(142.dp).clip(RoundedCornerShape(26.dp)).background(Brush.linearGradient(listOf(Color(0xFF071B3B), Color(0xFF123C68), Color(0xFF087D78))))) {
        Row(Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 17.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Surface(color = Color(0xFFFFD36A).copy(alpha = .16f), shape = RoundedCornerShape(20.dp)) {
                Icon(Icons.Default.MenuBook, null, tint = Color(0xFFFFD36A), modifier = Modifier.padding(17.dp).size(38.dp))
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text("دفتري المالي", color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
                Text("دفتري الخاص • سجلك المالي الشخصي", color = Color.White.copy(alpha = .88f), style = MaterialTheme.typography.bodyMedium)
                Text("مساحة مستقلة ومنظمة لمتابعة حساباتك", color = Color(0xFFFFD36A), style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun PersonalRentNotebook(db:RentalsDb){
    val now=java.time.YearMonth.now()
    var yearText by remember{mutableStateOf(now.year.toString())}
    var monthText by remember{mutableStateOf(now.monthValue.toString())}
    var monthId by remember{mutableLongStateOf(db.personalMonthId(now.year,now.monthValue))}
    var refresh by remember{mutableIntStateOf(0)}
    var expenseTitle by remember{mutableStateOf("")};var expenseAmount by remember{mutableStateOf("")};var expenseDate by remember{mutableStateOf(java.time.LocalDate.now().toString())};var expenseNotes by remember{mutableStateOf("")}
    var editingExpense by remember{mutableStateOf<Array<String>?>(null)}
    var annualVisible by remember{mutableStateOf(false)}
    var message by remember{mutableStateOf("")}
    val rows=remember(monthId,refresh){db.personalRows(monthId)}
    val expenses=remember(monthId,refresh){db.personalExpenses(monthId)}
    val deductions=remember(monthId,refresh){db.personalDeductions(monthId)}
    val total=rows.sumOf{it[2].toDoubleOrNull()?:0.0};val expenseTotal=expenses.sumOf{it[2].toDoubleOrNull()?:0.0}
    val deductionsTotal=deductions.sumOf{it[2].toDoubleOrNull()?:0.0}
    val collectedTotal=rows.filter{it.getOrElse(6){"0"}=="1"}.sumOf{it[2].toDoubleOrNull()?:0.0}
    val pendingTotal=total-collectedTotal
    val annual=remember(yearText,refresh){yearText.toIntOrNull()?.takeIf{it in 2000..2200}?.let{db.personalAnnualSummary(it)}?: emptyList()}
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
        PersonalNotebookHero()
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = androidx.compose.foundation.shape.RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF102B4C)),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFD8B45A).copy(alpha = .45f))
        ) {
            Column(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Color(0xFF071B3B), Color(0xFF174F71), Color(0xFF087D78)))).padding(18.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("ملخص الدفتر للشهر المحدد", modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold, color = Color.White)
                    Icon(Icons.Default.ShowChart, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                }
                Text(personalMoney(total - expenseTotal - deductionsTotal), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = Color.White)
                Text("الصافي بعد المصروفات والخصومات", style = MaterialTheme.typography.bodySmall, color = Color.White.copy(alpha = .78f))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Surface(Modifier.weight(1f), shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.surface.copy(alpha = .78f)) {
                        Column(Modifier.padding(11.dp)) { Text("الإيرادات", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant); Text(personalMoney(total), fontWeight = FontWeight.Bold, color = Color(0xFF087D78)) }
                    }
                    Surface(Modifier.weight(1f), shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.surface.copy(alpha = .78f)) {
                        Column(Modifier.padding(11.dp)) { Text("تم تحصيله", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant); Text(personalMoney(collectedTotal), fontWeight = FontWeight.Bold, color = Color(0xFF087D78)) }
                    }
                    Surface(Modifier.weight(1f), shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.surface.copy(alpha = .78f)) {
                        Column(Modifier.padding(11.dp)) { Text("متبقي", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant); Text(personalMoney(pendingTotal), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error) }
                    }
                }
            }
        }
        Text("التعديلات لا تؤثر في دفتر الحركات الرئيسي؛ هذا الدفتر الشخصي مستقل عن الحسابات الرئيسية ولا يغيّر الحركات المالية أو سجلات التحصيل.",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
            OutlinedTextField(yearText,{yearText=it.filter(Char::isDigit).take(4)},label={Text("السنة")},modifier=Modifier.weight(1f),singleLine=true)
            OutlinedTextField(monthText,{monthText=it.filter(Char::isDigit).take(2)},label={Text("الشهر 1–12")},modifier=Modifier.weight(1f),singleLine=true)
            Button(onClick={try{monthId=db.personalMonthId(yearText.toInt(),monthText.toInt());message="";refresh++}catch(e:Exception){message=e.message?:"راجع السنة والشهر"}},modifier=Modifier.align(Alignment.CenterVertically)){Text("فتح")}
        }
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
            OutlinedButton(onClick={try{val applied=db.applyPersonalTemplatesIfEmpty(monthId);refresh++;message=if(applied)"تم تحميل القائمة المتكررة إلى هذا الشهر فقط" else "لم يتم التغيير لأن الشهر يحتوي بيانات بالفعل"}catch(e:Exception){message=e.message?:"تعذر تحميل القائمة"}},modifier=Modifier.weight(1f)){Text("تحميل القائمة الأساسية")}
            OutlinedButton(onClick={try{val y=yearText.toInt();val m=monthText.toInt();val prev=java.time.YearMonth.of(y,m).minusMonths(1);val source=db.personalMonthId(prev.year,prev.monthValue);monthId=db.copyPersonalNames(source,y,m);refresh++;message="تم ترحيل الأسماء فقط دون المبالغ أو المصروفات"}catch(e:Exception){message=e.message?:"تعذر ترحيل الأسماء"}},modifier=Modifier.weight(1f)){Text("ترحيل أسماء الشهر السابق")}
            OutlinedButton(onClick={annualVisible=!annualVisible}){Text(if(annualVisible)"إخفاء السنوي" else "التقرير السنوي")}
        }
        if(annualVisible){
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){
                Text("ملخص السنة $yearText",fontWeight=FontWeight.Bold)
                if(annual.isEmpty()) Text("لا توجد بيانات مسجلة لهذه السنة.",color=MaterialTheme.colorScheme.onSurfaceVariant)
                annual.forEach{a->val income=a[1].toDoubleOrNull()?:0.0;val cost=a[2].toDoubleOrNull()?:0.0;Row(verticalAlignment=Alignment.CenterVertically){Text("${a[0]}",modifier=Modifier.weight(0.5f));Text("إيراد ${personalMoney(income)}",modifier=Modifier.weight(1.3f),fontSize=11.sp);Text("صافي ${personalMoney(income-cost)}",modifier=Modifier.weight(1.2f),fontSize=11.sp)}}
                val annualIncome=annual.sumOf{it[1].toDoubleOrNull()?:0.0};val annualExpenses=annual.sumOf{it[2].toDoubleOrNull()?:0.0}
                HorizontalDivider();Text("إجمالي السنة: ${personalMoney(annualIncome)} • المصروفات: ${personalMoney(annualExpenses)} • الصافي: ${personalMoney(annualIncome-annualExpenses)}",fontWeight=FontWeight.Bold)
            }}
        }
        Row(verticalAlignment=Alignment.CenterVertically) {
            Text("بيان توزيع عن شهر $monthText لسنة $yearText",fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f))
            Button(onClick={try{val n=db.addPersonalRow(monthId);refresh++;message="أُضيف السطر $n لهذا الشهر فقط"}catch(e:Exception){message=e.message?:"تعذرت إضافة السطر"}}){Text("إضافة صف")}
        }
        Text("البيان • المبلغ • البنت • الولد • حالة التحصيل",fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
        rows.forEach{r->
            val rowNo=r[0].toIntOrNull()?:1
            var tenant by remember(monthId,rowNo,r[1]){mutableStateOf(r[1])}
            var amount by remember(monthId,rowNo,r[2]){mutableStateOf(r[2])}
            var daughter by remember(monthId,rowNo,r[3]){mutableStateOf(r[3])}
            var son by remember(monthId,rowNo,r[4]){mutableStateOf(r[4])}
            var notes by remember(monthId,rowNo,r[5]){mutableStateOf(r[5])}
            var collected by remember(monthId,rowNo,r.getOrElse(6){"0"}){mutableStateOf(r.getOrElse(6){"0"}=="1")}
            Card(Modifier.fillMaxWidth()){
                Column(Modifier.padding(8.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Text("$rowNo",fontWeight=FontWeight.Bold)
                        Spacer(Modifier.weight(1f))
                        Checkbox(checked=collected,onCheckedChange={v->try{db.setPersonalCollected(monthId,rowNo,v);collected=v;refresh++;message=if(v)"تم تسجيل التحصيل لهذا الشهر" else "أُلغيت علامة التحصيل لهذا الشهر"}catch(e:Exception){message=e.message?:"تعذر تحديث حالة التحصيل"}})
                        Text(if(collected)"تم التحصيل" else "لم يتم التحصيل",fontSize=12.sp,color=if(collected)Color(0xFF087D78) else MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    OutlinedTextField(tenant,{tenant=it},label={Text("البيان / الاسم")},modifier=Modifier.fillMaxWidth(),singleLine=true)
                    Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){
                        OutlinedTextField(amount,{amount=it.filter{c->c.isDigit()||c=='.'}},label={Text("المبلغ")},modifier=Modifier.weight(1f),singleLine=true)
                        OutlinedTextField(daughter,{daughter=it.filter{c->c.isDigit()||c=='.'}},label={Text("البنت")},modifier=Modifier.weight(1f),singleLine=true)
                        OutlinedTextField(son,{son=it.filter{c->c.isDigit()||c=='.'}},label={Text("الولد")},modifier=Modifier.weight(1f),singleLine=true)
                    }
                    OutlinedTextField(notes,{notes=it},label={Text("ملاحظات")},modifier=Modifier.fillMaxWidth(),singleLine=true)
                    Row(horizontalArrangement=Arrangement.spacedBy(6.dp),modifier=Modifier.align(Alignment.End)) {
                        TextButton(onClick={try{db.savePersonalTemplate(rowNo,tenant,amount.toDoubleOrNull()?:0.0,daughter.toDoubleOrNull()?:0.0,son.toDoubleOrNull()?:0.0);message="حُفظ الاسم ضمن القائمة المتكررة للشهور الجديدة"}catch(e:Exception){message=e.message?:"تعذر حفظ الاسم المتكرر"}}){Text("تكرار في الشهور الجديدة")}
                        Button(onClick={try{db.savePersonalRow(monthId,rowNo,tenant,amount.toDoubleOrNull()?:0.0,daughter.toDoubleOrNull()?:0.0,son.toDoubleOrNull()?:0.0,notes);refresh++;message="تم حفظ السطر $rowNo لهذا الشهر"}catch(e:Exception){message=e.message?:"تعذر حفظ السطر"}}){Text("حفظ")}
                    }
                }
            }
        }
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)){Text("إجمالي الإيرادات: ${personalMoney(total)} جنيه",fontWeight=FontWeight.Bold);Text("إجمالي المصروفات: ${personalMoney(expenseTotal)} جنيه");Text("الخصومات: ${personalMoney(deductionsTotal)} جنيه");Text("الصافي: ${personalMoney(total-expenseTotal-deductionsTotal)} جنيه",fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary)} }
        HorizontalDivider()
        Row(verticalAlignment=Alignment.CenterVertically) {
            Text("يخصم",fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f))
            Text("إجمالي الخصومات: ${personalMoney(deductionsTotal)}",fontSize=12.sp,color=MaterialTheme.colorScheme.error)
            TextButton(onClick={try{db.addPersonalDeduction(monthId);refresh++;message="أُضيف بند خصم لهذا الشهر"}catch(e:Exception){message=e.message?:"تعذرت إضافة الخصم"}}){Text("إضافة خصم")}
        }
        deductions.forEach { d ->
            val rowNo=d[0].toIntOrNull()?:1
            var title by remember(monthId,rowNo,d[1]){mutableStateOf(d[1])}
            var amount by remember(monthId,rowNo,d[2]){mutableStateOf(d[2])}
            var notes by remember(monthId,rowNo,d[3]){mutableStateOf(d[3])}
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(8.dp),verticalArrangement=Arrangement.spacedBy(5.dp)) {
                Text("خصم $rowNo",fontWeight=FontWeight.SemiBold,fontSize=12.sp)
                Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(title,{title=it},label={Text("البيان")},modifier=Modifier.weight(1f),singleLine=true)
                    OutlinedTextField(amount,{amount=it.filter{c->c.isDigit()||c=='.'}},label={Text("المبلغ")},modifier=Modifier.weight(1f),singleLine=true)
                }
                OutlinedTextField(notes,{notes=it},label={Text("ملاحظات")},modifier=Modifier.fillMaxWidth(),singleLine=true)
                Button(onClick={try{db.savePersonalDeduction(monthId,rowNo,title,amount.toDoubleOrNull()?:0.0,notes);refresh++;message="تم حفظ الخصم $rowNo"}catch(e:Exception){message=e.message?:"تعذر حفظ الخصم"}},modifier=Modifier.align(Alignment.End)){Text("حفظ الخصم")}
            } }
        }
        HorizontalDivider();Text("المصروفات الأخرى",fontWeight=FontWeight.Bold)
        OutlinedTextField(expenseTitle,{expenseTitle=it},label={Text("بيان المصروف")},modifier=Modifier.fillMaxWidth())
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
            OutlinedTextField(expenseAmount,{expenseAmount=it},label={Text("المبلغ")},modifier=Modifier.weight(1f),singleLine=true)
            OutlinedTextField(expenseDate,{expenseDate=it},label={Text("التاريخ YYYY-MM-DD")},modifier=Modifier.weight(1f),singleLine=true)
        }
        OutlinedTextField(expenseNotes,{expenseNotes=it},label={Text("ملاحظات المصروف")},modifier=Modifier.fillMaxWidth())
        Button(onClick={try{db.addPersonalExpense(monthId,expenseTitle,expenseAmount.toDouble(),expenseDate,expenseNotes);expenseTitle="";expenseAmount="";expenseNotes="";refresh++;message="تمت إضافة المصروف"}catch(e:Exception){message=e.message?:"تعذر إضافة المصروف"}},enabled=expenseTitle.isNotBlank()&&(expenseAmount.toDoubleOrNull()?:-1.0)>=0,modifier=Modifier.fillMaxWidth()){Text("إضافة مصروف")}
        expenses.forEach{e->
            Card(Modifier.fillMaxWidth()){ListItem(headlineContent={Text(e[1])},supportingContent={Text("${e[3]} • ${e[4]}")},trailingContent={Row(verticalAlignment=Alignment.CenterVertically){Text(personalMoney(e[2].toDoubleOrNull()?:0.0),fontSize=11.sp);IconButton(onClick={editingExpense=e}){Icon(Icons.Default.Edit,"تعديل المصروف")};IconButton(onClick={try{db.deletePersonalExpense(e[0].toLong());refresh++;message="تم حذف المصروف"}catch(ex:Exception){message=ex.message?:"تعذر الحذف"}}){Icon(Icons.Default.Delete,"حذف المصروف")}}})}
        }
        if(message.isNotBlank()) Text(message,color=MaterialTheme.colorScheme.primary,fontSize=12.sp)
    }
    editingExpense?.let{e->
        var title by remember(e[0]){mutableStateOf(e[1])};var amount by remember(e[0]){mutableStateOf(e[2])};var date by remember(e[0]){mutableStateOf(e[3])};var notes by remember(e[0]){mutableStateOf(e[4])}
        AlertDialog(onDismissRequest={editingExpense=null},title={Text("تعديل المصروف")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){OutlinedTextField(title,{title=it},label={Text("البيان")});OutlinedTextField(amount,{amount=it},label={Text("المبلغ")});OutlinedTextField(date,{date=it},label={Text("التاريخ YYYY-MM-DD")});OutlinedTextField(notes,{notes=it},label={Text("ملاحظات")})}},confirmButton={TextButton(onClick={try{db.updatePersonalExpense(e[0].toLong(),title,amount.toDouble(),date,notes);editingExpense=null;refresh++;message="تم تعديل المصروف"}catch(ex:Exception){message=ex.message?:"تعذر تعديل المصروف"}}){Text("حفظ")}},dismissButton={TextButton(onClick={editingExpense=null}){Text("إلغاء")}})
    }
}

