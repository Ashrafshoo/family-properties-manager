package com.example.rentals.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONObject
import com.example.rentals.domain.collection.collectionIneligibilityReason


data class LegacyImportRecord(
    val id: Long, val batchId: String, val sourceWorkbook: String, val sourceSheet: String,
    val sourceRow: Int, val sourceRecordId: String, val recordType: String,
    val rawJson: String, val status: String, val reviewNote: String
)

class RentalsDb private constructor(context: Context) : SQLiteOpenHelper(context, "rentals_local.db", null, 19) {
    private fun validateMoney(value: Double, label: String, allowZero: Boolean = false) {
        require(value.isFinite() && (if (allowZero) value >= 0.0 else value > 0.0)) { "$label يجب أن يكون مبلغًا صحيحًا موجبًا" }
        val cents = value * 100.0
        require(kotlin.math.abs(cents - kotlin.math.round(cents)) < 0.000001) { "$label يجب ألا يتجاوز منزلتين عشريتين" }
    }
    private fun validatePeriod(period: String) {
        try { java.time.YearMonth.parse(period) }
        catch (_: Exception) { throw IllegalArgumentException("الفترة يجب أن تكون شهرًا صحيحًا بصيغة YYYY-MM") }
    }
    override fun onConfigure(db: SQLiteDatabase) { super.onConfigure(db); db.setForeignKeyConstraintsEnabled(true) }
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE properties(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL UNIQUE,address TEXT,notes TEXT,created_at INTEGER NOT NULL)""")
        db.execSQL("""CREATE TABLE tenants(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT,notes TEXT,created_at INTEGER NOT NULL)""")
        db.execSQL("""CREATE TABLE units(id INTEGER PRIMARY KEY AUTOINCREMENT,code TEXT UNIQUE,property TEXT,tenant TEXT,unit_type TEXT,rent REAL,status TEXT,description TEXT,notes TEXT,updated_at INTEGER NOT NULL,legacy_source_id INTEGER UNIQUE,property_id INTEGER,tenant_id INTEGER)""")
        db.execSQL("""CREATE TABLE leases(id INTEGER PRIMARY KEY AUTOINCREMENT,unit_id INTEGER,tenant_id INTEGER,start_date TEXT,end_date TEXT,rent REAL,payment_due_day INTEGER DEFAULT 1,status TEXT,document_uri TEXT,notes TEXT,tenant_name_snapshot TEXT)""")
        db.execSQL("""CREATE TABLE ledger(id INTEGER PRIMARY KEY AUTOINCREMENT,unit_code TEXT,tenant TEXT,entry_date TEXT,period TEXT,entry_type TEXT,debit REAL DEFAULT 0,credit REAL DEFAULT 0,collector_method TEXT,receipt_no TEXT,notes TEXT,created_at INTEGER NOT NULL)""")
        db.execSQL("""CREATE TABLE collector_receivables(id INTEGER PRIMARY KEY AUTOINCREMENT,collector TEXT NOT NULL,period TEXT,collected_date TEXT,amount REAL NOT NULL,handed_over REAL DEFAULT 0,balance REAL NOT NULL,notes TEXT)""")
        db.execSQL("""CREATE TABLE collection_batches(id INTEGER PRIMARY KEY AUTOINCREMENT,collector TEXT,received_date TEXT,period TEXT,amount REAL,method TEXT,expenses REAL DEFAULT 0,handed_over REAL DEFAULT 0,remaining REAL DEFAULT 0,notes TEXT)""")
        db.execSQL("""CREATE TABLE expenses(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT,amount REAL,expense_date TEXT,period TEXT,category TEXT,recurring INTEGER DEFAULT 0,allocation_json TEXT,attachment_uri TEXT,notes TEXT)""")
        db.execSQL("""CREATE TABLE heirs(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT UNIQUE,share_numerator REAL,share_denominator REAL,active INTEGER DEFAULT 1)""")
        db.execSQL("""CREATE TABLE heir_payouts(id INTEGER PRIMARY KEY AUTOINCREMENT,heir_id INTEGER,amount REAL,pay_date TEXT,method TEXT,period TEXT,notes TEXT)""")
        db.execSQL("""CREATE TABLE attachments(id INTEGER PRIMARY KEY AUTOINCREMENT,owner_type TEXT,owner_id TEXT,uri TEXT,display_name TEXT,mime_type TEXT,created_at INTEGER,notes TEXT,category TEXT NOT NULL DEFAULT 'مستند آخر')""")
        db.execSQL("""CREATE TABLE audit_log(id INTEGER PRIMARY KEY AUTOINCREMENT,record_type TEXT,record_id TEXT,field_name TEXT,old_value TEXT,new_value TEXT,reason TEXT,created_at INTEGER NOT NULL)""")
        db.execSQL("CREATE INDEX idx_units_tenant ON units(tenant)")
        db.execSQL("CREATE INDEX idx_units_property_id ON units(property_id)")
        db.execSQL("CREATE INDEX idx_units_tenant_id ON units(tenant_id)")
        db.execSQL("CREATE INDEX idx_leases_tenant_id ON leases(tenant_id)")
        db.execSQL("CREATE INDEX idx_ledger_unit_period ON ledger(unit_code,period)")
        db.execSQL("""CREATE TABLE receipts(id INTEGER PRIMARY KEY AUTOINCREMENT,receipt_no TEXT NOT NULL UNIQUE,unit_id INTEGER NOT NULL,unit_code TEXT NOT NULL,tenant TEXT NOT NULL,property TEXT,amount REAL,paid_date TEXT NOT NULL,period TEXT NOT NULL,template TEXT NOT NULL DEFAULT 'old',notes TEXT,ledger_id INTEGER,status TEXT NOT NULL DEFAULT 'paid',created_at INTEGER NOT NULL,FOREIGN KEY(unit_id) REFERENCES units(id))""")
        db.execSQL("CREATE INDEX idx_receipts_unit_period ON receipts(unit_id,period)")
        createLegacyStagingTable(db)
        createLegacyContractArchiveTable(db)
        createIntegrityGuards(db)
        createMonthlyWorkflowTables(db)
        createRecoveryTables(db)
        createAggregateReceiptTables(db)
        db.execSQL("CREATE INDEX idx_collection_batches_period ON collection_batches(period,collector)")
        db.execSQL("CREATE INDEX idx_expenses_period ON expenses(period)")
        val heirs = listOf(Triple("إيهاب",2.0,7.0),Triple("خالد",2.0,7.0),Triple("سهام",1.0,7.0),Triple("فاتن",1.0,7.0),Triple("هويدا",1.0,7.0))
        heirs.forEach { (name,n,d) -> db.execSQL("INSERT INTO heirs(name,share_numerator,share_denominator) VALUES(?,?,?)", arrayOf(name,n,d)) }
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("""CREATE TABLE IF NOT EXISTS receipts(id INTEGER PRIMARY KEY AUTOINCREMENT,receipt_no TEXT NOT NULL UNIQUE,unit_id INTEGER NOT NULL,unit_code TEXT NOT NULL,tenant TEXT NOT NULL,property TEXT,amount REAL,paid_date TEXT NOT NULL,period TEXT NOT NULL,template TEXT NOT NULL DEFAULT 'old',notes TEXT,ledger_id INTEGER,created_at INTEGER NOT NULL,FOREIGN KEY(unit_id) REFERENCES units(id))""")
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_receipts_unit_period ON receipts(unit_id,period)")
        }
        if (oldVersion < 3) {
            db.execSQL("ALTER TABLE receipts ADD COLUMN status TEXT NOT NULL DEFAULT 'paid'")
        }
        if (oldVersion < 4) {
            // Draft receipts may legitimately have an unknown rent. Rebuild the table
            // without NOT NULL on amount while preserving every historical row and ID.
            db.execSQL("""CREATE TABLE receipts_v4(id INTEGER PRIMARY KEY AUTOINCREMENT,receipt_no TEXT NOT NULL UNIQUE,unit_id INTEGER NOT NULL,unit_code TEXT NOT NULL,tenant TEXT NOT NULL,property TEXT,amount REAL,paid_date TEXT NOT NULL,period TEXT NOT NULL,template TEXT NOT NULL DEFAULT 'old',notes TEXT,ledger_id INTEGER,status TEXT NOT NULL DEFAULT 'paid',created_at INTEGER NOT NULL,FOREIGN KEY(unit_id) REFERENCES units(id))""")
            db.execSQL("""INSERT INTO receipts_v4(id,receipt_no,unit_id,unit_code,tenant,property,amount,paid_date,period,template,notes,ledger_id,status,created_at) SELECT id,receipt_no,unit_id,unit_code,tenant,property,amount,paid_date,period,template,notes,ledger_id,status,created_at FROM receipts""")
            db.execSQL("DROP TABLE receipts")
            db.execSQL("ALTER TABLE receipts_v4 RENAME TO receipts")
            db.execSQL("CREATE INDEX idx_receipts_unit_period ON receipts(unit_id,period)")
        }
        if (oldVersion < 5) createLegacyStagingTable(db)
        if (oldVersion < 6) {
            db.execSQL("ALTER TABLE units ADD COLUMN legacy_source_id INTEGER")
            db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_units_legacy_source ON units(legacy_source_id)")
        }
        if (oldVersion < 7) {
            db.execSQL("ALTER TABLE attachments ADD COLUMN notes TEXT NOT NULL DEFAULT ''")
        }
        if (oldVersion < 8) {
            db.execSQL("ALTER TABLE attachments ADD COLUMN category TEXT NOT NULL DEFAULT 'مستند آخر'")
        }
        if (oldVersion < 9) createLegacyContractArchiveTable(db)
        if (oldVersion < 10) createIntegrityGuards(db)
        if (oldVersion < 11) {
            // Historical batches had no reliable period; keep them NULL rather than guessing.
            db.execSQL("ALTER TABLE collection_batches ADD COLUMN period TEXT")
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_collection_batches_period ON collection_batches(period,collector)")
            db.execSQL("ALTER TABLE expenses ADD COLUMN period TEXT")
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_expenses_period ON expenses(period)")
        }
        if (oldVersion < 12) {
            // Preserve the tenant identity as it was when each lease was recorded.
            db.execSQL("ALTER TABLE leases ADD COLUMN tenant_name_snapshot TEXT")
            db.execSQL("UPDATE leases SET tenant_name_snapshot=(SELECT tenant FROM units WHERE units.id=leases.unit_id) WHERE tenant_name_snapshot IS NULL")
            // A unit may legitimately have sequential tenants in the same rent period.
            db.execSQL("DROP TRIGGER IF EXISTS trg_receipt_paid_unique_insert")
            db.execSQL("DROP TRIGGER IF EXISTS trg_receipt_paid_unique_update")
            createIntegrityGuards(db)
        }
        if (oldVersion < 13) {
            // Promote the existing text labels into stable, independently managed entities.
            db.execSQL("ALTER TABLE units ADD COLUMN property_id INTEGER")
            db.execSQL("ALTER TABLE units ADD COLUMN tenant_id INTEGER")
            val propertyNames=mutableListOf<String>()
            db.rawQuery("SELECT DISTINCT TRIM(COALESCE(property,'')) FROM units WHERE TRIM(COALESCE(property,''))<>''", null).use { c -> while(c.moveToNext()) propertyNames += c.getString(0) }
            propertyNames.forEach { name -> db.execSQL("INSERT OR IGNORE INTO properties(name,created_at) VALUES(?,?)", arrayOf(name,System.currentTimeMillis())) }
            val tenantNames=mutableListOf<String>()
            db.rawQuery("SELECT DISTINCT TRIM(COALESCE(tenant,'')) FROM units WHERE TRIM(COALESCE(tenant,''))<>''", null).use { c -> while(c.moveToNext()) tenantNames += c.getString(0) }
            tenantNames.forEach { name -> db.execSQL("INSERT INTO tenants(name,created_at) SELECT ?,? WHERE NOT EXISTS(SELECT 1 FROM tenants WHERE name=?)", arrayOf(name,System.currentTimeMillis(),name)) }
            db.execSQL("UPDATE units SET property_id=(SELECT id FROM properties WHERE properties.name=TRIM(units.property)) WHERE TRIM(COALESCE(property,''))<>''")
            db.execSQL("UPDATE units SET tenant_id=(SELECT id FROM tenants WHERE tenants.name=TRIM(units.tenant) ORDER BY id LIMIT 1) WHERE TRIM(COALESCE(tenant,''))<>''")
            // Backfill lease links from the historical snapshot first, not the mutable current unit label.
            db.execSQL("UPDATE leases SET tenant_id=(SELECT t.id FROM tenants t WHERE t.name=TRIM(COALESCE(leases.tenant_name_snapshot,'')) ORDER BY t.id LIMIT 1) WHERE tenant_id IS NULL AND TRIM(COALESCE(tenant_name_snapshot,''))<>''")
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_units_property_id ON units(property_id)")
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_units_tenant_id ON units(tenant_id)")
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_leases_tenant_id ON leases(tenant_id)")
        }
        if (oldVersion < 14) createMonthlyWorkflowTables(db)
        if (oldVersion in 14 until 15) db.execSQL("ALTER TABLE monthly_collection_batches ADD COLUMN issued_date TEXT NOT NULL DEFAULT ''")
        if (oldVersion < 16) createRecoveryTables(db)
        if (oldVersion < 17) {
            if (oldVersion >= 14) db.execSQL("ALTER TABLE personal_rent_rows ADD COLUMN collected INTEGER NOT NULL DEFAULT 0")
            createPersonalNotebookEnhancements(db)
        }
        if (oldVersion < 18) createAggregateReceiptTables(db)
        if (oldVersion < 19) db.execSQL("ALTER TABLE monthly_collection_items ADD COLUMN template_id TEXT NOT NULL DEFAULT ''")
    }

    private fun createAggregateReceiptTables(db: SQLiteDatabase) {
        // These editable monthly statements are independent of units, street numbers,
        // payment receipts, and the financial ledger. Existing rows are never rewritten.
        db.execSQL("""CREATE TABLE IF NOT EXISTS aggregate_receipt_statements(
            id INTEGER PRIMARY KEY AUTOINCREMENT, period TEXT NOT NULL, statement_type TEXT NOT NULL,
            title TEXT NOT NULL, issued_date TEXT NOT NULL DEFAULT '', created_at INTEGER NOT NULL,
            UNIQUE(period,statement_type))""")
        db.execSQL("""CREATE TABLE IF NOT EXISTS aggregate_receipt_items(
            id INTEGER PRIMARY KEY AUTOINCREMENT, statement_id INTEGER NOT NULL, tenant TEXT NOT NULL,
            amount REAL NOT NULL, property TEXT NOT NULL DEFAULT '', unit_code TEXT NOT NULL DEFAULT '',
            description TEXT NOT NULL DEFAULT '', address TEXT NOT NULL DEFAULT '',
            template_id TEXT NOT NULL DEFAULT '', notes TEXT NOT NULL DEFAULT '', sort_order INTEGER NOT NULL DEFAULT 0,
            FOREIGN KEY(statement_id) REFERENCES aggregate_receipt_statements(id) ON DELETE CASCADE)""")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_aggregate_receipt_items_statement ON aggregate_receipt_items(statement_id,sort_order,id)")
    }

    private fun createMonthlyWorkflowTables(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE IF NOT EXISTS monthly_collection_batches(
            id INTEGER PRIMARY KEY AUTOINCREMENT, period TEXT NOT NULL, issued_date TEXT NOT NULL DEFAULT '', title TEXT NOT NULL,
            property_filter TEXT NOT NULL DEFAULT '', created_at INTEGER NOT NULL,
            status TEXT NOT NULL DEFAULT 'prepared', notes TEXT NOT NULL DEFAULT '')""")
        db.execSQL("""CREATE TABLE IF NOT EXISTS monthly_collection_items(
            id INTEGER PRIMARY KEY AUTOINCREMENT, batch_id INTEGER NOT NULL, unit_id INTEGER NOT NULL,
            unit_code TEXT NOT NULL, property TEXT NOT NULL DEFAULT '', tenant TEXT NOT NULL,
            amount REAL, receipt_no TEXT NOT NULL, collection_status TEXT NOT NULL DEFAULT 'not_recorded',
            result_amount REAL, result_date TEXT NOT NULL DEFAULT '', notes TEXT NOT NULL DEFAULT '', template_id TEXT NOT NULL DEFAULT '',
            UNIQUE(batch_id,unit_id), UNIQUE(receipt_no),
            FOREIGN KEY(batch_id) REFERENCES monthly_collection_batches(id) ON DELETE CASCADE)""")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_monthly_collection_period ON monthly_collection_batches(period,created_at)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_monthly_collection_items_batch ON monthly_collection_items(batch_id)")
        // Personal rent notebook is intentionally isolated from family-property ledgers.
        db.execSQL("""CREATE TABLE IF NOT EXISTS personal_rent_months(
            id INTEGER PRIMARY KEY AUTOINCREMENT, year INTEGER NOT NULL, month INTEGER NOT NULL,
            created_at INTEGER NOT NULL, UNIQUE(year,month))""")
        db.execSQL("""CREATE TABLE IF NOT EXISTS personal_rent_rows(
            id INTEGER PRIMARY KEY AUTOINCREMENT, month_id INTEGER NOT NULL, row_no INTEGER NOT NULL,
            tenant TEXT NOT NULL DEFAULT '', total REAL NOT NULL DEFAULT 0,
            daughter REAL NOT NULL DEFAULT 0, son REAL NOT NULL DEFAULT 0,
            notes TEXT NOT NULL DEFAULT '', collected INTEGER NOT NULL DEFAULT 0,
            UNIQUE(month_id,row_no), FOREIGN KEY(month_id) REFERENCES personal_rent_months(id) ON DELETE CASCADE)""")
        db.execSQL("""CREATE TABLE IF NOT EXISTS personal_rent_expenses(
            id INTEGER PRIMARY KEY AUTOINCREMENT, month_id INTEGER NOT NULL,
            title TEXT NOT NULL, amount REAL NOT NULL DEFAULT 0, expense_date TEXT NOT NULL DEFAULT '',
            notes TEXT NOT NULL DEFAULT '', FOREIGN KEY(month_id) REFERENCES personal_rent_months(id) ON DELETE CASCADE)""")
        db.execSQL("""CREATE TABLE IF NOT EXISTS personal_rent_deductions(
            id INTEGER PRIMARY KEY AUTOINCREMENT, month_id INTEGER NOT NULL, row_no INTEGER NOT NULL,
            title TEXT NOT NULL DEFAULT '', amount REAL NOT NULL DEFAULT 0, notes TEXT NOT NULL DEFAULT '',
            UNIQUE(month_id,row_no), FOREIGN KEY(month_id) REFERENCES personal_rent_months(id) ON DELETE CASCADE)""")
        createPersonalNotebookEnhancements(db)
    }

    private fun createPersonalNotebookEnhancements(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE IF NOT EXISTS personal_rent_deductions(
            id INTEGER PRIMARY KEY AUTOINCREMENT, month_id INTEGER NOT NULL, row_no INTEGER NOT NULL,
            title TEXT NOT NULL DEFAULT '', amount REAL NOT NULL DEFAULT 0, notes TEXT NOT NULL DEFAULT '',
            UNIQUE(month_id,row_no), FOREIGN KEY(month_id) REFERENCES personal_rent_months(id) ON DELETE CASCADE)""")
        db.execSQL("""CREATE TABLE IF NOT EXISTS personal_rent_templates(
            id INTEGER PRIMARY KEY AUTOINCREMENT, tenant TEXT NOT NULL UNIQUE,
            total REAL NOT NULL DEFAULT 0, daughter REAL NOT NULL DEFAULT 0,
            son REAL NOT NULL DEFAULT 0, active INTEGER NOT NULL DEFAULT 1,
            created_at INTEGER NOT NULL)""")
        val defaults = listOf(
            arrayOf("الإيجار المتفرق", "0", "0", "0"),
            arrayOf("منى راضي قلادة", "8855", "1265", "2530"),
            arrayOf("حمادة قطعة فوزي رشيد الصغيرة", "6000", "857", "1714"),
            arrayOf("مهدي السيد أبو العلا", "11500", "1643", "3286"),
            arrayOf("جمال عبد الناصر", "8800", "1257", "2514"),
            arrayOf("شركة مصطفى منسي (راغب سابقًا)", "55000", "7857", "15714"),
            arrayOf("كريم شاهز ٣ عقود + أسامة + باقي العمارة (عم لطفي)", "70167", "10024", "20047"),
            arrayOf("محمود يوسف عيد عواد (صابر سفلي)", "15000", "2143", "4286"),
            arrayOf("معهد مصطفى عبد اللطيف جبر صابر علوي", "8000", "1143", "2286"),
            arrayOf("شيك مصر مرسيدس لتجارة السيارات", "13020", "1860", "3720"),
            arrayOf("أولاد صابر داود", "16660", "2380", "4760"),
            arrayOf("أحمد ناصر حسن حنفي", "16200", "2314", "4629"),
            arrayOf("توزيع وجهة شمس مجدي", "15333", "2190", "4381"),
            arrayOf("فوزي رشيد الجرن مجدي", "51333", "7333", "14667"),
            arrayOf("مجدي نعمان دكانين الحدائق", "2400", "343", "686")
        )
        defaults.forEach { row ->
            db.execSQL("INSERT OR IGNORE INTO personal_rent_templates(tenant,total,daughter,son,created_at) VALUES(?,?,?,?,?)",
                arrayOf(row[0], row[1].toDouble(), row[2].toDouble(), row[3].toDouble(), System.currentTimeMillis()))
        }
    }

    /** Database-level guards protect relationships even when data is inserted by import paths. */
    private fun createIntegrityGuards(db: SQLiteDatabase) {
        // A tenant may have at most one paid receipt for a unit and rent period; sequential tenants can both appear in the same month.
        db.execSQL("""CREATE TRIGGER IF NOT EXISTS trg_receipt_paid_unique_insert
            BEFORE INSERT ON receipts WHEN NEW.status='paid' AND EXISTS(
                SELECT 1 FROM receipts WHERE unit_id=NEW.unit_id AND period=NEW.period AND tenant=NEW.tenant AND status='paid')
            BEGIN SELECT RAISE(ABORT,'يوجد إيصال سداد معتمد للوحدة عن الفترة نفسها'); END""")
        db.execSQL("""CREATE TRIGGER IF NOT EXISTS trg_receipt_paid_unique_update
            BEFORE UPDATE OF unit_id,period,tenant,status ON receipts WHEN NEW.status='paid' AND EXISTS(
                SELECT 1 FROM receipts WHERE unit_id=NEW.unit_id AND period=NEW.period AND tenant=NEW.tenant AND status='paid' AND id<>OLD.id)
            BEGIN SELECT RAISE(ABORT,'يوجد إيصال سداد معتمد للوحدة عن الفترة نفسها'); END""")
        // Lease references must always point to an existing unit.
        db.execSQL("""CREATE TRIGGER IF NOT EXISTS trg_lease_unit_insert
            BEFORE INSERT ON leases WHEN NEW.unit_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM units WHERE id=NEW.unit_id)
            BEGIN SELECT RAISE(ABORT,'الوحدة المرتبطة بالعقد غير موجودة'); END""")
        db.execSQL("""CREATE TRIGGER IF NOT EXISTS trg_lease_unit_update
            BEFORE UPDATE OF unit_id ON leases WHEN NEW.unit_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM units WHERE id=NEW.unit_id)
            BEGIN SELECT RAISE(ABORT,'الوحدة المرتبطة بالعقد غير موجودة'); END""")
        db.execSQL("""CREATE TRIGGER IF NOT EXISTS trg_unit_delete_with_lease
            BEFORE DELETE ON units WHEN EXISTS(SELECT 1 FROM leases WHERE unit_id=OLD.id)
            BEGIN SELECT RAISE(ABORT,'لا يمكن حذف وحدة لها عقود؛ أغلق الوحدة واحتفظ بتاريخها'); END""")
        db.execSQL("""CREATE TRIGGER IF NOT EXISTS trg_unit_delete_with_attachments
            BEFORE DELETE ON units WHEN EXISTS(SELECT 1 FROM attachments WHERE owner_type='unit' AND owner_id=CAST(OLD.id AS TEXT))
            BEGIN SELECT RAISE(ABORT,'لا يمكن حذف وحدة لها مستندات محفوظة؛ احتفظ بتاريخ الوحدة ومستنداتها'); END""")
        db.execSQL("""CREATE TRIGGER IF NOT EXISTS trg_lease_tenant_insert
            BEFORE INSERT ON leases WHEN NEW.tenant_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM tenants WHERE id=NEW.tenant_id)
            BEGIN SELECT RAISE(ABORT,'المستأجر المرتبط بالعقد غير موجود'); END""")
        db.execSQL("""CREATE TRIGGER IF NOT EXISTS trg_lease_tenant_update
            BEFORE UPDATE OF tenant_id ON leases WHEN NEW.tenant_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM tenants WHERE id=NEW.tenant_id)
            BEGIN SELECT RAISE(ABORT,'المستأجر المرتبط بالعقد غير موجود'); END""")
        db.execSQL("""CREATE TRIGGER IF NOT EXISTS trg_tenant_delete_with_lease
            BEFORE DELETE ON tenants WHEN EXISTS(SELECT 1 FROM leases WHERE tenant_id=OLD.id)
            BEGIN SELECT RAISE(ABORT,'لا يمكن حذف مستأجر مرتبط بعقد؛ احتفظ بالسجل التاريخي'); END""")
        // Heir payouts are historical financial records and cannot reference a missing heir.
        db.execSQL("""CREATE TRIGGER IF NOT EXISTS trg_payout_heir_insert
            BEFORE INSERT ON heir_payouts WHEN NEW.heir_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM heirs WHERE id=NEW.heir_id)
            BEGIN SELECT RAISE(ABORT,'الوارث المرتبط بالتوزيع غير موجود'); END""")
        db.execSQL("""CREATE TRIGGER IF NOT EXISTS trg_payout_heir_update
            BEFORE UPDATE OF heir_id ON heir_payouts WHEN NEW.heir_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM heirs WHERE id=NEW.heir_id)
            BEGIN SELECT RAISE(ABORT,'الوارث المرتبط بالتوزيع غير موجود'); END""")
        db.execSQL("""CREATE TRIGGER IF NOT EXISTS trg_heir_delete_with_payout
            BEFORE DELETE ON heirs WHEN EXISTS(SELECT 1 FROM heir_payouts WHERE heir_id=OLD.id)
            BEGIN SELECT RAISE(ABORT,'لا يمكن حذف وارث له توزيعات مالية سابقة؛ عطّل السجل بدل حذفه'); END""")
        // If a receipt explicitly points to a ledger row, both must identify the same receipt.
        db.execSQL("""CREATE TRIGGER IF NOT EXISTS trg_receipt_ledger_insert
            BEFORE INSERT ON receipts WHEN NEW.ledger_id IS NOT NULL AND NOT EXISTS(
                SELECT 1 FROM ledger WHERE id=NEW.ledger_id AND receipt_no=NEW.receipt_no)
            BEGIN SELECT RAISE(ABORT,'قيد الإيصال المرتبط غير موجود أو لا يطابق رقم الإيصال'); END""")
        db.execSQL("""CREATE TRIGGER IF NOT EXISTS trg_receipt_ledger_update
            BEFORE UPDATE OF ledger_id,receipt_no ON receipts WHEN NEW.ledger_id IS NOT NULL AND NOT EXISTS(
                SELECT 1 FROM ledger WHERE id=NEW.ledger_id AND receipt_no=NEW.receipt_no)
            BEGIN SELECT RAISE(ABORT,'قيد الإيصال المرتبط غير موجود أو لا يطابق رقم الإيصال'); END""")
        db.execSQL("""CREATE TRIGGER IF NOT EXISTS trg_ledger_keep_receipt_link
            BEFORE DELETE ON ledger WHEN EXISTS(SELECT 1 FROM receipts WHERE ledger_id=OLD.id)
            BEGIN SELECT RAISE(ABORT,'لا يمكن حذف قيد مرتبط بإيصال؛ استخدم تصحيحًا محاسبيًا موثقًا'); END""")
    }

    private fun createLegacyContractArchiveTable(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE IF NOT EXISTS legacy_contract_archive(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source_import_id INTEGER NOT NULL UNIQUE,
            source_contract_id TEXT,
            source_workbook TEXT NOT NULL,
            source_sheet TEXT NOT NULL,
            source_row INTEGER NOT NULL,
            raw_json TEXT NOT NULL,
            linked_unit_id INTEGER,
            link_status TEXT NOT NULL DEFAULT 'unlinked',
            created_at INTEGER NOT NULL,
            linked_at INTEGER,
            notes TEXT NOT NULL DEFAULT '',
            FOREIGN KEY(linked_unit_id) REFERENCES units(id) ON DELETE SET NULL
        )""")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_legacy_contract_link ON legacy_contract_archive(link_status,source_contract_id)")
    }

    /** Returns legacy source rows without converting them into live financial or rental records. */
    @Synchronized fun legacyImportRecords(status: String? = null, recordType: String? = null, query: String = ""): List<LegacyImportRecord> {
        val clauses = mutableListOf<String>()
        val args = mutableListOf<String>()
        if (!status.isNullOrBlank()) { clauses += "status=?"; args += status }
        if (!recordType.isNullOrBlank()) { clauses += "record_type=?"; args += recordType }
        if (query.isNotBlank()) {
            clauses += "(source_record_id LIKE ? OR source_sheet LIKE ? OR raw_json LIKE ? OR review_note LIKE ?)"
            repeat(4) { args += "%$query%" }
        }
        val where = if (clauses.isEmpty()) "" else " WHERE " + clauses.joinToString(" AND ")
        val sql = "SELECT id,batch_id,source_workbook,source_sheet,source_row,COALESCE(source_record_id,''),record_type,raw_json,status,COALESCE(review_note,'') FROM legacy_import_records$where ORDER BY created_at DESC,source_sheet,source_row LIMIT 1000"
        return readableDatabase.rawQuery(sql, args.toTypedArray()).use { c ->
            val out = mutableListOf<LegacyImportRecord>()
            while (c.moveToNext()) out += LegacyImportRecord(c.getLong(0),c.getString(1),c.getString(2),c.getString(3),c.getInt(4),c.getString(5),c.getString(6),c.getString(7),c.getString(8),c.getString(9))
            out
        }
    }

    @Synchronized fun legacyImportCounts(): Map<String, Int> {
        val result = linkedMapOf<String, Int>()
        readableDatabase.rawQuery("SELECT status,COUNT(*) FROM legacy_import_records GROUP BY status", null).use { c ->
            while (c.moveToNext()) result[c.getString(0)] = c.getInt(1)
        }
        return result
    }

    @Synchronized fun updateLegacyImportReview(id: Long, status: String, note: String) {
        require(status in setOf("pending_review", "approved_for_mapping", "excluded", "migrated_to_review", "archived_unlinked")) { "حالة مراجعة غير مسموح بها" }
        val changed = writableDatabase.update("legacy_import_records", ContentValues().apply {
            put("status", status); put("review_note", note)
        }, "id=?", arrayOf(id.toString()))
        require(changed == 1) { "لم يتم العثور على السجل المطلوب" }
    }

    data class LegacyContractArchiveRow(
        val id: Long, val sourceImportId: Long, val sourceContractId: String,
        val sourceWorkbook: String, val sourceSheet: String, val sourceRow: Int,
        val rawJson: String, val linkedUnitId: Long?, val linkStatus: String,
        val createdAt: Long, val linkedAt: Long?, val notes: String
    )
    data class LegacyContractArchiveResult(val inserted: Int, val alreadyArchived: Int, val blocked: Int)

    /** Archives only individually approved source contracts. It deliberately creates no operational lease,
     * no unit link, no tenant, no receipt and no financial transaction. */
    @Synchronized fun archiveApprovedLegacyContracts(): LegacyContractArchiveResult {
        val db = writableDatabase
        val records = legacyImportRecords(recordType = "lease_source").filter { it.status == "approved_for_mapping" }
        var inserted = 0; var already = 0; var blocked = 0
        db.beginTransaction()
        try {
            records.forEach { record ->
                val exists = db.rawQuery("SELECT 1 FROM legacy_contract_archive WHERE source_import_id=?", arrayOf(record.id.toString())).use { it.moveToFirst() }
                if (exists) { already++; return@forEach }
                val contractId = record.sourceRecordId.takeIf { it.isNotBlank() }
                db.execSQL("""INSERT INTO legacy_contract_archive(source_import_id,source_contract_id,source_workbook,source_sheet,source_row,raw_json,link_status,created_at,notes)
                    VALUES(?,?,?,?,?,?, 'unlinked', ?, ?)""", arrayOf(record.id, contractId, record.sourceWorkbook, record.sourceSheet, record.sourceRow, record.rawJson, System.currentTimeMillis(), "أُرشف من المصدر بعد اعتماد فردي. لم يُربط بوحدة ولم يُنشأ عقد تشغيلي أو قيد مالي."))
                db.update("legacy_import_records", ContentValues().apply { put("status", "archived_unlinked"); put("review_note", "نُسخت نسخة أمينة إلى أرشيف العقود غير المرتبطة؛ لا يوجد ربط تشغيلي بعد.") }, "id=?", arrayOf(record.id.toString()))
                inserted++
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
        return LegacyContractArchiveResult(inserted, already, blocked)
    }

    @Synchronized fun legacyContractArchive(): List<LegacyContractArchiveRow> = readableDatabase.rawQuery(
        "SELECT id,source_import_id,COALESCE(source_contract_id,''),source_workbook,source_sheet,source_row,raw_json,linked_unit_id,link_status,created_at,linked_at,COALESCE(notes,'') FROM legacy_contract_archive ORDER BY id DESC", null
    ).use { c ->
        val out = mutableListOf<LegacyContractArchiveRow>()
        while (c.moveToNext()) out += LegacyContractArchiveRow(c.getLong(0),c.getLong(1),c.getString(2),c.getString(3),c.getString(4),c.getInt(5),c.getString(6),if(c.isNull(7)) null else c.getLong(7),c.getString(8),c.getLong(9),if(c.isNull(10)) null else c.getLong(10),c.getString(11))
        out
    }

    /** Explicit owner-selected link only; no source matching result can call this automatically. */
    @Synchronized fun linkLegacyContractToUnit(archiveId: Long, unitId: Long, note: String = "") {
        require(archiveId > 0 && unitId > 0)
        require(readableDatabase.rawQuery("SELECT 1 FROM legacy_contract_archive WHERE id=?", arrayOf(archiveId.toString())).use { it.moveToFirst() }) { "العقد المؤرشف غير موجود" }
        require(readableDatabase.rawQuery("SELECT 1 FROM units WHERE id=?", arrayOf(unitId.toString())).use { it.moveToFirst() }) { "الوحدة المحددة غير موجودة" }
        val db = writableDatabase
        db.beginTransaction()
        try {
            val old = db.rawQuery("SELECT linked_unit_id,COALESCE(source_contract_id,''),COALESCE(notes,'') FROM legacy_contract_archive WHERE id=?", arrayOf(archiveId.toString())).use { c ->
                require(c.moveToFirst()) { "العقد المؤرشف غير موجود" }
                Triple(if (c.isNull(0)) null else c.getLong(0), c.getString(1), c.getString(2))
            }
            val now = System.currentTimeMillis()
            val updatedNotes = if (note.isBlank()) old.third else listOf(old.third, "ملاحظة ربط $now: $note").filter { it.isNotBlank() }.joinToString("\n")
            val changed = db.update("legacy_contract_archive", ContentValues().apply {
                put("linked_unit_id", unitId); put("link_status", "linked_by_user"); put("linked_at", now); put("notes", updatedNotes)
            }, "id=?", arrayOf(archiveId.toString()))
            require(changed == 1) { "تعذر حفظ ربط العقد بالوحدة" }
            db.execSQL("INSERT INTO audit_log(record_type,record_id,field_name,old_value,new_value,reason,created_at) VALUES(?,?,?,?,?,?,?)", arrayOf("legacy_contract", archiveId.toString(), "linked_unit_id", old.first?.toString() ?: "", unitId.toString(), "ربط صريح اختاره المستخدم للعقد ${old.second}.", now))
            if (old.first == null) db.execSQL("INSERT INTO audit_log(record_type,record_id,field_name,old_value,new_value,reason,created_at) VALUES(?,?,?,?,?,?,?)", arrayOf("legacy_contract", archiveId.toString(), "link_status", "unlinked", "linked_by_user", "اعتماد ربط يدوي", now))
            if (note.isNotBlank()) db.execSQL("INSERT INTO audit_log(record_type,record_id,field_name,old_value,new_value,reason,created_at) VALUES(?,?,?,?,?,?,?)", arrayOf("legacy_contract", archiveId.toString(), "notes", old.third, updatedNotes, "إضافة ملاحظة ربط دون حذف الملاحظات السابقة", now))
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    /** Removes only the manual unit link; the archived source contract and all prior notes remain intact. */
    @Synchronized fun unlinkLegacyContractFromUnit(archiveId: Long, reason: String) {
        require(archiveId > 0) { "معرّف العقد غير صالح" }
        require(reason.isNotBlank()) { "اكتب سبب إلغاء الربط لحفظه في سجل المراجعة" }
        val db = writableDatabase
        db.beginTransaction()
        try {
            val old = db.rawQuery("SELECT linked_unit_id,COALESCE(source_contract_id,''),COALESCE(notes,'') FROM legacy_contract_archive WHERE id=?", arrayOf(archiveId.toString())).use { c ->
                require(c.moveToFirst()) { "العقد المؤرشف غير موجود" }
                Triple(if (c.isNull(0)) null else c.getLong(0), c.getString(1), c.getString(2))
            }
            require(old.first != null) { "العقد غير مرتبط بوحدة حاليًا" }
            val now = System.currentTimeMillis()
            val updatedNotes = listOf(old.third, "إلغاء ربط $now: $reason").filter { it.isNotBlank() }.joinToString("\n")
            val changed = db.update("legacy_contract_archive", ContentValues().apply {
                putNull("linked_unit_id"); put("link_status", "unlinked"); putNull("linked_at"); put("notes", updatedNotes)
            }, "id=?", arrayOf(archiveId.toString()))
            require(changed == 1) { "تعذر إلغاء ربط العقد" }
            db.execSQL("INSERT INTO audit_log(record_type,record_id,field_name,old_value,new_value,reason,created_at) VALUES(?,?,?,?,?,?,?)", arrayOf("legacy_contract", archiveId.toString(), "linked_unit_id", old.first.toString(), "", "إلغاء ربط يدوي للعقد ${old.second}: $reason", now))
            db.execSQL("INSERT INTO audit_log(record_type,record_id,field_name,old_value,new_value,reason,created_at) VALUES(?,?,?,?,?,?,?)", arrayOf("legacy_contract", archiveId.toString(), "link_status", "linked_by_user", "unlinked", reason, now))
            db.execSQL("INSERT INTO audit_log(record_type,record_id,field_name,old_value,new_value,reason,created_at) VALUES(?,?,?,?,?,?,?)", arrayOf("legacy_contract", archiveId.toString(), "notes", old.third, updatedNotes, "حفظ سبب إلغاء الربط في سجل العقد", now))
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    data class LegacyUnitMigrationResult(val inserted: Int, val alreadyMigrated: Int, val blocked: Int)

    /**
     * Q022 operational import: a named tenant and positive current rent are sufficient
     * to create a review-state unit. Receipt matching is supporting evidence only;
     * it must never be a gate that leaves the operational units list empty.
     * Missing names/rents, sold/closed, tenant-change-pending and documentary duplicates
     * remain safely staged for manual review. No receipts or financial entries are created.
     */
    @Synchronized fun migrateUniquelyMatchedLegacyUnitsToReview(): LegacyUnitMigrationResult {
        val records = legacyImportRecords(recordType = "unit_source")
        val actionable = records.filter { it.status == "pending_review" || it.status == "approved_for_mapping" }
        val existingCodes = units().map { it.code }.filter { it.isNotBlank() }.toSet()
        val candidates = LegacyUnitReviewAnalyzer.analyze(actionable, existingCodes)
        val excluded = setOf(
            LegacyUnitReviewAnalyzer.Class.SOLD_ARCHIVE_ONLY,
            LegacyUnitReviewAnalyzer.Class.CLOSED_ARCHIVE_ONLY,
            LegacyUnitReviewAnalyzer.Class.CLOSED_STOPPED_CONFIRMED,
            LegacyUnitReviewAnalyzer.Class.EXCLUDED_SOURCE_ONLY,
            LegacyUnitReviewAnalyzer.Class.DOCUMENTARY_DUPLICATE,
            LegacyUnitReviewAnalyzer.Class.TENANT_CHANGE_PENDING
        )
        val eligible = candidates.filter { row ->
            val rent = row.currentRent.replace(",", "").toDoubleOrNull()
            val tenant = row.tenant.trim().removePrefix("-").trim()
                .replace(Regex("^(السيد|السادة|السيدة|أ\\s*/|ا\\s*/|م\\s*/|مدام)\\s*/?\\s*"), "").trim()
            row.code.isNotBlank() && tenant.isNotBlank() && rent != null && rent > 0.0 &&
                row.classification !in excluded && !row.conflictsWithExistingCode
        }
        eligible.forEach { updateLegacyImportReview(it.record.id, "approved_for_mapping", "اسم المستأجر والقيمة الحالية متوفران؛ أُنشئت الوحدة بحالة مراجعة. مطابقة الإيصال دليل مساعد وليست شرطًا لإنشاء الوحدة.") }
        val result = migrateApprovedLegacyUnitsToReview(eligible.map { it.record.id }.toSet())
        val blocked = (actionable.size - result.inserted - result.alreadyMigrated).coerceAtLeast(0)
        return result.copy(blocked = blocked)
    }

    /** Imports individually approved Q022 source units as unresolved operational records.
     * Receipt matching is optional evidence. No draft receipts, paid receipts, leases, or ledger entries are created.
     */
    @Synchronized fun migrateApprovedLegacyUnitsToReview(onlySourceIds: Set<Long>? = null): LegacyUnitMigrationResult {
        val db = writableDatabase
        val records = legacyImportRecords(recordType = "unit_source")
        // Join by immutable staging-row ID, never by the human-readable unit code.
        // Codes can be duplicated or corrected; a code-based map could otherwise
        // apply another row's unique match to the wrong approved source record.
        val matches = LegacyReceiptMatchAnalyzer.analyze(legacyImportRecords())
            .associateBy { it.sourceImportId }
        var inserted = 0
        var already = 0
        var blocked = 0
        db.beginTransaction()
        try {
            records.filter { it.status == "approved_for_mapping" && (onlySourceIds == null || it.id in onlySourceIds) }.forEach { record ->
                val json = org.json.JSONObject(record.rawJson)
                fun f(key: String) = json.optString(key, "").trim()
                val code = f("معرّف السجل")
                val match = matches[record.id]
                val tenantCheck = f("اسم المستأجر كما ورد").removePrefix("-").trim()
                    .replace(Regex("^(السيد|السادة|السيدة|أ\\s*/|ا\\s*/|م\\s*/|مدام)\\s*/?\\s*"), "").trim()
                val rentCheck = f("القيمة الحالية (جنيه/شهر)").replace(",", "").toDoubleOrNull()
                val classification = LegacyUnitReviewAnalyzer.classifySourceFields(
                    f("حالة الوحدة التشغيلية"), f("حالة الربط"), f("اسم المستأجر كما ورد"),
                    f("القيمة الحالية (جنيه/شهر)"), f("قيمة الإيصال (جنيه)"), f("ملاحظات الكشف/الاعتماد")
                )
                val neverAutoCreate = classification in setOf(
                    LegacyUnitReviewAnalyzer.Class.SOLD_ARCHIVE_ONLY,
                    LegacyUnitReviewAnalyzer.Class.CLOSED_ARCHIVE_ONLY,
                    LegacyUnitReviewAnalyzer.Class.CLOSED_STOPPED_CONFIRMED,
                    LegacyUnitReviewAnalyzer.Class.EXCLUDED_SOURCE_ONLY,
                    LegacyUnitReviewAnalyzer.Class.DOCUMENTARY_DUPLICATE,
                    LegacyUnitReviewAnalyzer.Class.TENANT_CHANGE_PENDING
                )
                if (code.isBlank() || tenantCheck.isBlank() || rentCheck == null || rentCheck <= 0.0 || neverAutoCreate) {
                    blocked++
                    return@forEach
                }
                val alreadyMigrated = db.rawQuery("SELECT id FROM units WHERE legacy_source_id=? LIMIT 1", arrayOf(record.id.toString())).use { it.moveToFirst() }
                if (alreadyMigrated) {
                    db.update("legacy_import_records", ContentValues().apply { put("status", "migrated_to_review") }, "id=?", arrayOf(record.id.toString()))
                    already++
                    return@forEach
                }
                val codeConflict = db.rawQuery("SELECT id FROM units WHERE code=? LIMIT 1", arrayOf(code)).use { it.moveToFirst() }
                if (codeConflict) { blocked++; return@forEach }
                val tenantRaw = f("اسم المستأجر كما ورد")
                val tenant = tenantRaw.removePrefix("-").trim()
                    .replace(Regex("^(السيد|السادة|السيدة|أ\\s*/|ا\\s*/|م\\s*/|مدام)\\s*/?\\s*"), "").trim()
                val rent = f("القيمة الحالية (جنيه/شهر)").replace(",", "").toDoubleOrNull()
                if (tenant.isBlank() || rent == null || rent <= 0.0) { blocked++; return@forEach }
                val property = f("المجموعة/العقار كما ورد بالمصدر")
                val unitType = f("نوع الوحدة").ifBlank { "غير محدد" }
                val notes = buildString {
                    append("مستورد من ملف Q022 – يحتاج اعتماد الحالة التشغيلية قبل التفعيل.")
                    append("\nالوصف: ").append(f("وصف العين من الإيصال"))
                    append("\nالعنوان: ").append(f("العنوان كما ورد بالإيصال"))
                    append("\nمصدر البيانات: ").append(f("مصدر البيانات"))
                    append("\nمرجع المصدر: ").append(record.sourceSheet).append("، الصف ").append(record.sourceRow)
                    if (match?.matchStatus == LegacyReceiptMatchAnalyzer.MatchStatus.UNIQUE_SOURCE_MATCH) {
                        append("\nمطابقة مصدرية فريدة مع صف الإيصال: ").append(match.receiptRows.joinToString("، "))
                    } else {
                        append("\nلم تُشترط مطابقة إيصال لإنشاء الوحدة؛ تُستكمل المطابقة عند الحاجة.")
                    }
                }
                val values = ContentValues().apply {
                    put("code", code); put("property", property); put("tenant", tenant)
                    put("unit_type", unitType); if (rent == null) putNull("rent") else put("rent", rent)
                    put("status", when {
                        f("حالة الوحدة التشغيلية").contains("متوقف عن الدفع") -> "متوقف عن الدفع"
                        f("حالة الوحدة التشغيلية").contains("نشطة") -> "نشطة – غير محسومة ماليًا"
                        else -> "غير محسومة"
                    }); put("description", f("وصف العين من الإيصال"))
                    put("notes", notes); put("updated_at", System.currentTimeMillis()); put("legacy_source_id", record.id)
                }
                db.insertOrThrow("units", null, values)
                db.update("legacy_import_records", ContentValues().apply {
                    put("status", "migrated_to_review")
                    put("review_note", "نُقل إلى سجل الوحدات بحالة غير محسومة؛ لم يُنشأ إيصال أو قيد مالي.")
                }, "id=?", arrayOf(record.id.toString()))
                inserted++
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
        return LegacyUnitMigrationResult(inserted, already, blocked)
    }

    private fun createLegacyStagingTable(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE IF NOT EXISTS legacy_import_records(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            batch_id TEXT NOT NULL,
            source_fingerprint TEXT NOT NULL,
            source_workbook TEXT NOT NULL,
            source_sheet TEXT NOT NULL,
            source_row INTEGER NOT NULL,
            source_record_id TEXT,
            record_type TEXT NOT NULL,
            raw_json TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'pending_review',
            review_note TEXT,
            created_at INTEGER NOT NULL,
            UNIQUE(source_fingerprint, source_sheet, source_row)
        )""")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_legacy_import_status ON legacy_import_records(status,record_type)")
    }


    @Synchronized fun reviewFlags(): List<ReviewFlag> {
        val out = mutableListOf<ReviewFlag>()
        units().forEach { u ->
            if (u.code.isBlank()) out += ReviewFlag(u.code, u.tenant, "كود الوحدة غير مدخل")
            if (u.property.isBlank()) out += ReviewFlag(u.code, u.tenant, "عنوان العقار غير مكتمل")
            if (u.tenant.isBlank()) out += ReviewFlag(u.code, u.tenant, "اسم المستأجر غير مدخل")
            if (u.status.contains("غير محسومة")) out += ReviewFlag(u.code, u.tenant, "حالة التشغيل غير محسومة؛ لا تُنشأ مسودة إيصال قابلة للتحصيل حتى اعتماد الحالة")
            if (u.status.contains("تغيير مستأجر")) out += ReviewFlag(u.code, u.tenant, "حالة تغيير مستأجر لم تُستكمل بعد؛ أدخل اسم المستأجر الجديد لاعتماد الوحدة وإنشاء مسودة باسمه")
            if (u.rent == null) out += ReviewFlag(u.code, u.tenant, "القيمة الحالية غير معروفة؛ تُترك فارغة ولا تُحسب صفرًا")
            val hasLease = readableDatabase.rawQuery("SELECT 1 FROM leases WHERE unit_id=? LIMIT 1", arrayOf(u.id.toString())).use { it.moveToFirst() }
            if (!hasLease) out += ReviewFlag(u.code, u.tenant, "لا يوجد عقد مرتبط مسجل في التطبيق")
            val hasPaidReceipt = readableDatabase.rawQuery("SELECT 1 FROM receipts WHERE unit_id=? AND tenant=? AND status='paid' LIMIT 1", arrayOf(u.id.toString(),u.tenant)).use { it.moveToFirst() }
            val hasDraftReceipt = readableDatabase.rawQuery("SELECT 1 FROM receipts WHERE unit_id=? AND tenant=? AND status='draft' LIMIT 1", arrayOf(u.id.toString(),u.tenant)).use { it.moveToFirst() }
            if (!hasPaidReceipt && hasDraftReceipt) out += ReviewFlag(u.code, u.tenant, "يوجد إيصال مسودة فقط؛ لا يثبت سداد الإيجار")
            else if (!hasPaidReceipt) out += ReviewFlag(u.code, u.tenant, "لا يوجد إيصال سداد محفوظ؛ يلزم التحقق ولا يعني ذلك تلقائيًا توقف الدفع")
        }
        return out
    }

    @Synchronized fun nextReceiptNo(): String {
        val n = readableDatabase.rawQuery("SELECT COUNT(*) FROM receipts", null).use { if (it.moveToFirst()) it.getInt(0) + 1 else 1 }
        return "REC-${System.currentTimeMillis()}-$n"
    }

    @Synchronized fun saveReceipt(receipt: ReceiptRecord): Long {
        require(receipt.receiptNo.isNotBlank() && receipt.amount != null && receipt.amount.isFinite() && receipt.amount > 0.0) { "راجع رقم الإيصال والمبلغ" }
        validatePeriod(receipt.period)
        val paidAmount = receipt.amount ?: throw IllegalArgumentException("مبلغ السداد مطلوب")
        require(receipt.tenant.isNotBlank()) { "اسم المستأجر مطلوب" }
        try { java.time.LocalDate.parse(receipt.paidDate) } catch (_: Exception) { throw IllegalArgumentException("تاريخ السداد يجب أن يكون YYYY-MM-DD") }
        val db = writableDatabase
        db.beginTransaction()
        try {
            val unitExists = db.rawQuery("SELECT id FROM units WHERE id=? AND code=?", arrayOf(receipt.unitId.toString(), receipt.unitCode)).use { it.moveToFirst() }
            require(unitExists) { "الوحدة المحددة لم تعد موجودة؛ حدّث القائمة ثم أعد المحاولة" }
            val alreadyPaid = db.rawQuery("SELECT id FROM receipts WHERE unit_id=? AND period=? AND tenant=? AND status='paid' LIMIT 1", arrayOf(receipt.unitId.toString(), receipt.period, receipt.tenant)).use { it.moveToFirst() }
            require(!alreadyPaid) { "يوجد إيصال سداد معتمد لهذه الوحدة عن الفترة نفسها؛ لا يمكن تسجيل إيصال مكرر. استخدم إجراء تصحيح موثق إن كان الإيصال السابق خاطئًا." }
            val ledgerId = db.insertOrThrow("ledger", null, ContentValues().apply {
                put("unit_code", receipt.unitCode); put("tenant", receipt.tenant); put("entry_date", receipt.paidDate)
                put("period", receipt.period); put("entry_type", "إيصال سداد")
                put("debit", 0.0); put("credit", paidAmount); put("collector_method", "المحصّل")
                put("receipt_no", receipt.receiptNo); put("notes", receipt.notes); put("created_at", System.currentTimeMillis())
            })
            val draftId = db.rawQuery("SELECT id FROM receipts WHERE unit_id=? AND period=? AND tenant=? AND status='draft' ORDER BY id LIMIT 1", arrayOf(receipt.unitId.toString(), receipt.period, receipt.tenant)).use { if(it.moveToFirst()) it.getLong(0) else 0L }
            val values = ContentValues().apply {
                put("receipt_no", receipt.receiptNo); put("unit_id", receipt.unitId); put("unit_code", receipt.unitCode)
                put("tenant", receipt.tenant); put("property", receipt.property); put("amount", paidAmount)
                put("paid_date", receipt.paidDate); put("period", receipt.period); put("template", receipt.template)
                put("notes", receipt.notes); put("ledger_id", ledgerId); put("status", "paid"); put("created_at", System.currentTimeMillis())
            }
            val id = if (draftId > 0) db.update("receipts", values, "id=?", arrayOf(draftId.toString())).let { draftId }
                      else db.insertOrThrow("receipts", null, values)
            db.setTransactionSuccessful()
            return id
        } finally { db.endTransaction() }
    }

    @Synchronized fun ensureDraftReceiptsForAllUnits() {
        val db = writableDatabase
        db.beginTransaction()
        try {
            val rows = mutableListOf<Pair<Long, UnitRecord>>()
            db.rawQuery("SELECT id,code,property,tenant,unit_type,rent,status,description,notes,updated_at FROM units", null).use { c ->
                while (c.moveToNext()) rows += c.getLong(0) to UnitRecord(c.getLong(0),c.getString(1)?:"",c.getString(2)?:"",c.getString(3)?:"",c.getString(4)?:"غير محدد",if(c.isNull(5)) null else c.getDouble(5),c.getString(6)?:"نشطة",c.getString(7)?:"",c.getString(8)?:"",c.getLong(9))
            }
            rows.forEach { (id,u) -> ensureDraftReceipt(db,id,u.code,u) }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    @Synchronized fun receipts(unitId: Long? = null): List<ReceiptRecord> {
        val sql = "SELECT id,receipt_no,unit_id,unit_code,tenant,COALESCE(property,''),amount,COALESCE(paid_date,''),period,template,COALESCE(notes,''),status FROM receipts" + if (unitId == null) " ORDER BY created_at DESC,id DESC" else " WHERE unit_id=? ORDER BY created_at DESC,id DESC"
        val c = if (unitId == null) readableDatabase.rawQuery(sql, null) else readableDatabase.rawQuery(sql, arrayOf(unitId.toString()))
        return c.use { cur -> buildList { while (cur.moveToNext()) add(ReceiptRecord(cur.getLong(0),cur.getString(1),cur.getLong(2),cur.getString(3),cur.getString(4),cur.getString(5),if(cur.isNull(6)) null else cur.getDouble(6),cur.getString(7),cur.getString(8),cur.getString(9),cur.getString(10),cur.getString(11))) } }
    }


    data class MonthlyBatch(val id:Long,val period:String,val title:String,val propertyFilter:String,val createdAt:Long,val itemCount:Int)

    private fun validateAggregateType(type: String) {
        require(type in setOf("factories", "homes", "villa_mayor")) { "نوع الكشف المجمع غير صحيح" }
    }
    @Synchronized fun getOrCreateAggregateStatement(period: String, type: String, issuedDate: String): Long {
        validatePeriod(period); validateAggregateType(type)
        require(issuedDate.isBlank() || runCatching { java.time.LocalDate.parse(issuedDate) }.isSuccess) { "تاريخ الإصدار غير صحيح" }
        val titles = mapOf("factories" to "كشف مجمع المصانع", "homes" to "كشف مجمع البيوت", "villa_mayor" to "كشف مجمع فيلا وعمارة العمدة")
        val db = writableDatabase
        db.rawQuery("SELECT id,issued_date FROM aggregate_receipt_statements WHERE period=? AND statement_type=?", arrayOf(period,type)).use { c ->
            if (c.moveToFirst()) {
                val existingId=c.getLong(0); val oldDate=c.getString(1).orEmpty()
                if (oldDate != issuedDate) db.update("aggregate_receipt_statements",ContentValues().apply{put("issued_date",issuedDate)},"id=?",arrayOf(existingId.toString()))
                return existingId
            }
        }
        return db.insertOrThrow("aggregate_receipt_statements", null, ContentValues().apply {
            put("period",period); put("statement_type",type); put("title",titles.getValue(type)); put("issued_date",issuedDate); put("created_at",System.currentTimeMillis())
        })
    }
    @Synchronized fun aggregateReceiptStatements(period: String): List<AggregateReceiptStatement> {
        validatePeriod(period)
        return readableDatabase.rawQuery("SELECT id,period,statement_type,title,issued_date FROM aggregate_receipt_statements WHERE period=? ORDER BY statement_type",arrayOf(period)).use { c ->
            buildList { while(c.moveToNext()) { val id=c.getLong(0); add(AggregateReceiptStatement(id,c.getString(1),c.getString(2),c.getString(3),c.getString(4),aggregateReceiptItems(id))) } }
        }
    }
    @Synchronized fun aggregateReceiptItems(statementId: Long): List<AggregateReceiptItem> = readableDatabase.rawQuery(
        "SELECT id,statement_id,tenant,amount,property,unit_code,description,address,template_id,notes FROM aggregate_receipt_items WHERE statement_id=? ORDER BY sort_order,id",arrayOf(statementId.toString())
    ).use { c -> buildList { while(c.moveToNext()) add(AggregateReceiptItem(c.getLong(0),c.getLong(1),c.getString(2),c.getDouble(3),c.getString(4),c.getString(5),c.getString(6),c.getString(7),c.getString(8),c.getString(9))) } }
    @Synchronized fun addAggregateReceiptItem(statementId: Long, item: AggregateReceiptItem): Long {
        require(item.tenant.isNotBlank()) { "اسم المستأجر مطلوب" }; validateMoney(item.amount,"القيمة الإيجارية")
        require(readableDatabase.rawQuery("SELECT 1 FROM aggregate_receipt_statements WHERE id=?",arrayOf(statementId.toString())).use{it.moveToFirst()}) { "الكشف المجمع غير موجود" }
        val db=writableDatabase
        val id=db.insertOrThrow("aggregate_receipt_items",null,ContentValues().apply {
            put("statement_id",statementId);put("tenant",item.tenant.trim());put("amount",item.amount);put("property",item.property);put("unit_code",item.unitCode);put("description",item.description);put("address",item.address);put("template_id",item.templateId);put("notes",item.notes);put("sort_order",(aggregateReceiptItems(statementId).size+1))
        })
        recordAudit(db,"aggregate_receipt_items",id.toString(),"record",null,"${item.tenant.trim()}|${item.amount}","إضافة صف إلى كشف مجمع شهري")
        return id
    }
    @Synchronized fun updateAggregateReceiptItem(item: AggregateReceiptItem) {
        require(item.id>0 && item.tenant.isNotBlank()) { "اسم المستأجر مطلوب" }; validateMoney(item.amount,"القيمة الإيجارية")
        val db=writableDatabase
        val old=db.rawQuery("SELECT tenant,amount,property,unit_code,description,address,template_id,notes FROM aggregate_receipt_items WHERE id=? AND statement_id=?",arrayOf(item.id.toString(),item.statementId.toString())).use{c->if(c.moveToFirst())(0..7).map{c.getString(it)?:""} else null}
        require(old!=null) { "صف الكشف غير موجود" }
        val fresh=listOf(item.tenant.trim(),item.amount.toString(),item.property,item.unitCode,item.description,item.address,item.templateId,item.notes)
        db.update("aggregate_receipt_items",ContentValues().apply{put("tenant",fresh[0]);put("amount",item.amount);put("property",item.property);put("unit_code",item.unitCode);put("description",item.description);put("address",item.address);put("template_id",item.templateId);put("notes",item.notes)},"id=? AND statement_id=?",arrayOf(item.id.toString(),item.statementId.toString()))
        listOf("tenant","amount","property","unit_code","description","address","template_id","notes").forEachIndexed{i,f->if(old[i]!=fresh[i])recordAudit(db,"aggregate_receipt_items",item.id.toString(),f,old[i],fresh[i],"تعديل صف كشف مجمع") }
    }
    @Synchronized fun deleteAggregateReceiptItem(statementId:Long,itemId:Long) {
        val db=writableDatabase
        val name=db.rawQuery("SELECT tenant FROM aggregate_receipt_items WHERE id=? AND statement_id=?",arrayOf(itemId.toString(),statementId.toString())).use{if(it.moveToFirst())it.getString(0) else null}
        require(name!=null) { "صف الكشف غير موجود" }; db.delete("aggregate_receipt_items","id=? AND statement_id=?",arrayOf(itemId.toString(),statementId.toString()))
        recordAudit(db,"aggregate_receipt_items",itemId.toString(),"record",name,null,"حذف صف من كشف مجمع")
    }

    @Synchronized fun createMonthlyCollectionBatch(period:String, issuedDate:String, selectedUnitIds:Set<Long>, propertyFilter:String=""):Long {
        validatePeriod(period); try{java.time.LocalDate.parse(issuedDate)}catch(_:Exception){throw IllegalArgumentException("تاريخ إصدار الإيصالات يجب أن يكون YYYY-MM-DD")}; require(selectedUnitIds.isNotEmpty()) { "اختر وحدة واحدة على الأقل" }
        val db=writableDatabase; db.beginTransaction()
        try {
            val allUnits = units()
            val selectedById = allUnits.filter { it.id in selectedUnitIds }.associateBy { it.id }
            val missingIds = selectedUnitIds - selectedById.keys
            // Receipt preparation/export is independent from the unit's collection status.
            // Only reject IDs that no longer exist; do not require status approval here.
            if (missingIds.isNotEmpty()) {
                throw IllegalArgumentException("تعذر تجهيز الإيصالات لأن بعض الوحدات لم تعد موجودة: ${missingIds.joinToString()}")
            }
            val selected = selectedById.values.toList()
            // Block an accidental duplicate when the same period/property and exact unit set already exists.
            db.rawQuery("SELECT id FROM monthly_collection_batches WHERE period=? AND property_filter=? ORDER BY id DESC",arrayOf(period,propertyFilter)).use { c ->
                while(c.moveToNext()) {
                    val existingId=c.getLong(0)
                    val existing=db.rawQuery("SELECT unit_id FROM monthly_collection_items WHERE batch_id=? ORDER BY unit_id",arrayOf(existingId.toString())).use { q -> buildSet { while(q.moveToNext()) add(q.getLong(0)) } }
                    if(existing==selectedUnitIds) throw IllegalArgumentException("توجد دفعة محفوظة بالفعل للفترة والعقار والوحدات نفسها (رقم ${existingId}). افتح الدفعة السابقة بدل إنشاء نسخة مكررة.")
                }
            }
            val monthName=try{java.time.YearMonth.parse(period).month.getDisplayName(java.time.format.TextStyle.FULL,java.util.Locale("ar"))}catch(_:Exception){period.substring(5,7)}
            val title="${if(propertyFilter.isBlank())"" else "$propertyFilter – "}كشف التحصيل لشهر $monthName سنة ${period.substring(0,4)}"
            val batchId=db.insertOrThrow("monthly_collection_batches",null,ContentValues().apply {
                put("period",period);put("issued_date",issuedDate);put("title",title);put("property_filter",propertyFilter);put("created_at",System.currentTimeMillis());put("status","prepared")
            })
            selected.forEach { u -> db.insertOrThrow("monthly_collection_items",null,ContentValues().apply {
                put("batch_id",batchId);put("unit_id",u.id);put("unit_code",u.code);put("property",u.property);put("tenant",u.tenant)
                if(u.rent==null)putNull("amount") else put("amount",u.rent)
                put("receipt_no", "COL-${period.replace("-","")}-${batchId}-${u.id}")
                put("collection_status","not_recorded")
            }) }
            db.setTransactionSuccessful(); return batchId
        } finally { db.endTransaction() }
    }

    @Synchronized fun monthlyBatches():List<MonthlyBatch> = readableDatabase.rawQuery(
        "SELECT b.id,b.period,b.title,b.property_filter,b.created_at,(SELECT COUNT(*) FROM monthly_collection_items i WHERE i.batch_id=b.id) FROM monthly_collection_batches b ORDER BY b.created_at DESC",null
    ).use { c->buildList { while(c.moveToNext()) add(MonthlyBatch(c.getLong(0),c.getString(1),c.getString(2),c.getString(3),c.getLong(4),c.getInt(5))) } }

    @Synchronized fun monthlyBatchReceipts(batchId:Long):List<ReceiptRecord> = readableDatabase.rawQuery(
        "SELECT i.id,i.receipt_no,i.unit_id,i.unit_code,i.tenant,i.property,i.amount,b.issued_date,b.period,COALESCE(i.template_id,''),i.notes,'draft' FROM monthly_collection_items i JOIN monthly_collection_batches b ON b.id=i.batch_id WHERE i.batch_id=? ORDER BY i.property,i.unit_code",arrayOf(batchId.toString())
    ).use { c->buildList { while(c.moveToNext()) add(ReceiptRecord(c.getLong(0),c.getString(1),c.getLong(2),c.getString(3),c.getString(4),c.getString(5),if(c.isNull(6))null else c.getDouble(6),c.getString(7),c.getString(8),c.getString(9),c.getString(10),c.getString(11))) } }

    @Synchronized fun updateMonthlyCollectionReceiptTemplate(itemId: Long, templateId: String) {
        require(templateId.isNotBlank() && templateId.length <= 32) { "نموذج الإيصال غير صالح" }
        val changed = writableDatabase.update("monthly_collection_items", ContentValues().apply { put("template_id", templateId) }, "id=?", arrayOf(itemId.toString()))
        require(changed == 1) { "لم يتم العثور على إيصال الدفعة" }
    }

    @Synchronized fun updateMonthlyCollectionResult(itemId:Long,status:String,resultAmount:Double?,resultDate:String,notes:String) {
        require(status in setOf("not_recorded","paid","partial","unpaid","unreachable")) { "حالة التحصيل غير صحيحة" }
        require(resultAmount==null || (resultAmount.isFinite() && resultAmount>=0)) { "مبلغ التحصيل غير صحيح" }
        if(resultDate.isNotBlank()) try { java.time.LocalDate.parse(resultDate) } catch(_:Exception) { throw IllegalArgumentException("تاريخ التحصيل يجب أن يكون YYYY-MM-DD") }
        if(status=="paid" || status=="partial") require(resultAmount!=null && resultAmount>0) { "أدخل المبلغ الذي حصّله المحصّل فعلًا" }
        if(status=="not_recorded" || status=="unpaid" || status=="unreachable") require(resultAmount==null || resultAmount==0.0) { "لا تسجل مبلغًا لحالة غير محصلة" }
        val changed=writableDatabase.update("monthly_collection_items",ContentValues().apply { put("collection_status",status);if(resultAmount==null)putNull("result_amount") else put("result_amount",resultAmount);put("result_date",resultDate);put("notes",notes) },"id=?",arrayOf(itemId.toString()))
        require(changed==1) { "لم يتم العثور على بند التحصيل" }
        // Intentionally no receipt/ledger write here: collector result is recorded separately for later review.
    }

    @Synchronized fun monthlyBatchItems(batchId:Long):List<Array<String>> = readableDatabase.rawQuery(
        "SELECT id,unit_code,property,tenant,COALESCE(CAST(amount AS TEXT),''),collection_status,COALESCE(CAST(result_amount AS TEXT),''),COALESCE(result_date,''),notes FROM monthly_collection_items WHERE batch_id=? ORDER BY property,unit_code",arrayOf(batchId.toString())
    ).use { c->buildList { while(c.moveToNext()) add(Array(9){i->c.getString(i)?:""}) } }

    @Synchronized fun personalMonthId(year:Int,month:Int):Long {
        require(year in 2000..2200 && month in 1..12)
        val db=writableDatabase
        db.beginTransaction()
        try {
            db.rawQuery("SELECT id FROM personal_rent_months WHERE year=? AND month=?",arrayOf(year.toString(),month.toString())).use{if(it.moveToFirst()){db.setTransactionSuccessful();return it.getLong(0)}}
            val id=db.insertOrThrow("personal_rent_months",null,ContentValues().apply{put("year",year);put("month",month);put("created_at",System.currentTimeMillis())})
            val templates = db.rawQuery("SELECT tenant,total,daughter,son FROM personal_rent_templates WHERE active=1 ORDER BY id", null).use { c ->
                buildList { while(c.moveToNext()) add(arrayOf(c.getString(0), c.getDouble(1).toString(), c.getDouble(2).toString(), c.getDouble(3).toString())) }
            }
            if (templates.isEmpty()) for(i in 1..15) db.insertOrThrow("personal_rent_rows",null,ContentValues().apply{put("month_id",id);put("row_no",i)})
            else templates.forEachIndexed { index, row -> db.insertOrThrow("personal_rent_rows",null,ContentValues().apply {
                put("month_id",id); put("row_no",index+1); put("tenant",row[0]); put("total",row[1].toDouble()); put("daughter",row[2].toDouble()); put("son",row[3].toDouble())
            }) }
            for(i in 1..5) db.insertOrThrow("personal_rent_deductions",null,ContentValues().apply { put("month_id",id);put("row_no",i) })
            db.setTransactionSuccessful()
            return id
        } finally { db.endTransaction() }
    }

    @Synchronized fun personalRows(monthId:Long):List<Array<String>> = readableDatabase.rawQuery(
        "SELECT row_no,tenant,total,daughter,son,notes,collected FROM personal_rent_rows WHERE month_id=? ORDER BY row_no",arrayOf(monthId.toString())
    ).use{c->buildList{while(c.moveToNext())add(Array(7){i->c.getString(i)?:""})}}

    @Synchronized fun savePersonalRow(monthId:Long,rowNo:Int,tenant:String,total:Double,daughter:Double,son:Double,notes:String) {
        require(monthId>0 && rowNo>0 && listOf(total,daughter,son).all{it.isFinite()&&it>=0})
        require(listOf(total,daughter,son).all { kotlin.math.abs(it*100.0-kotlin.math.round(it*100.0))<0.000001 }) { "المبالغ لا تقبل أكثر من منزلتين عشريتين" }
        val db=writableDatabase
        val old=db.rawQuery("SELECT id,tenant,total,daughter,son,notes FROM personal_rent_rows WHERE month_id=? AND row_no=?",arrayOf(monthId.toString(),rowNo.toString())).use { c -> if(c.moveToFirst()) (0..5).map { c.getString(it) ?: "" } else null }
        require(old!=null) { "لم يتم العثور على سطر الدفتر المطلوب" }
        val changed=db.update("personal_rent_rows",ContentValues().apply{put("tenant",tenant.trim());put("total",total);put("daughter",daughter);put("son",son);put("notes",notes)},"month_id=? AND row_no=?",arrayOf(monthId.toString(),rowNo.toString()))
        require(changed==1) { "لم يتم العثور على سطر الدفتر المطلوب" }
        val fields=listOf("tenant","total","daughter","son","notes")
        val fresh=listOf(tenant.trim(),total.toString(),daughter.toString(),son.toString(),notes)
        fields.forEachIndexed { index,field -> if(old[index+1]!=fresh[index]) recordAudit(db,"personal_rent_rows",old[0],field,old[index+1],fresh[index],"تعديل دفتر دفتري للشهر $monthId") }
    }

    @Synchronized fun addPersonalRow(monthId:Long):Int {
        require(monthId>0)
        val db=writableDatabase
        val next=db.rawQuery("SELECT COALESCE(MAX(row_no),0)+1 FROM personal_rent_rows WHERE month_id=?",arrayOf(monthId.toString())).use { if(it.moveToFirst()) it.getInt(0) else 1 }
        db.insertOrThrow("personal_rent_rows",null,ContentValues().apply { put("month_id",monthId);put("row_no",next) })
        return next
    }

    @Synchronized fun setPersonalCollected(monthId:Long,rowNo:Int,collected:Boolean) {
        val changed=writableDatabase.update("personal_rent_rows",ContentValues().apply { put("collected",if(collected)1 else 0) },"month_id=? AND row_no=?",arrayOf(monthId.toString(),rowNo.toString()))
        require(changed==1) { "لم يتم العثور على سطر الدفتر" }
    }

    @Synchronized fun applyPersonalTemplatesIfEmpty(monthId:Long):Boolean {
        val db=writableDatabase
        val hasData=db.rawQuery("SELECT COUNT(*) FROM personal_rent_rows WHERE month_id=? AND (TRIM(tenant)<>'' OR total<>0 OR daughter<>0 OR son<>0 OR collected<>0)",arrayOf(monthId.toString())).use { it.moveToFirst() && it.getInt(0)>0 }
        if(hasData) return false
        val templates=db.rawQuery("SELECT tenant,total,daughter,son FROM personal_rent_templates WHERE active=1 ORDER BY id",null).use { c -> buildList { while(c.moveToNext()) add(arrayOf(c.getString(0),c.getDouble(1).toString(),c.getDouble(2).toString(),c.getDouble(3).toString())) } }
        if(templates.isEmpty()) return false
        db.beginTransaction()
        try {
            db.delete("personal_rent_rows","month_id=?",arrayOf(monthId.toString()))
            templates.forEachIndexed { index,row -> db.insertOrThrow("personal_rent_rows",null,ContentValues().apply { put("month_id",monthId);put("row_no",index+1);put("tenant",row[0]);put("total",row[1].toDouble());put("daughter",row[2].toDouble());put("son",row[3].toDouble()) }) }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
        return true
    }

    @Synchronized fun savePersonalTemplate(rowNo:Int,tenant:String,total:Double,daughter:Double,son:Double) {
        require(rowNo>0 && tenant.isNotBlank() && listOf(total,daughter,son).all { it.isFinite() && it>=0 })
        val db=writableDatabase
        val values=ContentValues().apply { put("tenant",tenant.trim());put("total",total);put("daughter",daughter);put("son",son);put("active",1);put("created_at",System.currentTimeMillis()) }
        val existingId=db.rawQuery("SELECT id FROM personal_rent_templates ORDER BY id LIMIT 1 OFFSET ?",arrayOf((rowNo-1).toString())).use { if(it.moveToFirst())it.getLong(0) else null }
        if(existingId==null) db.insertOrThrow("personal_rent_templates",null,values)
        else {
            val changed=db.update("personal_rent_templates",values,"id=?",arrayOf(existingId.toString()))
            require(changed==1) { "تعذر تحديث الاسم في القائمة المتكررة" }
        }
    }

    @Synchronized fun addPersonalExpense(monthId:Long,title:String,amount:Double,date:String,notes:String="") {
        require(title.isNotBlank() && amount.isFinite() && amount>=0)
        try { java.time.LocalDate.parse(date) } catch (_: Exception) { throw IllegalArgumentException("تاريخ المصروف يجب أن يكون YYYY-MM-DD") }
        require(kotlin.math.abs(amount * 100.0 - kotlin.math.round(amount * 100.0)) < 0.000001) { "المبلغ لا يقبل أكثر من منزلتين عشريتين" }
        val db=writableDatabase
        val id=db.insertOrThrow("personal_rent_expenses",null,ContentValues().apply{put("month_id",monthId);put("title",title.trim());put("amount",amount);put("expense_date",date);put("notes",notes)})
        recordAudit(db,"personal_rent_expenses",id.toString(),"record",null,"إضافة مصروف","إضافة مصروف إلى دفتر الإيجارات")
    }
    @Synchronized fun updatePersonalExpense(id:Long,title:String,amount:Double,date:String,notes:String="") {
        require(id>0 && title.isNotBlank() && amount.isFinite() && amount>=0)
        try { java.time.LocalDate.parse(date) } catch (_: Exception) { throw IllegalArgumentException("تاريخ المصروف يجب أن يكون YYYY-MM-DD") }
        require(kotlin.math.abs(amount * 100.0 - kotlin.math.round(amount * 100.0)) < 0.000001) { "المبلغ لا يقبل أكثر من منزلتين عشريتين" }
        val db=writableDatabase
        val old=db.rawQuery("SELECT title,amount,expense_date,COALESCE(notes,'') FROM personal_rent_expenses WHERE id=?",arrayOf(id.toString())).use{if(it.moveToFirst())(0..3).map{c->it.getString(c)}else null}
        require(old!=null) { "لم يتم العثور على المصروف المطلوب تعديله" }
        val fresh=listOf(title.trim(),amount.toString(),date,notes)
        val changed=db.update("personal_rent_expenses",ContentValues().apply{put("title",title.trim());put("amount",amount);put("expense_date",date);put("notes",notes)},"id=?",arrayOf(id.toString()))
        require(changed==1) { "لم يتم العثور على المصروف المطلوب تعديله" }
        listOf("title","amount","expense_date","notes").forEachIndexed{idx,field->if(old[idx]!=fresh[idx])recordAudit(db,"personal_rent_expenses",id.toString(),field,old[idx],fresh[idx],"تعديل مصروف دفتر الإيجارات")}
    }
    @Synchronized fun deletePersonalExpense(id:Long) = moveToTrash("personal_rent_expenses", id, "حذف مصروف دفتر الإيجارات")
    @Synchronized fun personalDeductions(monthId:Long):List<Array<String>> {
        val db=writableDatabase
        val count=db.rawQuery("SELECT COUNT(*) FROM personal_rent_deductions WHERE month_id=?",arrayOf(monthId.toString())).use { if(it.moveToFirst())it.getInt(0) else 0 }
        if(count==0) for(i in 1..5) db.insertOrThrow("personal_rent_deductions",null,ContentValues().apply { put("month_id",monthId);put("row_no",i) })
        return db.rawQuery("SELECT row_no,title,amount,notes FROM personal_rent_deductions WHERE month_id=? ORDER BY row_no",arrayOf(monthId.toString())).use { c -> buildList { while(c.moveToNext()) add(Array(4){i->c.getString(i)?:""}) } }
    }

    @Synchronized fun savePersonalDeduction(monthId:Long,rowNo:Int,title:String,amount:Double,notes:String) {
        require(monthId>0 && rowNo>0 && amount.isFinite() && amount>=0 && kotlin.math.abs(amount*100.0-kotlin.math.round(amount*100.0))<0.000001)
        val changed=writableDatabase.update("personal_rent_deductions",ContentValues().apply { put("title",title.trim());put("amount",amount);put("notes",notes) },"month_id=? AND row_no=?",arrayOf(monthId.toString(),rowNo.toString()))
        require(changed==1) { "لم يتم العثور على بند الخصم" }
    }

    @Synchronized fun addPersonalDeduction(monthId:Long):Int {
        val db=writableDatabase
        val next=db.rawQuery("SELECT COALESCE(MAX(row_no),0)+1 FROM personal_rent_deductions WHERE month_id=?",arrayOf(monthId.toString())).use { if(it.moveToFirst())it.getInt(0) else 1 }
        db.insertOrThrow("personal_rent_deductions",null,ContentValues().apply { put("month_id",monthId);put("row_no",next) })
        return next
    }

    @Synchronized fun personalAnnualSummary(year:Int):List<Array<String>> {
        require(year in 2000..2200)
        return (1..12).map { month ->
            val values=readableDatabase.rawQuery("""SELECT ?,
                COALESCE((SELECT SUM(r.total) FROM personal_rent_rows r JOIN personal_rent_months m ON m.id=r.month_id WHERE m.year=? AND m.month=?),0),
                COALESCE((SELECT SUM(e.amount) FROM personal_rent_expenses e JOIN personal_rent_months m ON m.id=e.month_id WHERE m.year=? AND m.month=?),0)""",
                arrayOf(month.toString(),year.toString(),month.toString(),year.toString(),month.toString())).use { c ->
                if(c.moveToFirst()) Array(3){i->c.getString(i)?:"0"} else arrayOf(month.toString(),"0","0")
            }
            values
        }
    }
    @Synchronized fun personalExpenses(monthId:Long):List<Array<String>> = readableDatabase.rawQuery(
        "SELECT id,title,amount,expense_date,notes FROM personal_rent_expenses WHERE month_id=? ORDER BY id",arrayOf(monthId.toString())
    ).use{c->buildList{while(c.moveToNext())add(Array(5){i->c.getString(i)?:""})}}

    @Synchronized fun copyPersonalNames(sourceMonthId:Long,targetYear:Int,targetMonth:Int):Long {
        val target=personalMonthId(targetYear,targetMonth); val db=writableDatabase
        db.beginTransaction();try{db.execSQL("UPDATE personal_rent_rows SET tenant=COALESCE((SELECT s.tenant FROM personal_rent_rows s WHERE s.month_id=? AND s.row_no=personal_rent_rows.row_no),tenant) WHERE month_id=? AND (tenant IS NULL OR TRIM(tenant)='')",arrayOf(sourceMonthId,target));db.setTransactionSuccessful()}finally{db.endTransaction()};return target
    }

    data class EntityCounts(val properties:Int, val tenants:Int, val linkedUnits:Int, val linkedLeases:Int)

    @Synchronized fun properties(): List<PropertyRecord> = readableDatabase.rawQuery(
        "SELECT p.id,p.name,COALESCE(p.address,''),COALESCE(p.notes,''),p.created_at,(SELECT COUNT(*) FROM units u WHERE u.property_id=p.id) FROM properties p ORDER BY p.name", null
    ).use { c -> buildList { while(c.moveToNext()) add(PropertyRecord(c.getLong(0),c.getString(1),c.getString(2),c.getString(3),c.getLong(4),c.getInt(5))) } }

    @Synchronized fun tenants(): List<TenantRecord> = readableDatabase.rawQuery(
        "SELECT t.id,t.name,COALESCE(t.phone,''),COALESCE(t.notes,''),t.created_at,(SELECT COUNT(*) FROM units u WHERE u.tenant_id=t.id),(SELECT COUNT(*) FROM leases l WHERE l.tenant_id=t.id) FROM tenants t ORDER BY t.name,t.id", null
    ).use { c -> buildList { while(c.moveToNext()) add(TenantRecord(c.getLong(0),c.getString(1),c.getString(2),c.getString(3),c.getLong(4),c.getInt(5),c.getInt(6))) } }

    @Synchronized fun saveProperty(item:PropertyRecord):Long {
        val name=item.name.trim(); require(name.isNotBlank()) { "اسم العقار مطلوب" }
        val db=writableDatabase; val v=ContentValues().apply { put("name",name);put("address",item.address.trim());put("notes",item.notes.trim()) }
        if(item.id>0) {
            val old=db.rawQuery("SELECT name,COALESCE(address,''),COALESCE(notes,'') FROM properties WHERE id=?",arrayOf(item.id.toString())).use{if(it.moveToFirst())(0..2).map{c->it.getString(c)}else null}
            require(old!=null) { "العقار غير موجود" }
            db.update("properties",v,"id=?",arrayOf(item.id.toString()))
            listOf("name" to name,"address" to item.address.trim(),"notes" to item.notes.trim()).forEachIndexed{idx,p->if(old[idx]!=p.second)recordAudit(db,"properties",item.id.toString(),p.first,old[idx],p.second,"تعديل بيانات العقار")}
            db.update("units",ContentValues().apply{put("property",name)},"property_id=?",arrayOf(item.id.toString()))
            return item.id
        }
        v.put("created_at",System.currentTimeMillis()); val id=db.insertOrThrow("properties",null,v);recordAudit(db,"properties",id.toString(),"record",null,"إنشاء عقار","إضافة سجل جديد");return id
    }

    @Synchronized fun saveTenant(item:TenantRecord):Long {
        val name=item.name.trim(); require(name.isNotBlank()) { "اسم المستأجر مطلوب" }
        val db=writableDatabase; val v=ContentValues().apply { put("name",name);put("phone",item.phone.trim());put("notes",item.notes.trim()) }
        if(item.id>0) {
            val oldName=db.rawQuery("SELECT name FROM tenants WHERE id=?",arrayOf(item.id.toString())).use{if(it.moveToFirst())it.getString(0) else null}
            require(oldName!=null) { "المستأجر غير موجود" }
            if(oldName!=name) {
                val linked=db.rawQuery("SELECT COUNT(*) FROM units WHERE tenant_id=?",arrayOf(item.id.toString())).use{it.moveToFirst()&&it.getInt(0)>0}
                require(!linked) { "هذا المستأجر مرتبط بوحدة حالية؛ غيّر المستأجر من بطاقة الوحدة حتى تُحفظ دورة التغيير والإيصالات دون فقد التاريخ" }
            }
            val old=db.rawQuery("SELECT name,COALESCE(phone,''),COALESCE(notes,'') FROM tenants WHERE id=?",arrayOf(item.id.toString())).use{if(it.moveToFirst())(0..2).map{c->it.getString(c)}else null}
            db.update("tenants",v,"id=?",arrayOf(item.id.toString()))
            listOf("name" to name,"phone" to item.phone.trim(),"notes" to item.notes.trim()).forEachIndexed{idx,p->if(old!=null&&old[idx]!=p.second)recordAudit(db,"tenants",item.id.toString(),p.first,old[idx],p.second,"تعديل بيانات المستأجر")}
            return item.id
        }
        v.put("created_at",System.currentTimeMillis()); val id=db.insertOrThrow("tenants",null,v);recordAudit(db,"tenants",id.toString(),"record",null,"إنشاء مستأجر","إضافة سجل جديد");return id
    }

    @Synchronized fun deleteProperty(id:Long) = moveToTrash("properties", id, "حذف عقار")

    @Synchronized fun deleteTenant(id:Long) = moveToTrash("tenants", id, "حذف مستأجر")

    data class TrashEntry(val id:Long, val tableName:String, val recordId:String, val deletedAt:Long, val summary:String)
    data class AuditEntry(val id:Long, val recordType:String, val recordId:String, val fieldName:String, val oldValue:String, val newValue:String, val reason:String, val createdAt:Long)

    private fun recordAudit(db:SQLiteDatabase, type:String, id:String, field:String, old:String?, fresh:String?, reason:String) {
        db.execSQL("INSERT INTO audit_log(record_type,record_id,field_name,old_value,new_value,reason,created_at) VALUES(?,?,?,?,?,?,?)",arrayOf(type,id,field,old,fresh,reason,System.currentTimeMillis()))
    }

    private fun createRecoveryTables(db:SQLiteDatabase) {
        db.execSQL("""CREATE TABLE IF NOT EXISTS trash_bin(
            id INTEGER PRIMARY KEY AUTOINCREMENT, table_name TEXT NOT NULL, record_id TEXT NOT NULL,
            snapshot_json TEXT NOT NULL, deleted_at INTEGER NOT NULL, reason TEXT NOT NULL DEFAULT '',
            UNIQUE(table_name,record_id))""")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_trash_deleted_at ON trash_bin(deleted_at DESC)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_audit_record_time ON audit_log(record_type,record_id,created_at DESC)")
    }

    private fun allowedTrashTable(table:String):Boolean = table in setOf(
        "properties","tenants","leases","attachments","personal_rent_expenses"
    )

    /** Snapshot + audit + delete are atomic. The attachment's physical file is deliberately retained. */
    @Synchronized fun moveToTrash(table:String, id:Long, reason:String="حذف من التطبيق") {
        require(id>0 && allowedTrashTable(table)) { "نوع السجل غير مسموح بنقله إلى سلة المحذوفات" }
        val db=writableDatabase
        db.beginTransaction()
        try {
            val snapshot=JSONObject()
            db.rawQuery("SELECT * FROM $table WHERE id=?", arrayOf(id.toString())).use { c ->
                require(c.moveToFirst()) { "السجل غير موجود أو سبق حذفه" }
                for(i in 0 until c.columnCount) {
                    val key=c.getColumnName(i)
                    when(c.getType(i)) {
                        android.database.Cursor.FIELD_TYPE_NULL -> snapshot.put(key, JSONObject.NULL)
                        android.database.Cursor.FIELD_TYPE_INTEGER -> snapshot.put(key,c.getLong(i))
                        android.database.Cursor.FIELD_TYPE_FLOAT -> snapshot.put(key,c.getDouble(i))
                        else -> snapshot.put(key,c.getString(i))
                    }
                }
            }
            if(table=="properties") {
                val linked=db.rawQuery("SELECT COUNT(*) FROM units WHERE property_id=?",arrayOf(id.toString())).use{it.moveToFirst()&&it.getInt(0)>0}
                require(!linked) { "لا يمكن حذف عقار مرتبط بوحدات؛ احتفظ بسجله أو انقل الوحدات أولًا" }
            }
            if(table=="tenants") {
                val linked=db.rawQuery("SELECT (SELECT COUNT(*) FROM units WHERE tenant_id=?)+(SELECT COUNT(*) FROM leases WHERE tenant_id=?)",arrayOf(id.toString(),id.toString())).use{it.moveToFirst()&&it.getInt(0)>0}
                require(!linked) { "لا يمكن حذف مستأجر مرتبط بوحدة أو عقد؛ احتفظ بسجله التاريخي" }
            }
            db.insertOrThrow("trash_bin",null,ContentValues().apply {
                put("table_name",table); put("record_id",id.toString()); put("snapshot_json",snapshot.toString())
                put("deleted_at",System.currentTimeMillis()); put("reason",reason)
            })
            val changed=db.delete(table,"id=?",arrayOf(id.toString()))
            require(changed==1) { "تعذر نقل السجل إلى سلة المحذوفات" }
            db.execSQL("INSERT INTO audit_log(record_type,record_id,field_name,old_value,new_value,reason,created_at) VALUES(?,?, 'deleted', 'active', 'trash', ?, ?)",arrayOf(table,id.toString(),reason,System.currentTimeMillis()))
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    @Synchronized fun trashEntries():List<TrashEntry> = readableDatabase.rawQuery(
        "SELECT id,table_name,record_id,deleted_at,reason FROM trash_bin ORDER BY deleted_at DESC,id DESC",null
    ).use { c -> buildList { while(c.moveToNext()) add(TrashEntry(c.getLong(0),c.getString(1),c.getString(2),c.getLong(3),c.getString(4))) } }

    /** Restores the exact primary key and original column values; on any constraint conflict the trash item remains untouched. */
    @Synchronized fun restoreFromTrash(trashId:Long) {
        require(trashId>0)
        val db=writableDatabase
        db.beginTransaction()
        try {
            val row=db.rawQuery("SELECT table_name,record_id,snapshot_json FROM trash_bin WHERE id=?",arrayOf(trashId.toString())).use { c ->
                require(c.moveToFirst()) { "عنصر سلة المحذوفات غير موجود" }
                Triple(c.getString(0),c.getString(1),c.getString(2))
            }
            val table=row.first; val recordId=row.second; val json=row.third
            require(allowedTrashTable(table)) { "نوع السجل غير معروف؛ لم يتم حذف النسخة المحفوظة" }
            val obj=JSONObject(json); val values=ContentValues()
            val keys=obj.keys()
            while(keys.hasNext()) {
                val key=keys.next(); val value=obj.get(key)
                when {
                    value===JSONObject.NULL -> values.putNull(key)
                    value is Boolean -> values.put(key,if(value) 1 else 0)
                    value is Int -> values.put(key,value)
                    value is Long -> values.put(key,value)
                    value is Number -> values.put(key,value.toDouble())
                    else -> values.put(key,value.toString())
                }
            }
            require(values.containsKey("id") && values.getAsString("id")==recordId) { "نسخة الاستعادة غير متطابقة؛ تم الاحتفاظ بها في السلة" }
            db.insertOrThrow(table,null,values)
            db.delete("trash_bin","id=?",arrayOf(trashId.toString()))
            db.execSQL("INSERT INTO audit_log(record_type,record_id,field_name,old_value,new_value,reason,created_at) VALUES(?,?, 'deleted', 'trash', 'restored', ?, ?)",arrayOf(table,recordId,"استعادة من سلة المحذوفات",System.currentTimeMillis()))
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    @Synchronized fun auditHistory(recordType:String?=null, recordId:String?=null, limit:Int=500):List<AuditEntry> {
        require(limit in 1..5000)
        val clauses=mutableListOf<String>(); val args=mutableListOf<String>()
        if(!recordType.isNullOrBlank()){clauses+="record_type=?";args+=recordType}
        if(!recordId.isNullOrBlank()){clauses+="record_id=?";args+=recordId}
        val where=if(clauses.isEmpty()) "" else " WHERE "+clauses.joinToString(" AND ")
        args+=limit.toString()
        return readableDatabase.rawQuery("SELECT id,COALESCE(record_type,''),COALESCE(record_id,''),COALESCE(field_name,''),COALESCE(old_value,''),COALESCE(new_value,''),COALESCE(reason,''),created_at FROM audit_log$where ORDER BY created_at DESC,id DESC LIMIT ?",args.toTypedArray()).use { c ->
            buildList { while(c.moveToNext()) add(AuditEntry(c.getLong(0),c.getString(1),c.getString(2),c.getString(3),c.getString(4),c.getString(5),c.getString(6),c.getLong(7))) }
        }
    }

    private fun findOrCreateProperty(db:SQLiteDatabase,nameRaw:String):Long? {
        val name=nameRaw.trim(); if(name.isBlank()) return null
        db.rawQuery("SELECT id FROM properties WHERE name=?",arrayOf(name)).use{if(it.moveToFirst())return it.getLong(0)}
        return db.insertOrThrow("properties",null,ContentValues().apply{put("name",name);put("created_at",System.currentTimeMillis())})
    }
    private fun findOrCreateTenant(db:SQLiteDatabase,nameRaw:String):Long? {
        val name=nameRaw.trim(); if(name.isBlank()) return null
        db.rawQuery("SELECT id FROM tenants WHERE name=? ORDER BY id LIMIT 1",arrayOf(name)).use{if(it.moveToFirst())return it.getLong(0)}
        return db.insertOrThrow("tenants",null,ContentValues().apply{put("name",name);put("created_at",System.currentTimeMillis())})
    }

    @Synchronized fun units(query: String = ""): List<UnitRecord> {
        val db=readableDatabase
        val c= if(query.isBlank()) db.rawQuery("SELECT id,code,property,tenant,unit_type,rent,status,description,notes,updated_at FROM units ORDER BY property,tenant",null)
        else db.rawQuery("SELECT id,code,property,tenant,unit_type,rent,status,description,notes,updated_at FROM units WHERE tenant LIKE ? OR property LIKE ? OR code LIKE ? ORDER BY property,tenant", arrayOf("%$query%","%$query%","%$query%"))
        val out= mutableListOf<UnitRecord>(); c.use { while(it.moveToNext()) out += UnitRecord(it.getLong(0),it.getString(1)?:"",it.getString(2)?:"",it.getString(3)?:"",it.getString(4)?:"غير محدد",if(it.isNull(5)) null else it.getDouble(5),it.getString(6)?:"نشطة",it.getString(7)?:"",it.getString(8)?:"",it.getLong(9)) }; return out
    }
    @Synchronized fun saveUnit(unit: UnitRecord, reason: String = "تعديل من التطبيق"): Long {
        require(unit.rent == null || (unit.rent.isFinite() && unit.rent >= 0.0)) { "القيمة الإيجارية يجب أن تكون فارغة أو رقمًا غير سالب" }
        val db=writableDatabase; db.beginTransaction()
        try {
            val old = if(unit.id>0) db.rawQuery("SELECT code,property,tenant,unit_type,rent,status,description,notes FROM units WHERE id=?", arrayOf(unit.id.toString())).use { if(it.moveToFirst()) (0..7).map { i -> if(it.isNull(i)) "" else it.getString(i) } else null } else null
            val effectiveCode=unit.code.ifBlank { "LOCAL-${System.currentTimeMillis()}" }
            val tenantChangedBeforeSave = old != null && old[2] != unit.tenant
            val savedStatus = if (tenantChangedBeforeSave && unit.status.contains("تغيير مستأجر")) "نشطة" else unit.status
            val propertyId=findOrCreateProperty(db,unit.property)
            val tenantId=findOrCreateTenant(db,unit.tenant)
            val v=ContentValues().apply { put("code",effectiveCode);put("property",unit.property);put("tenant",unit.tenant);if(propertyId==null)putNull("property_id")else put("property_id",propertyId);if(tenantId==null)putNull("tenant_id")else put("tenant_id",tenantId);put("unit_type",unit.unitType);if(unit.rent==null) putNull("rent") else put("rent",unit.rent);put("status",savedStatus);put("description",unit.description);put("notes",unit.notes);put("updated_at",System.currentTimeMillis()) }
            val id=if(unit.id>0){db.update("units",v,"id=?",arrayOf(unit.id.toString()));unit.id}else db.insertOrThrow("units",null,v)
            val fields=listOf("code","property","tenant","unit_type","rent","status","description","notes")
            if(old!=null) fields.forEachIndexed { i,f -> val nv=listOf(unit.code,unit.property,unit.tenant,unit.unitType,unit.rent?.toString() ?: "",savedStatus,unit.description,unit.notes)[i]; if(old[i]!=nv) db.execSQL("INSERT INTO audit_log(record_type,record_id,field_name,old_value,new_value,reason,created_at) VALUES('unit',?,?,?,?,?,?)", arrayOf(effectiveCode,f,old[i],nv,reason,System.currentTimeMillis())) }
            else db.execSQL("INSERT INTO audit_log(record_type,record_id,field_name,old_value,new_value,reason,created_at) VALUES('unit',?,'record',NULL,?,?,?)",arrayOf(effectiveCode,"إنشاء سجل جديد",reason,System.currentTimeMillis()))
            val tenantChanged = old != null && old[2] != unit.tenant
            val wasClosed = old != null && isClosedOrStopped(old[5])
            val effectiveStatus = savedStatus
            val isClosed = isClosedOrStopped(effectiveStatus)
            val currentPeriod = java.time.YearMonth.now().toString()
            if (isClosed) {
                // Preserve paid/history records, but a sold/closed/stopped unit must not retain an actionable draft.
                db.execSQL("UPDATE receipts SET status='superseded' WHERE unit_id=? AND period=? AND status IN ('draft','pending_tenant_change')", arrayOf(id, currentPeriod))
            } else if (unit.status.contains("تغيير مستأجر") && !tenantChanged) {
                // The owner has flagged a tenant change but has not entered the new identity yet.
                db.execSQL("UPDATE receipts SET status='pending_tenant_change',notes=COALESCE(notes,'') || ? WHERE unit_id=? AND period=? AND status='draft'", arrayOf("\nمعلقة لحين إدخال بيانات المستأجر الجديد", id, currentPeriod))
            } else if (old == null || tenantChanged || wasClosed) {
                if (tenantChanged) {
                    // Keep the previous tenant's draft as a non-actionable audit record; create a fresh draft for the new tenant.
                    db.execSQL("UPDATE receipts SET status='superseded',notes=COALESCE(notes,'') || ? WHERE unit_id=? AND period=? AND status IN ('draft','pending_tenant_change')", arrayOf("\nمسودة سابقة قبل تغيير المستأجر بتاريخ ${java.time.LocalDate.now()}", id, currentPeriod))
                }
                ensureDraftReceipt(db, id, effectiveCode, unit.copy(status=effectiveStatus))
            } else {
                db.execSQL("UPDATE receipts SET unit_code=?,tenant=?,property=?,amount=?,notes=? WHERE unit_id=? AND period=? AND tenant=? AND status='draft'",
                    arrayOf(effectiveCode,unit.tenant,unit.property,unit.rent,unit.notes,id,currentPeriod,unit.tenant))
            }
            db.setTransactionSuccessful(); return id
        } finally { db.endTransaction() }
    }

    private fun ensureDraftReceipt(db: SQLiteDatabase, unitId: Long, code: String, unit: UnitRecord) {
        if (isClosedOrStopped(unit.status) || unit.status.contains("تغيير مستأجر")) return
        val period = java.time.YearMonth.now().toString()
        val alreadyPaid = db.rawQuery("SELECT id FROM receipts WHERE unit_id=? AND period=? AND tenant=? AND status='paid' LIMIT 1", arrayOf(unitId.toString(), period, unit.tenant)).use { it.moveToFirst() }
        if (alreadyPaid) return
        val exists = db.rawQuery("SELECT id FROM receipts WHERE unit_id=? AND period=? AND tenant=? AND status='draft' LIMIT 1", arrayOf(unitId.toString(), period, unit.tenant)).use { it.moveToFirst() }
        if (exists) {
            db.execSQL("UPDATE receipts SET unit_code=?,tenant=?,property=?,amount=?,notes=? WHERE unit_id=? AND period=? AND tenant=? AND status='draft'",
                arrayOf(code,unit.tenant,unit.property,unit.rent,unit.notes,unitId,period,unit.tenant))
        } else {
            db.insertOrThrow("receipts", null, ContentValues().apply {
                put("receipt_no", nextReceiptNo()); put("unit_id", unitId); put("unit_code", code)
                put("tenant", unit.tenant); put("property", unit.property); if (unit.rent == null) putNull("amount") else put("amount", unit.rent)
                put("paid_date", ""); put("period", period); put("template", "old")
                put("notes", unit.notes); putNull("ledger_id"); put("status", "draft"); put("created_at", System.currentTimeMillis())
            })
        }
    }

    private fun isClosedOrStopped(status: String): Boolean = collectionIneligibilityReason(status) != null

    @Synchronized fun importUnit(unit: UnitRecord) {
        val existing = if(unit.code.isNotBlank()) readableDatabase.rawQuery("SELECT id FROM units WHERE code=?", arrayOf(unit.code)).use { if(it.moveToFirst()) it.getLong(0) else 0L } else 0L
        saveUnit(unit.copy(id=existing), "استيراد من Excel")
    }

    /** Imports the whole reviewed unit batch atomically: one invalid/conflicting row rolls back every row. */
    @Synchronized fun importUnitsAtomically(units: List<UnitRecord>) {
        require(units.isNotEmpty()) { "لا توجد وحدات للاستيراد" }
        val codes = units.map { it.code.trim() }.filter { it.isNotBlank() }
        require(codes.size == codes.distinct().size) { "يوجد كود وحدة مكرر داخل ملف الاستيراد" }
        val db = writableDatabase
        db.beginTransaction()
        try {
            units.forEach { importUnit(it) }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }
    /** Read-only diagnostics; reports existing inconsistencies without changing historical data. */
    @Synchronized fun relationshipIntegrity(): Map<String, Int> {
        val db = readableDatabase
        fun count(sql: String): Int = db.rawQuery(sql, null).use { if (it.moveToFirst()) it.getInt(0) else 0 }
        return linkedMapOf(
            "orphanLeases" to count("SELECT COUNT(*) FROM leases l LEFT JOIN units u ON u.id=l.unit_id WHERE l.unit_id IS NOT NULL AND u.id IS NULL"),
            "orphanHeirPayouts" to count("SELECT COUNT(*) FROM heir_payouts p LEFT JOIN heirs h ON h.id=p.heir_id WHERE p.heir_id IS NOT NULL AND h.id IS NULL"),
            "orphanLeaseTenants" to count("SELECT COUNT(*) FROM leases l LEFT JOIN tenants t ON t.id=l.tenant_id WHERE l.tenant_id IS NOT NULL AND t.id IS NULL"),
            "orphanUnitProperties" to count("SELECT COUNT(*) FROM units u LEFT JOIN properties p ON p.id=u.property_id WHERE u.property_id IS NOT NULL AND p.id IS NULL"),
            "orphanUnitTenants" to count("SELECT COUNT(*) FROM units u LEFT JOIN tenants t ON t.id=u.tenant_id WHERE u.tenant_id IS NOT NULL AND t.id IS NULL"),
            "unlinkedUnitProperties" to count("SELECT COUNT(*) FROM units WHERE TRIM(COALESCE(property,''))<>'' AND property_id IS NULL"),
            "unlinkedUnitTenants" to count("SELECT COUNT(*) FROM units WHERE TRIM(COALESCE(tenant,''))<>'' AND tenant_id IS NULL"),
            "orphanReceiptUnits" to count("SELECT COUNT(*) FROM receipts r LEFT JOIN units u ON u.id=r.unit_id WHERE u.id IS NULL"),
            "brokenReceiptLedgerLinks" to count("SELECT COUNT(*) FROM receipts r LEFT JOIN ledger l ON l.id=r.ledger_id AND l.receipt_no=r.receipt_no WHERE r.ledger_id IS NOT NULL AND l.id IS NULL"),
            "duplicatePaidPeriods" to count("SELECT COUNT(*) FROM (SELECT unit_id,period,tenant FROM receipts WHERE status='paid' GROUP BY unit_id,period,tenant HAVING COUNT(*)>1)")
        )
    }

    fun counts(): Map<String,Int> {
        val db=readableDatabase
        fun count(table:String)=db.rawQuery("SELECT COUNT(*) FROM $table",null).use{if(it.moveToFirst())it.getInt(0)else 0}
        return mapOf("units" to count("units"),"ledger" to count("ledger"),"receipts" to count("receipts"),"expenses" to count("expenses"),"collections" to count("collection_batches"))
    }
    fun financeSummary(): Map<String,Double> {
        val db=readableDatabase
        fun sum(sql:String)=db.rawQuery(sql,null).use{if(it.moveToFirst())it.getDouble(0)else 0.0}
        return mapOf("due" to sum("SELECT COALESCE(SUM(debit-credit),0) FROM ledger"),"collected" to sum("SELECT COALESCE(SUM(credit),0) FROM ledger"),"expenses" to sum("SELECT COALESCE(SUM(amount),0) FROM expenses") + sum("SELECT COALESCE(SUM(expenses),0) FROM collection_batches"),"collectorHeld" to sum("SELECT COALESCE(SUM(balance),0) FROM collector_receivables"),"undistributed" to sum("SELECT COALESCE(SUM(remaining),0) FROM collection_batches WHERE period IS NOT NULL"),"unassignedLegacy" to sum("SELECT COALESCE(SUM(remaining),0) FROM collection_batches WHERE period IS NULL"),"unassignedLegacyExpenses" to sum("SELECT COALESCE(SUM(amount),0) FROM expenses WHERE period IS NULL"),"received" to sum("SELECT COALESCE(SUM(amount),0) FROM collection_batches"))
    }
    fun addLedger(unitCode:String,tenant:String,date:String,period:String,type:String,debit:Double,credit:Double,method:String,notes:String) {
        require((debit > 0.0) xor (credit > 0.0)) { "يجب أن يكون أحد طرفي القيد فقط موجبًا، دون قيم سالبة أو غير صالحة" }
        validateMoney(debit, "مدين", true); validateMoney(credit, "دائن", true)
        try { java.time.LocalDate.parse(date) } catch (_: Exception) { throw IllegalArgumentException("تاريخ القيد يجب أن يكون YYYY-MM-DD") }
        validatePeriod(period)
        writableDatabase.execSQL("INSERT INTO ledger(unit_code,tenant,entry_date,period,entry_type,debit,credit,collector_method,notes,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)",arrayOf(unitCode,tenant,date,period,type,debit,credit,method,notes,System.currentTimeMillis()))
    }
    fun addExpense(title:String,amount:Double,date:String,period:String,category:String,notes:String) {
        require(title.isNotBlank()) { "وصف المصروف مطلوب" }; validateMoney(amount, "المصروف")
        try { java.time.LocalDate.parse(date) } catch (_: Exception) { throw IllegalArgumentException("تاريخ المصروف يجب أن يكون YYYY-MM-DD") }
        validatePeriod(period)
        writableDatabase.execSQL("INSERT INTO expenses(title,amount,expense_date,period,category,notes) VALUES(?,?,?,?,?,?)",arrayOf(title,amount,date,period,category,notes))
    }
    fun addCollectorReceivable(collector:String,period:String,date:String,amount:Double,notes:String) {
        require(collector.isNotBlank()) { "اسم المحصّل مطلوب" }; validateMoney(amount, "التحصيل")
        try { java.time.LocalDate.parse(date) } catch (_: Exception) { throw IllegalArgumentException("تاريخ التحصيل يجب أن يكون YYYY-MM-DD") }
        validatePeriod(period)
        writableDatabase.execSQL("INSERT INTO collector_receivables(collector,period,collected_date,amount,handed_over,balance,notes) VALUES(?,?,?,?,0,?,?)",arrayOf(collector,period,date,amount,amount,notes))
    }
    fun handoverCollector(collector:String,date:String,amount:Double,method:String,expenses:Double,distributed:Double,period:String,notes:String) {
        require(collector.isNotBlank() && method.isNotBlank()) { "اسم المحصّل وطريقة الاستلام مطلوبان" }; validateMoney(amount, "المبلغ المستلم"); validateMoney(expenses, "المصروفات", true); validateMoney(distributed, "المبلغ الموزع", true); require(expenses+distributed<=amount + 0.000001) { "راجع اسم المحصّل وطريقة الاستلام والمبلغ والمصروفات والتوزيع؛ يجب ألا يتجاوز مجموع المصروفات والتوزيع المبلغ المستلم" }
        try { java.time.LocalDate.parse(date) } catch (_: Exception) { throw IllegalArgumentException("تاريخ الاستلام يجب أن يكون YYYY-MM-DD") }
        validatePeriod(period)
        val db=writableDatabase; db.beginTransaction()
        try {
            var remaining=amount
            val c=db.rawQuery("SELECT id,balance FROM collector_receivables WHERE collector=? AND period=? AND balance>0 ORDER BY id",arrayOf(collector,period))
            val balances=mutableListOf<Pair<Long,Double>>();c.use{while(it.moveToNext())balances+=it.getLong(0) to it.getDouble(1)}
            val held=balances.sumOf{it.second};require(held+0.000001>=amount){"المبلغ المطلوب استلامه أكبر من رصيد المحصل المسجل للمحصّل عن الفترة $period (${held})"}
            balances.forEach{(id,balance)->if(remaining>0){val take=minOf(balance,remaining);db.execSQL("UPDATE collector_receivables SET handed_over=handed_over+?,balance=balance-? WHERE id=?",arrayOf(take,take,id));remaining-=take}}
            db.execSQL("INSERT INTO collection_batches(collector,received_date,period,amount,method,expenses,handed_over,remaining,notes) VALUES(?,?,?,?,?,?,?,?,?)",arrayOf(collector,date,period,amount,method,expenses,distributed,amount-expenses-distributed,notes))
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }
    fun heirs():List<Triple<Long,String,Double>> = readableDatabase.rawQuery("SELECT id,name,share_numerator/share_denominator FROM heirs WHERE active=1 ORDER BY id",null).use{c->val out=mutableListOf<Triple<Long,String,Double>>();while(c.moveToNext())out+=Triple(c.getLong(0),c.getString(1),c.getDouble(2));out}
    fun updateHeirShares(percentages:Map<Long,Double>) {
        val activeIds = heirs().map { it.first }.toSet()
        require(percentages.keys == activeIds) { "يجب إدخال أنصبة جميع الورثة النشطين دون إغفال أي وارث" }
        require(percentages.values.all { it.isFinite() && it >= 0.0 } && kotlin.math.abs(percentages.values.sum()-100.0)<0.02) { "يجب أن تكون الأنصبة غير سالبة ومجموعها 100٪" }
        val db=writableDatabase;db.beginTransaction()
        try {
            percentages.forEach{(id,pct)->
                require(pct>=0.0) { "النصيب لا يمكن أن يكون سالبًا" }
                val old=db.rawQuery("SELECT name,share_numerator,share_denominator FROM heirs WHERE id=?",arrayOf(id.toString())).use{if(it.moveToFirst()) Triple(it.getString(0),it.getDouble(1),it.getDouble(2)) else null}
                if(old!=null){val oldPct=if(old.third==0.0)0.0 else old.second/old.third*100.0;db.execSQL("UPDATE heirs SET share_numerator=?,share_denominator=100 WHERE id=?",arrayOf(pct,id));db.execSQL("INSERT INTO audit_log(record_type,record_id,field_name,old_value,new_value,reason,created_at) VALUES('heir',?,'share_percent',?,?,?,?)",arrayOf(old.first,String.format(java.util.Locale.US,"%.4f",oldPct),String.format(java.util.Locale.US,"%.4f",pct),"تعديل يدوي لأنصبة الورثة",System.currentTimeMillis()))}
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }
    fun payHeir(heirId:Long,amount:Double,date:String,method:String,period:String,notes:String="") {
        validateMoney(amount, "قيمة الدفع"); require(method.isNotBlank()) { "طريقة الدفع مطلوبة" }
        try { java.time.LocalDate.parse(date) } catch (_: Exception) { throw IllegalArgumentException("تاريخ الدفع يجب أن يكون YYYY-MM-DD") }
        validatePeriod(period)
        require(heirs().any { it.first == heirId }) { "الوارث المحدد غير موجود أو غير نشط" }
        val db=writableDatabase;db.beginTransaction()
        try {
            val total=db.rawQuery("SELECT COALESCE(SUM(remaining),0) FROM collection_batches WHERE period=?",arrayOf(period)).use{if(it.moveToFirst())it.getDouble(0)else 0.0}
            require(total+0.000001>=amount) { "المبلغ المتاح غير الموزع لا يكفي لهذه الدفعة" }
            var left=amount
            val c=db.rawQuery("SELECT id,remaining FROM collection_batches WHERE period=? AND remaining>0 ORDER BY id",arrayOf(period))
            val batches=mutableListOf<Pair<Long,Double>>();c.use{while(it.moveToNext())batches+=it.getLong(0) to it.getDouble(1)}
            batches.forEach{(id,balance)->if(left>0){val take=minOf(balance,left);db.execSQL("UPDATE collection_batches SET remaining=remaining-?,handed_over=handed_over+? WHERE id=?",arrayOf(take,take,id));left-=take}}
            db.execSQL("INSERT INTO heir_payouts(heir_id,amount,pay_date,method,period,notes) VALUES(?,?,?,?,?,?)",arrayOf(heirId,amount,date,method,period,notes))
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }
    fun payHeirs(net:Double,date:String,method:String,period:String){
        validateMoney(net, "صافي التوزيع"); require(method.isNotBlank()) { "طريقة الدفع مطلوبة" }
        try { java.time.LocalDate.parse(date) } catch (_: Exception) { throw IllegalArgumentException("تاريخ التوزيع يجب أن يكون YYYY-MM-DD") }
        validatePeriod(period)
        val activeHeirs = heirs()
        require(activeHeirs.isNotEmpty()) { "لا يوجد ورثة نشطون لتوزيع المبلغ" }
        require(kotlin.math.abs(activeHeirs.sumOf { it.third } - 1.0) < 0.0002) { "مجموع أنصبة الورثة لا يساوي 100٪؛ راجع الأنصبة قبل التوزيع" }
        val db=writableDatabase;db.beginTransaction();try{
            val available=db.rawQuery("SELECT COALESCE(SUM(remaining),0) FROM collection_batches WHERE period=?",arrayOf(period)).use{if(it.moveToFirst())it.getDouble(0)else 0.0}
            require(net <= available + 0.000001) { "صافي المبلغ المراد توزيعه أكبر من الرصيد المتاح غير الموزع" }
            var left=net
            val c=db.rawQuery("SELECT id,remaining FROM collection_batches WHERE period=? AND remaining>0 ORDER BY id",arrayOf(period))
            val batches=mutableListOf<Pair<Long,Double>>();c.use{while(it.moveToNext())batches+=it.getLong(0) to it.getDouble(1)}
            batches.forEach{(id,balance)->if(left>0.000001){val take=minOf(balance,left);db.execSQL("UPDATE collection_batches SET remaining=remaining-?,handed_over=handed_over+? WHERE id=?",arrayOf(take,take,id));left-=take}}
            activeHeirs.forEach{(id,_,share)->db.execSQL("INSERT INTO heir_payouts(heir_id,amount,pay_date,method,period) VALUES(?,?,?,?,?)",arrayOf(id,net*share,date,method,period))}
            db.setTransactionSuccessful()
        }finally{db.endTransaction()}
    }
    /** Saves all heir payouts as one atomic operation so a failed later payout cannot leave a partial distribution. */
    fun payHeirsDetailed(payouts: List<Triple<Long, Double, String>>, date: String, period: String, notes: String = "") {
        require(payouts.isNotEmpty()) { "لا توجد دفعات لإثباتها" }
        require(payouts.map { it.first }.distinct().size == payouts.size) { "لا تكرر الوارث نفسه في عملية التوزيع الواحدة" }
        val activeIds = heirs().map { it.first }.toSet()
        require(payouts.all { it.first in activeIds && it.third.isNotBlank() }) { "راجع الورثة ووسائل دفع الورثة" }; payouts.forEach { validateMoney(it.second, "مبلغ الوارث") }
        try { java.time.LocalDate.parse(date) } catch (_: Exception) { throw IllegalArgumentException("تاريخ التوزيع يجب أن يكون YYYY-MM-DD") }
        validatePeriod(period)
        val totalRequested = payouts.sumOf { it.second }
        val db = writableDatabase
        db.beginTransaction()
        try {
            val available = db.rawQuery("SELECT COALESCE(SUM(remaining),0) FROM collection_batches WHERE period=?", arrayOf(period)).use {
                if (it.moveToFirst()) it.getDouble(0) else 0.0
            }
            require(totalRequested <= available + 0.000001) {
                "إجمالي التوزيع (${totalRequested}) أكبر من صافي المبلغ غير الموزع (${available})"
            }
            var left = totalRequested
            val c = db.rawQuery("SELECT id,remaining FROM collection_batches WHERE period=? AND remaining>0 ORDER BY id", arrayOf(period))
            val batches = mutableListOf<Pair<Long, Double>>()
            c.use { while (it.moveToNext()) batches += it.getLong(0) to it.getDouble(1) }
            batches.forEach { (id, balance) ->
                if (left > 0.000001) {
                    val take = minOf(balance, left)
                    db.execSQL("UPDATE collection_batches SET remaining=remaining-?,handed_over=handed_over+? WHERE id=?", arrayOf(take, take, id))
                    left -= take
                }
            }
            payouts.forEach { (heirId, amount, method) ->
                db.execSQL("INSERT INTO heir_payouts(heir_id,amount,pay_date,method,period,notes) VALUES(?,?,?,?,?,?)", arrayOf(heirId, amount, date, method, period, notes))
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }


    data class LeaseRow(val id:Long,val unitId:Long,val unitCode:String,val tenant:String,val startDate:String,val endDate:String,val rent:Double?,val status:String,val notes:String)
    data class AttachmentRow(val id:Long,val ownerType:String,val ownerId:String,val uri:String,val name:String,val mime:String,val createdAt:Long,val notes:String,val category:String)

    @Synchronized fun leases(): List<LeaseRow> = readableDatabase.rawQuery("SELECT l.id,l.unit_id,COALESCE(u.code,''),COALESCE(l.tenant_name_snapshot,u.tenant,''),COALESCE(l.start_date,''),COALESCE(l.end_date,''),l.rent,COALESCE(l.status,'نشط'),COALESCE(l.notes,'') FROM leases l LEFT JOIN units u ON u.id=l.unit_id ORDER BY l.id DESC",null).use { c ->
        val out=mutableListOf<LeaseRow>(); while(c.moveToNext()) out += LeaseRow(c.getLong(0),c.getLong(1),c.getString(2),c.getString(3),c.getString(4),c.getString(5),if(c.isNull(6)) null else c.getDouble(6),c.getString(7),c.getString(8)); out
    }
    @Synchronized fun saveLease(id:Long,unitId:Long,start:String,end:String,rent:Double?,status:String,notes:String):Long {
        require(start.isNotBlank()) { "تاريخ بداية العقد مطلوب" }; try { java.time.LocalDate.parse(start) } catch (_:Exception) { throw IllegalArgumentException("تاريخ البداية بصيغة YYYY-MM-DD") }
        if(end.isNotBlank()){try{require(java.time.LocalDate.parse(end)>=java.time.LocalDate.parse(start))}catch(e:IllegalArgumentException){throw e}catch(_:Exception){throw IllegalArgumentException("تاريخ نهاية العقد بصيغة YYYY-MM-DD")}}
        require(rent==null || (rent.isFinite() && rent>=0.0)) { "قيمة الإيجار غير صحيحة" }
        require(readableDatabase.rawQuery("SELECT 1 FROM units WHERE id=?",arrayOf(unitId.toString())).use{it.moveToFirst()}) { "الوحدة غير موجودة" }
        val db=writableDatabase
        val tenantSnapshot=db.rawQuery("SELECT tenant FROM units WHERE id=?",arrayOf(unitId.toString())).use{if(it.moveToFirst())it.getString(0).orEmpty() else ""}
        val tenantId=findOrCreateTenant(db,tenantSnapshot)
        val v=ContentValues().apply{put("unit_id",unitId);if(id<=0){if(tenantId==null)putNull("tenant_id")else put("tenant_id",tenantId)};put("start_date",start);put("end_date",end);if(rent==null)putNull("rent")else put("rent",rent);put("payment_due_day",1);put("status",status);put("notes",notes)}
        return if(id>0){
            // Keep the original tenant snapshot when editing the terms of an existing lease.
            val old=db.rawQuery("SELECT start_date,end_date,rent,status,notes FROM leases WHERE id=?",arrayOf(id.toString())).use{if(it.moveToFirst())(0..4).map{c->if(it.isNull(c)) "" else it.getString(c)}else null}
            require(old!=null) { "العقد غير موجود" }
            db.update("leases",v,"id=?",arrayOf(id.toString()))
            val fresh=listOf(start,end,rent?.toString()?:"",status,notes)
            listOf("start_date","end_date","rent","status","notes").forEachIndexed{idx,field->if(old[idx]!=fresh[idx])recordAudit(db,"leases",id.toString(),field,old[idx],fresh[idx],"تعديل بيانات العقد")}
            id
        }else{
            v.put("tenant_name_snapshot",tenantSnapshot)
            val newId=db.insertOrThrow("leases",null,v);recordAudit(db,"leases",newId.toString(),"record",null,"إنشاء عقد","إضافة سجل جديد");newId
        }
    }
    @Synchronized fun attachments():List<AttachmentRow> = readableDatabase.rawQuery("SELECT id,owner_type,owner_id,uri,display_name,mime_type,created_at,COALESCE(notes,''),COALESCE(category,'مستند آخر') FROM attachments ORDER BY id DESC",null).use{c->
        val out=mutableListOf<AttachmentRow>()
        while(c.moveToNext()) out+=AttachmentRow(c.getLong(0),c.getString(1)?:"",c.getString(2)?:"",c.getString(3)?:"",c.getString(4)?:"",c.getString(5)?:"",c.getLong(6),c.getString(7)?:"",c.getString(8)?:"مستند آخر")
        out
    }
    @Synchronized fun addAttachment(ownerType:String,ownerId:String,uri:String,name:String,mime:String,notes:String="",category:String="مستند آخر"){
        require(uri.isNotBlank()&&name.isNotBlank())
        writableDatabase.execSQL("INSERT INTO attachments(owner_type,owner_id,uri,display_name,mime_type,created_at,notes,category) VALUES(?,?,?,?,?,?,?,?)",arrayOf(ownerType,ownerId,uri,name,mime,System.currentTimeMillis(),notes,category))
    }
    @Synchronized fun deleteLease(id:Long) = moveToTrash("leases", id, "حذف عقد")
    @Synchronized fun deleteAttachment(id:Long) = moveToTrash("attachments", id, "حذف فهرس مستند؛ الملف الأصلي لا يُحذف")
    @Synchronized fun reminders():List<String>{
        val today=java.time.LocalDate.now(); val out=mutableListOf<String>()
        leases().filter{it.status !in listOf("منتهي","ملغي") && it.endDate.isNotBlank()}.forEach{l->try{val d=java.time.LocalDate.parse(l.endDate);val days=java.time.temporal.ChronoUnit.DAYS.between(today,d);if(days in 0..60)out+="العقد للوحدة ${l.unitCode} ينتهي خلال $days يومًا (${l.endDate})" else if(days<0)out+="انتهى عقد الوحدة ${l.unitCode} بتاريخ ${l.endDate}"}catch(_:Exception){}}
        return out
    }

    fun closeForBackup() { writableDatabase.rawQuery("PRAGMA wal_checkpoint(FULL)",null).close(); close() }
    companion object { @Volatile private var instance: RentalsDb?=null; fun get(context: Context)=instance ?: synchronized(this){instance ?: RentalsDb(context.applicationContext).also{instance=it}}; fun reopen(context: Context){ synchronized(this){ val current=instance; if(current!=null) current.close() else instance=RentalsDb(context.applicationContext) } } }
}
