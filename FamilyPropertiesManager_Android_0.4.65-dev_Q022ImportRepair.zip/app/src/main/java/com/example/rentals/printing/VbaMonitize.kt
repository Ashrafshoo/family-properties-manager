package com.example.rentals.printing

import java.math.BigDecimal
import java.math.RoundingMode
import kotlin.math.floor

/**
 * Behavioral port of Module1.Monitize and Digit_Translator extracted from the
 * original November 2026 workbook's VBA project.
 *
 * The workbook applies Int(num_entry), then Format(num_entry,
 * "000000000000.00") and reads the last two characters as the fractional
 * amount. Int() is therefore intentionally independent from the rounded
 * formatted value. Format midpoint handling is modeled as IEEE-754
 * midpoint-to-even rounding.
 */
internal object VbaMonitize {
    fun amountWords(value: Double): String {
        val formatted = BigDecimal(value).setScale(2, RoundingMode.HALF_EVEN)
        val whole = floor(value).toLong().coerceIn(0L, 999_999_999_999L)
        val fraction = formatted.movePointRight(2).toLong().rem(100).toInt()
        val wholeWords = digitTranslator(whole)
        val fractionWords = digitTranslator(fraction.toLong())
        val le = " جنيه "
        val pt = " قرش "
        return when {
            wholeWords.isNotEmpty() && fraction > 0 -> wholeWords + le + " و " + fractionWords + pt
            wholeWords.isNotEmpty() && fraction == 0 -> wholeWords + le
            wholeWords.isEmpty() && fraction != 0 -> fractionWords + pt
            else -> ""
        }
    }

    private fun digitTranslator(value: Long): String {
        val digits = value.coerceIn(0L, 999_999_999_999L).toString().padStart(12, '0')
        val c1 = digits[11].digitToInt()
        val digit1 = when (c1) {
            1 -> "واحد"; 2 -> "اثنان"; 3 -> "ثلاث"; 4 -> "اربع"; 5 -> "خمس"
            6 -> "ست"; 7 -> "سبع"; 8 -> "ثمان"; 9 -> "تسع"; else -> ""
        }
        val c2 = digits[10].digitToInt()
        var digit2 = when (c2) {
            1 -> "عشر"; 2 -> "عشرون"; 3 -> "ثلاثون"; 4 -> "اربعون"; 5 -> "خمسون"
            6 -> "ستون"; 7 -> "سبعون"; 8 -> "ثمانون"; 9 -> "تسعون"; else -> ""
        }
        if (digit1.isNotEmpty() && c2 > 1) digit2 = "$digit1 و$digit2"
        if (digit2.isEmpty()) digit2 = digit1
        if (c1 == 0 && c2 == 1) digit2 += "ة"
        if (c1 == 1 && c2 == 1) digit2 = "احدى عشر"
        if (c1 == 2 && c2 == 1) digit2 = "اثنتى عشر"
        if (c1 > 2 && c2 == 1) digit2 = "$digit1 $digit2"

        val c3 = digits[9].digitToInt()
        var digit3 = when (c3) {
            1 -> "مائة"; 2 -> "مئتان"; in 3..9 -> digitTranslator(c3.toLong()) + "مائة"; else -> ""
        }
        if (digit3.isNotEmpty() && digit2.isNotEmpty()) digit3 += " و$digit2"
        if (digit3.isEmpty()) digit3 = digit2

        val c4 = digits.substring(6, 9).toInt()
        var digit4 = when (c4) {
            1 -> "الف"; 2 -> "الفان"; in 3..10 -> digitTranslator(c4.toLong()) + " آلاف"
            in 11..999 -> digitTranslator(c4.toLong()) + " الف"; else -> ""
        }
        if (digit4.isNotEmpty() && digit3.isNotEmpty()) digit4 += " و$digit3"
        if (digit4.isEmpty()) digit4 = digit3

        val c5 = digits.substring(3, 6).toInt()
        var digit5 = when (c5) {
            1 -> "مليون"; 2 -> "مليونان"; in 3..10 -> digitTranslator(c5.toLong()) + " ملايين"
            in 11..999 -> digitTranslator(c5.toLong()) + " مليونا"; else -> ""
        }
        if (digit5.isNotEmpty() && digit4.isNotEmpty()) digit5 += " و$digit4"
        if (digit5.isEmpty()) digit5 = digit4

        val c6 = digits.substring(0, 3).toInt()
        var digit6 = when (c6) {
            1 -> "مليار"; 2 -> "ملياران"; in 3..999 -> digitTranslator(c6.toLong()) + " مليارات"; else -> ""
        }
        if (digit6.isNotEmpty() && digit5.isNotEmpty()) digit6 += " و$digit5"
        if (digit6.isEmpty()) digit6 = digit5
        return digit6
    }
}
