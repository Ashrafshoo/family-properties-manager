from pathlib import Path
p = Path("app/src/main/java/com/example/rentals/printing/OriginalReceiptTemplateRenderer.kt")
s = p.read_text(encoding="utf-8")
assert "setMaxLines(maxLines)" in s
assert "coerceAtMost(24)" in s
assert "BREAK_STRATEGY_HIGH_QUALITY" in s
assert "HYPHENATION_FREQUENCY_NONE" in s
assert "sourceFont.contains(\"calibri\")" in s
assert "sourceFont.contains(\"arial\")" in s
print("PASS: workbook font-family fallback and height-aware RTL wrapping")

assert "val numericOnly = displayText.isNotEmpty()" in s
assert "val direction = if (isRtl) TextDirectionHeuristics.RTL else TextDirectionHeuristics.LTR" in s
assert "if (!wraps)" in s and "paint.measureText(displayText) > available" in s
assert "setMaxLines(maxLines)" in s
print("PASS: numeric text uses LTR bidi and non-wrapped fields shrink to one line")
