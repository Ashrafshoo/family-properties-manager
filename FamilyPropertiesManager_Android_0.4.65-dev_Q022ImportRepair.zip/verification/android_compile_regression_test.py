from pathlib import Path
root = Path(__file__).resolve().parents[1]
panel = (root / "app/src/main/java/com/example/rentals/features/printing/AggregateStatementsPanel.kt").read_text(encoding="utf-8")
renderer = (root / "app/src/main/java/com/example/rentals/printing/OriginalReceiptTemplateRenderer.kt").read_text(encoding="utf-8")
checks = {
    "aggregate print icon extension is imported": "import androidx.compose.material.icons.filled.Print" in panel,
    "JSONArray cells use indexed access, not ambiguous iterator": "for (cellIndex in 0 until cells.length())" in renderer and "for (cell in cells)" not in renderer,
    "column span uses explicit integer comparisons": "index >= colIndex && index <= endCol" in renderer,
    "row height uses an explicitly typed fold": "(rowIndex..endRow).fold(0.0)" in renderer and "val h = heightTotal.toFloat()" in renderer,
}
for name, ok in checks.items():
    print(("PASS" if ok else "FAIL") + ": " + name)
assert all(checks.values())
