from pathlib import Path
root=Path(__file__).resolve().parents[1]
screen=(root/"app/src/main/java/com/example/rentals/features/printing/MonthlyCollectionScreen.kt").read_text(encoding="utf-8")
exporter=(root/"app/src/main/java/com/example/rentals/printing/ReceiptPdfExporter.kt").read_text(encoding="utf-8")
checks={
 "quick receipt actions appear immediately after batch creation": "إجراءات الإيصالات للدفعة المحددة" in screen,
 "direct receipt print action is visible": "طباعة الإيصالات — ٣ في A4" in screen,
 "receipt PDF is separate from collector PDF": "إيصالات PDF" in screen and "كشف PDF" in screen,
 "receipt Excel is separate from collector Excel": "إيصالات Excel" in screen and "كشف Excel" in screen,
 "PDF export uses original receipt artwork": "receipt_${if (oldLawTemplate) \"old\" else \"new\"}_$suffix" in exporter,
 "PDF keeps three receipts per page maximum": "perPage.coerceIn(1, 3)" in exporter,
}
for name,ok in checks.items(): print(("PASS" if ok else "FAIL")+" - "+name)
assert all(checks.values()),"Receipt export access regression"
print(f"{len(checks)}/{len(checks)} checks passed")
