#!/usr/bin/env python3
"""Aggregate export must fill the full reference workbook template, not a plain table."""
from pathlib import Path
R = Path(__file__).resolve().parents[1]
S = (R / 'app/src/main/java/com/example/rentals/features/printing/MonthlyCollectionScreen.kt').read_text(encoding='utf-8')
E = (R / 'app/src/main/java/com/example/rentals/io/AggregateStatementWorkbookExporter.kt').read_text(encoding='utf-8')
P = (R / 'app/src/main/java/com/example/rentals/features/printing/AggregateStatementsPanel.kt').read_text(encoding='utf-8')
assert 'AggregateStatementWorkbookExporter.export(context, context.contentResolver, uri, items, period)' in S
assert 'aggregateExportMoney(it.amount)' not in S
assert 'updateSettingsSheet(bytes, month, year)' in E
assert 'item.tenant' in E and 'item.amount' in E and 'item.property' in E
assert 'item.templateId' not in E  # the workbook's receipt layout is a single repeated template
assert 'items.size <= 120' in E
assert 'templateOptions.none { it.first == item.templateId }' in P
assert 'row.templateId' in P
print('PASS: aggregate Excel export fills the original receipt workbook and keeps template validation in the UI')
