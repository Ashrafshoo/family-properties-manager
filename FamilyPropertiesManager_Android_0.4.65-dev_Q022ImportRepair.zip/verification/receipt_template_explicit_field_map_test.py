#!/usr/bin/env python3
"""Every November template must declare stable editable field coordinates."""
import json, re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
CATALOG=json.loads((ROOT/'app/src/main/assets/receipt_templates/receipt_template_catalog_v1.json').read_text(encoding='utf-8'))
RENDERER=(ROOT/'app/src/main/java/com/example/rentals/printing/OriginalReceiptTemplateRenderer.kt').read_text(encoding='utf-8')
assert len(CATALOG['templates'])==88
for t in CATALOG['templates']:
    tid=t['template_id']; cells=t['grid']['cells']; by={c['addr']:c for c in cells}; ef=t['editableFields']
    for key in ('tenant','amount','description','location'):
        assert len(ef.get(key,[]))==1,(tid,key,ef.get(key))
        addr=ef[key][0]['address']; assert addr in by,(tid,key,addr)
        pos=ef[key][0]; assert pos['r']==by[addr]['r'] and pos['c']==by[addr]['c'],(tid,key,pos,by[addr])
    formula_refs=[]
    for c in cells:
        v=c.get('value')
        if isinstance(v,str):
            m=re.fullmatch(r'=Monitize\(([A-Z]+[0-9]+)\)',v,re.I)
            if m: formula_refs.append(m.group(1).upper())
    assert len(ef['amount'])==1
    assert ef['amount'][0]['address'] in by
    assert len(formula_refs)<=1,(tid,formula_refs)
    for f in ef.get('dateLiterals',[]):
        assert f['address'] in by and '2026/11/01' in str(by[f['address']].get('value') or ''),(tid,f)
    for f in ef.get('amountInWords',[]): assert f['address'] in by,(tid,f)
# Blank source fields are intentionally mapped and must remain editable.
t=next(x for x in CATALOG['templates'] if x['template_id']=='T058')
assert t['editableFields']['tenant'][0]['address']=='B83' and t['grid']['cells']
assert t['editableFields']['amount'][0]['address']=='C82'
assert 'findUniqueCellAddress' not in RENDERER
assert 'descriptionAddresses = declared("description")' in RENDERER
assert 'locationAddresses = declared("location")' in RENDERER
assert 'موضع وصف العين غير محدد بدقة' in RENDERER
assert 'موضع العنوان غير محدد بدقة' in RENDERER
print('PASS: 88/88 templates use explicit tenant, amount, description and location cell maps')
print('PASS: declared dates preserve original period dates; T058 blank tenant and amount cells are mapped')
print('PASS: renderer no longer discovers legal/property cells through fuzzy runtime text searches')
