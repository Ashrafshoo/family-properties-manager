#!/usr/bin/env python3
"""Structural integrity checks for the extracted November receipt-template catalog."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ASSET_ROOT = ROOT / "app/src/main/assets/receipt_templates"
CATALOG = ASSET_ROOT / "receipt_template_catalog_v1.json"

def main():
    data = json.loads(CATALOG.read_text(encoding="utf-8"))
    templates = data["templates"]
    assert data["schemaVersion"] == 1
    assert len(templates) == 88, f"expected 88 templates, got {len(templates)}"
    ids = [t["template_id"] for t in templates]
    assert len(ids) == len(set(ids)), "duplicate template IDs"
    assert len(data["styles"]) > 0 and len(data["fonts"]) > 0
    image_count = 0
    for template in templates:
        grid = template["grid"]
        assert grid["rows"] > 0 and grid["columns"] > 0
        for cell in grid["cells"]:
            assert 0 <= cell["styleId"] < len(data["styles"]), (template["template_id"], cell)
        for image in grid["images"]:
            path = ASSET_ROOT / image["file"]
            assert path.is_file() and path.stat().st_size > 0, (template["template_id"], path)
            image_count += 1
        for field in template["editableFields"].values():
            for pos in field:
                assert 0 <= pos["r"] < grid["rows"]
                assert 0 <= pos["c"] < grid["columns"]
    assert image_count == 88, f"expected 88 image assets, got {image_count}"
    print(f"PASS: {len(templates)} templates, {image_count} image assets, {len(data['styles'])} styles")

if __name__ == "__main__":
    main()
