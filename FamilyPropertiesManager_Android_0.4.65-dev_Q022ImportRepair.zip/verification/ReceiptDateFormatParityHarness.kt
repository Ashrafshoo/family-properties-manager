import com.example.rentals.printing.ReceiptDateFormat

fun main() {
    check(ReceiptDateFormat.toStorage("٢٠٢٦/١١/٠٥") == "2026-11-05")
    check(ReceiptDateFormat.toSheet("2026-11-05") == "٢٠٢٦/١١/٠٥")
    check(ReceiptDateFormat.toSheet(ReceiptDateFormat.toStorage("٢٠٢٦/٠٢/٠١")) == "٢٠٢٦/٠٢/٠١")
    check(ReceiptDateFormat.toStorage("2026/11/15") == "2026-11-15")
    check(ReceiptDateFormat.toArabicDigits("Rent 2026/11/01") == "Rent ٢٠٢٦/١١/٠١")
    check(runCatching { ReceiptDateFormat.toStorage("٢٠٢٦/١٣/٠١") }.isFailure)
    check(runCatching { ReceiptDateFormat.toStorage("١٥/١١/٢٠٢٦") }.isFailure)
    println("PASS: 7 ReceiptDateFormat runtime parity cases")
}
