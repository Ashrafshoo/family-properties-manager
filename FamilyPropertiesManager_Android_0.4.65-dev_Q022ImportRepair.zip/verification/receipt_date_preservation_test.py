#!/usr/bin/env python3
"""Only the November issue-date token is replaced; other date boundaries remain intact."""
from pathlib import Path
R=Path(__file__).resolve().parents[1]
S=(R/'app/src/main/java/com/example/rentals/printing/OriginalReceiptTemplateRenderer.kt').read_text(encoding='utf-8')
assert 'old.replace("2026/11/01", date)' in S
assert 'old.replace(Regex("\\\\d{4}/\\\\d{2}/\\\\d{2}"), date)' not in S
assert 'monthlyEligible' in S
print('PASS: period boundary dates are preserved; only the source issue-date token is changed')
