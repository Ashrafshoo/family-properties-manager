#!/usr/bin/env python3
from pathlib import Path

root = Path(__file__).resolve().parents[1]
src = (root / "app/src/main/java/com/example/rentals/io/AggregateStatementWorkbookExporter.kt").read_text(encoding="utf-8")
assert "XMLConstants.ACCESS_EXTERNAL_DTD" not in src
assert "XMLConstants.ACCESS_EXTERNAL_SCHEMA" not in src
assert "XMLConstants.ACCESS_EXTERNAL_STYLESHEET" not in src
assert 'setAttribute("http://javax.xml.XMLConstants/property/accessExternalDTD", "")' in src
assert 'setAttribute("http://javax.xml.XMLConstants/property/accessExternalSchema", "")' in src
assert 'setAttribute("http://javax.xml.XMLConstants/property/accessExternalStylesheet", "")' in src
assert 'setFeature("http://apache.org/xml/features/disallow-doctype-decl", true)' in src
assert 'setFeature("http://xml.org/sax/features/external-general-entities", false)' in src
assert 'setFeature("http://xml.org/sax/features/external-parameter-entities", false)' in src
print("PASS: XML security properties use Android-compatible string keys")
