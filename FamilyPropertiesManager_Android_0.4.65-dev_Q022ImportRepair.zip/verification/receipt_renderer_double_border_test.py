#!/usr/bin/env python3
from pathlib import Path
s=(Path(__file__).resolve().parents[1]/'app/src/main/java/com/example/rentals/printing/OriginalReceiptTemplateRenderer.kt').read_text(encoding='utf-8')
assert 'if (kind == "double")' in s
for token in ('x + .35f','x + 1.1f','x + w - .35f','x + w - 1.1f','y + .35f','y + 1.1f','y + h - .35f','y + h - 1.1f'):
    assert token in s,token
print('PASS: Excel double borders are rendered as paired lines on all four sides')
