#!/usr/bin/env python3
"""The new per-batch receipt template selector must migrate without touching records."""
import sqlite3
from pathlib import Path
root = Path(__file__).resolve().parents[1]
db = (root / 'app/src/main/java/com/example/rentals/data/RentalsDb.kt').read_text()
repo = (root / 'app/src/main/java/com/example/rentals/domain/collection/MonthlyCollectionRepository.kt').read_text()
impl = (root / 'app/src/main/java/com/example/rentals/data/repository/SqliteMonthlyCollectionRepository.kt').read_text()
assert 'SQLiteOpenHelper(context, "rentals_local.db", null, 19)' in db
assert 'if (oldVersion < 19) db.execSQL("ALTER TABLE monthly_collection_items ADD COLUMN template_id TEXT NOT NULL DEFAULT \'\'")' in db
assert 'updateMonthlyCollectionReceiptTemplate' in db
assert 'updateBatchReceiptTemplate' in repo and 'updateBatchReceiptTemplate' in impl
con = sqlite3.connect(':memory:')
con.executescript('''CREATE TABLE monthly_collection_items(id INTEGER PRIMARY KEY, tenant TEXT NOT NULL, notes TEXT NOT NULL DEFAULT '');
INSERT INTO monthly_collection_items(id,tenant,notes) VALUES(1,'مستأجر أ','ملاحظة أ'),(2,'مستأجر ب','ملاحظة ب');''')
con.execute("ALTER TABLE monthly_collection_items ADD COLUMN template_id TEXT NOT NULL DEFAULT ''")
assert con.execute('SELECT id,tenant,notes,template_id FROM monthly_collection_items ORDER BY id').fetchall() == [(1,'مستأجر أ','ملاحظة أ',''),(2,'مستأجر ب','ملاحظة ب','')]
con.execute("UPDATE monthly_collection_items SET template_id='T017' WHERE id=1")
assert con.execute('SELECT template_id FROM monthly_collection_items WHERE id=1').fetchone()[0] == 'T017'
assert con.execute('SELECT template_id FROM monthly_collection_items WHERE id=2').fetchone()[0] == ''
print('PASS: version-19 migration preserves existing batch rows and notes')
print('PASS: template selection is stored per receipt without touching payment or ledger tables')
