#!/usr/bin/env python3
"""Regression checks for editable month-scoped aggregate receipt statements."""
import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
db_source = (ROOT / "app/src/main/java/com/example/rentals/data/RentalsDb.kt").read_text(encoding="utf-8")
model_source = (ROOT / "app/src/main/java/com/example/rentals/data/Models.kt").read_text(encoding="utf-8")
ui_source = (ROOT / "app/src/main/java/com/example/rentals/features/printing/AggregateStatementsPanel.kt").read_text(encoding="utf-8")

assert 'SQLiteOpenHelper(context, "rentals_local.db", null, 19)' in db_source
assert 'if (oldVersion < 18) createAggregateReceiptTables(db)' in db_source
assert 'CREATE TABLE IF NOT EXISTS aggregate_receipt_statements' in db_source
assert 'CREATE TABLE IF NOT EXISTS aggregate_receipt_items' in db_source
assert 'FOREIGN KEY(statement_id)' in db_source
assert 'FOREIGN KEY(unit_id)' not in db_source.split('CREATE TABLE IF NOT EXISTS aggregate_receipt_items', 1)[1].split('"""', 1)[0]
assert 'require(item.tenant.isNotBlank())' in db_source
assert 'validateMoney(item.amount,"القيمة الإيجارية")' in db_source
assert 'recordAudit(db,"aggregate_receipt_items"' in db_source
assert 'factories' in db_source and 'homes' in db_source and 'villa_mayor' in db_source
assert 'اسم المستأجر / صاحب الإيصال *' in ui_source
assert 'القيمة الإيجارية بالجنيه *' in ui_source
assert 'رقم الشارع' in ui_source and 'اختياري' in ui_source
assert 'parseAggregateAmount' in ui_source and "'٠'..'٩'" in ui_source
assert 'data class AggregateReceiptItem' in model_source

con = sqlite3.connect(':memory:')
con.executescript('''
CREATE TABLE aggregate_receipt_statements(
 id INTEGER PRIMARY KEY AUTOINCREMENT, period TEXT NOT NULL, statement_type TEXT NOT NULL,
 title TEXT NOT NULL, issued_date TEXT NOT NULL DEFAULT '', created_at INTEGER NOT NULL,
 UNIQUE(period,statement_type));
CREATE TABLE aggregate_receipt_items(
 id INTEGER PRIMARY KEY AUTOINCREMENT, statement_id INTEGER NOT NULL, tenant TEXT NOT NULL,
 amount REAL NOT NULL, property TEXT NOT NULL DEFAULT '', unit_code TEXT NOT NULL DEFAULT '',
 description TEXT NOT NULL DEFAULT '', address TEXT NOT NULL DEFAULT '', template_id TEXT NOT NULL DEFAULT '',
 notes TEXT NOT NULL DEFAULT '', sort_order INTEGER NOT NULL DEFAULT 0,
 FOREIGN KEY(statement_id) REFERENCES aggregate_receipt_statements(id) ON DELETE CASCADE);
INSERT INTO aggregate_receipt_statements(period,statement_type,title,created_at) VALUES
 ('2026-11','factories','كشف مجمع المصانع',1),('2026-12','factories','كشف مجمع المصانع',2);
INSERT INTO aggregate_receipt_items(statement_id,tenant,amount,address) VALUES(1,'مستأجر بلا رقم شارع',55000,'');
''')
assert con.execute("SELECT tenant,amount FROM aggregate_receipt_items WHERE statement_id=1").fetchone() == ('مستأجر بلا رقم شارع', 55000.0)
assert con.execute("SELECT COUNT(*) FROM aggregate_receipt_items WHERE statement_id=2").fetchone()[0] == 0
con.execute("UPDATE aggregate_receipt_items SET amount=56000 WHERE statement_id=1")
assert con.execute("SELECT amount FROM aggregate_receipt_items WHERE statement_id=1").fetchone()[0] == 56000
assert con.execute("SELECT COUNT(*) FROM aggregate_receipt_items WHERE statement_id=2").fetchone()[0] == 0
print('PASS: aggregate statements accept tenant + rent without street/unit identifiers')
print('PASS: statement data is month-scoped and edits do not leak into other months')
print('PASS: schema has no mandatory unit foreign key; audit trail hooks are present')
