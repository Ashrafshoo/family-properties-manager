#!/usr/bin/env python3
"""Audit all workbook templates for runtime-recoverable variable receipt fields."""
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CATALOG = ROOT / 'app/src/main/assets/receipt_templates/receipt_template_catalog_v1.json'
RENDERER = ROOT / 'app/src/main/java/com/example/rentals/printing/OriginalReceiptTemplateRenderer.kt'
data = json.loads(CATALOG.read_text(encoding='utf-8'))
renderer = RENDERER.read_text(encoding='utf-8')
assert len(data['templates']) == 88

def addr(cell):
    return cell.get('addr', '')

for t in data['templates']:
    cells = t['grid']['cells']
    values = [(c, str(c.get('value') or '')) for c in cells]
    ef = t.get('editableFields') or {}
    tenant = list(ef.get('tenant') or [])
    amount = list(ef.get('amount') or [])
    words = list(ef.get('amountInWords') or [])
    dates = list(ef.get('dateLiterals') or [])
    formula_cells = [(c, v) for c, v in values if v.startswith('=Monitize(')]
    tenant_cells = [c for c, v in values if 'وصلنا من' in v]
    date_cells = [c for c, v in values if re.search(r'\d{4}/\d{2}/\d{2}', v)]
    label_rows = [c.get('r') for c, v in values if 'المبلغ المرقوم' in v]
    literal_words = [c for c, v in values if any(c.get('r') == r and c.get('c') == 2 for r in label_rows)]
    # The only intentionally blank tenant-name form has a merged B-cell above the amount-words row.
    blank_tenant_cell = any(c.get('c') == 1 and c.get('r') == r - 1 for c in cells for r in label_rows)
    has_tenant = bool(tenant or tenant_cells or blank_tenant_cell)
    has_amount = bool(amount or formula_cells)
    has_words = bool(words or formula_cells or literal_words)
    has_dates = bool(dates or date_cells)
    assert has_tenant, (t['template_id'], 'tenant field not recoverable')
    assert has_amount, (t['template_id'], 'amount field not recoverable')
    assert has_words, (t['template_id'], 'amount-in-words field not recoverable')
    assert has_dates, (t['template_id'], 'date field not recoverable')

assert 'tenantAddresses = declared("tenant")' in renderer
assert 'Only catalog-declared issue-date cells are editable' in renderer
assert 'amountAddresses = declared("amount")' in renderer
assert 'if (isRtl) Layout.Alignment.ALIGN_OPPOSITE' in renderer
assert 'rows.optDouble(it, 18.0).toFloat())' in renderer
print('PASS: all 88 templates have recoverable tenant, amount, amount-in-words and date positions')
print('PASS: explicit catalog fields are used for runtime receipt editing')
