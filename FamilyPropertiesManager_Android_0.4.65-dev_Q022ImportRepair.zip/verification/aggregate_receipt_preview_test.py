#!/usr/bin/env python3
"""The aggregate statement exposes a preview rendered by the same template engine as output."""
from pathlib import Path
R=Path(__file__).resolve().parents[1]
P=(R/'app/src/main/java/com/example/rentals/features/printing/AggregateStatementsPanel.kt').read_text(encoding='utf-8')
assert 'previewItem' in P and 'معاينة' in P
assert 'OriginalReceiptTemplateRenderer(context).draw(' in P
assert 'composeCanvas.nativeCanvas' in P
assert 'issuedDate' in P
print('PASS: selected aggregate receipt can be previewed using the exact renderer and issue date used by PDF/print')
