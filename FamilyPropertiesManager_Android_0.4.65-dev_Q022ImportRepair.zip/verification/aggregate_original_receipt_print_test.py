#!/usr/bin/env python3
"""Source regression checks for printing selected aggregate rows with workbook-derived templates."""
from pathlib import Path
import json
ROOT = Path(__file__).resolve().parents[1]
renderer = (ROOT / 'app/src/main/java/com/example/rentals/printing/OriginalReceiptTemplateRenderer.kt').read_text(encoding='utf-8')
adapter = (ROOT / 'app/src/main/java/com/example/rentals/printing/AggregateReceiptPrintAdapter.kt').read_text(encoding='utf-8')
panel = (ROOT / 'app/src/main/java/com/example/rentals/features/printing/AggregateStatementsPanel.kt').read_text(encoding='utf-8')
screen = (ROOT / 'app/src/main/java/com/example/rentals/features/printing/MonthlyCollectionScreen.kt').read_text(encoding='utf-8')
catalog = json.loads((ROOT / 'app/src/main/assets/receipt_templates/receipt_template_catalog_v1.json').read_text(encoding='utf-8'))
assert len(catalog['templates']) == 88
assert 'receipt_template_catalog_v1.json' in renderer
assert 'editableFields' in renderer and 'amountInWords' in renderer and 'dateLiterals' in renderer
assert 'drawSideImages' in renderer and 'item.tenant' in renderer and 'item.amount' in renderer
assert 'templateIds()' in renderer and 'legal_variant' in renderer
assert 'renderer.draw(page.canvas, rect, items[index], normalizedIssuedDate)' in adapter
assert 'ReceiptDateFormat.toSheet(ReceiptDateFormat.toStorage(issuedDate))' in adapter
assert 'pageCount' in adapter and 'coerceIn(1, 3)' in adapter
assert 'تحديد الكل' in panel and 'طباعة' in panel and 'تحديد الكل' in panel
assert 'templateOptions.forEach' in panel
assert 'AggregateReceiptPrintAdapter(activity, items, normalizedPrintDate, 3, settings.marginMm)' in screen
assert 'تاريخ الإصدار غير صحيح' in screen and 'ReceiptDateFormat.toSheet(ReceiptDateFormat.toStorage(issuedDate))' in screen
assert 'AggregateReceiptPdfExporter.export' in screen and 'exportAggregateExcel' in screen
assert 'onExportSelectedPdf' in panel and 'onExportSelectedExcel' in panel
assert 'repository.createBatch' not in adapter and 'recordCollectorResult' not in adapter
assert 'AggregateReceiptPdfExporter' in screen and 'WorkbookExporter.exportRows' in screen
print('PASS: catalog-driven receipt rendering and variable overlays are wired to the selected aggregate rows')
print('PASS: selected-only printing and 3-per-A4 layout are wired; print adapter does not create financial collection records')
