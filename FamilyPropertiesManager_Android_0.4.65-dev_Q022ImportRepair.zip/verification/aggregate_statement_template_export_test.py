from pathlib import Path
import zipfile
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "app/src/main/java/com/example/rentals/io/AggregateStatementWorkbookExporter.kt"
SCREEN = ROOT / "app/src/main/java/com/example/rentals/features/printing/MonthlyCollectionScreen.kt"
TEMPLATE = ROOT / "app/src/main/assets/aggregate_statement_template.xlsx"


def test_template_is_bundled_and_keeps_original_receipt_artwork():
    assert TEMPLATE.exists() and TEMPLATE.stat().st_size > 100_000
    with zipfile.ZipFile(TEMPLATE) as archive:
        names = set(archive.namelist())
        assert "xl/worksheets/sheet1.xml" in names
        assert "xl/worksheets/sheet3.xml" in names
        assert "xl/worksheets/sheet4.xml" in names
        assert "xl/drawings/drawing1.xml" in names
        assert "xl/worksheets/_rels/sheet3.xml.rels" in names
        drawing = ET.fromstring(archive.read("xl/drawings/drawing1.xml"))
        ns = {"xdr": "http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing"}
        assert len(drawing.findall("xdr:twoCellAnchor", ns)) >= 300
        sheet = ET.fromstring(archive.read("xl/worksheets/sheet3.xml"))
        ns_main = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
        assert sheet.find("m:rowBreaks", ns_main) is not None


def test_aggregate_export_uses_template_and_does_not_use_plain_table_export():
    src = SOURCE.read_text(encoding="utf-8")
    screen = SCREEN.read_text(encoding="utf-8")
    assert 'TEMPLATE_ASSET = "aggregate_statement_template.xlsx"' in src
    assert '"xl/worksheets/sheet1.xml"' in src
    assert '"xl/worksheets/sheet4.xml"' in src
    assert '"xl/workbook.xml" -> updateCalculationMode(bytes)' in src
    assert 'AggregateStatementWorkbookExporter.export(context, context.contentResolver, uri, items, period)' in screen
    assert 'WorkbookExporter.exportRows(context.contentResolver, uri, "كشف الإيصالات المجمع"' not in screen
    assert 'item.tenant' in src and 'item.amount' in src and 'item.property' in src
    assert 'item.address' in src and 'item.description' in src and 'item.notes' in src
    assert 'require(items.size <= 120)' in src
    assert 'clearIncreaseSheet(bytes)' in src
    assert 'require(hasWorkbook && hasUnits && hasReceiptImages)' in src


def test_export_preserves_receipt_formulas_and_never_marks_payment():
    src = SOURCE.read_text(encoding="utf-8")
    assert 'columnOf(it.getAttribute("r")) != "U"' in src
    assert 'updateSettingsSheet(bytes, month, year)' in src
    assert 'fullCalcOnLoad' in src and 'forceFullCalc' in src
    # This exporter is isolated from payment/ledger APIs.
    assert "repository." not in src
    assert "paid" not in src.lower()
