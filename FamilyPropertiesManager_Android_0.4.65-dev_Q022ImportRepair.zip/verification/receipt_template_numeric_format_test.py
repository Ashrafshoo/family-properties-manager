#!/usr/bin/env python3
"""Protect source-derived amount precision for original receipt templates."""
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
data=json.loads((ROOT/'app/src/main/assets/receipt_templates/receipt_template_catalog_v1.json').read_text(encoding='utf-8'))
styles=data['styles']
expected={'T001':1,'T006':2,'T081':166,'T086':166}
for tid,numfmt in expected.items():
 t=next(x for x in data['templates'] if x['template_id']==tid)
 addr=t['editableFields']['amount'][0]['address']
 cell=next(c for c in t['grid']['cells'] if c['addr']==addr)
 assert styles[cell['styleId']]['numFmtId']==numfmt,(tid,addr,styles[cell['styleId']])
renderer=(ROOT/'app/src/main/java/com/example/rentals/printing/OriginalReceiptTemplateRenderer.kt').read_text(encoding='utf-8')
assert '2, 4, 165 -> 2' in renderer
assert '10, 166, 169 -> 1' in renderer
assert 'ReceiptDateFormat.toArabicDigits(String.format(Locale.US, pattern, value))' in renderer
print('PASS: integer, 2-decimal and 1-decimal source formats retained for representative November receipts')
