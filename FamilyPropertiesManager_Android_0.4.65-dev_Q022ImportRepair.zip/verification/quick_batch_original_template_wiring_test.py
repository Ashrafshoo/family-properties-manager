from pathlib import Path
root = Path(__file__).resolve().parents[1]
screen = (root / "app/src/main/java/com/example/rentals/features/printing/MonthlyCollectionScreen.kt").read_text()
db = (root / "app/src/main/java/com/example/rentals/data/RentalsDb.kt").read_text()
repo = (root / "app/src/main/java/com/example/rentals/domain/collection/MonthlyCollectionRepository.kt").read_text()
impl = (root / "app/src/main/java/com/example/rentals/data/repository/SqliteMonthlyCollectionRepository.kt").read_text()
assert 'OriginalReceiptTemplateRenderer(context).templateIds(monthlyOnly = true)' in screen
assert 'AggregateReceiptPdfExporter.export(activity,context.contentResolver,uri,items,issuedDate,3,settings.marginMm)' in screen
assert 'AggregateStatementWorkbookExporter.export(context,context.contentResolver,uri,items,b.period)' in screen
assert 'AggregateReceiptPrintAdapter(activity' in screen
assert 'ReceiptPdfExporter.export(activity,context.contentResolver,uri,receipts' not in screen
assert 'WorkbookExporter.exportRows(context.contentResolver,uri,"إيصالات الدفعة"' not in screen
assert 'updateBatchReceiptTemplate' in repo and 'updateBatchReceiptTemplate' in impl
assert 'updateMonthlyCollectionReceiptTemplate' in db
assert 'ALTER TABLE monthly_collection_items ADD COLUMN template_id TEXT NOT NULL DEFAULT ''' in db
assert "COALESCE(i.template_id,'')" in db
assert 'r.amount==null' in screen
print('PASS: quick batch PDF, Excel and print route through original-template exporters; template choice is persisted per batch row; missing amounts are rejected.')
