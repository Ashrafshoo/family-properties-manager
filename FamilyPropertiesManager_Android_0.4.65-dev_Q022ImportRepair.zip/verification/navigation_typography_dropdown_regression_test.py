from pathlib import Path
root = Path(__file__).resolve().parents[1]
main = (root / 'app/src/main/java/com/example/rentals/MainActivity.kt').read_text()
bar = (root / 'app/src/main/java/com/example/rentals/ui/components/PropertyComponents.kt').read_text()
settings = (root / 'app/src/main/java/com/example/rentals/features/settings/SettingsScreen.kt').read_text()
theme = (root / 'app/src/main/java/com/example/rentals/design/AppTheme.kt').read_text()
store = (root / 'app/src/main/java/com/example/rentals/ui/SettingsStore.kt').read_text()
checks = {
    'system back is handled inside the app': 'BackHandler(enabled = true)' in main,
    'back from a feature returns to dashboard': 'tab != Tab.Home -> tab = Tab.Home' in main,
    'dashboard back asks before exit': 'confirmExit = true' in main and 'هل تريد إغلاق تطبيق أملاك العائلة؟' in main,
    'visible top bar back control exists': 'fun BrandTopBar(onBack: () -> Unit' in bar and 'contentDescription = "رجوع"' in bar,
    'font size can shrink to 65 percent': 'valueRange=.65f..1.35f' in settings and 'MIN_FONT_SCALE = 0.65f' in store,
    'font size affects explicit sp values via density': 'LocalDensity provides Density(baseDensity.density,' in main,
    'font choices are dropdowns': 'PreferenceDropdown("نوع الخط"' in settings,
    'background and text palettes are dropdowns': 'PreferenceDropdown("لون خلفية التطبيق"' in settings and 'PreferenceDropdown("لون الكتابة"' in settings,
    'bold font switch remains available': 'خط عريض وواضح' in settings,
    'sans and Noto are distinct': '"noto" -> ArabicFontFamily' in theme and 'else -> FontFamily.SansSerif' in theme,
}
for name, ok in checks.items(): print(('PASS' if ok else 'FAIL') + ' - ' + name)
assert all(checks.values()), 'Navigation / typography regression'
print(f'{len(checks)}/{len(checks)} checks passed')
