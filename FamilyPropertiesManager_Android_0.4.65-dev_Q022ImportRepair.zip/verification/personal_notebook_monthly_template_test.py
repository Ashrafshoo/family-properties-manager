from pathlib import Path
root = Path(__file__).resolve().parents[1]
db = (root / 'app/src/main/java/com/example/rentals/data/RentalsDb.kt').read_text(encoding='utf-8')
ui = (root / 'app/src/main/java/com/example/rentals/features/personal/PersonalRentNotebook.kt').read_text(encoding='utf-8')
checks = {
    'database schema upgraded without replacing database': 'SQLiteOpenHelper(context, "rentals_local.db", null, 19)' in db,
    'collection status is stored per monthly row': 'collected INTEGER NOT NULL DEFAULT 0' in db and 'fun setPersonalCollected(monthId:Long,rowNo:Int,collected:Boolean)' in db,
    'recurring master list is separate from monthly rows': 'CREATE TABLE IF NOT EXISTS personal_rent_templates' in db,
    'new months are populated from active recurring names': 'FROM personal_rent_templates WHERE active=1 ORDER BY id' in db,
    'month-specific rows can be added without a fixed 15-row limit': 'fun addPersonalRow(monthId:Long)' in db and 'rowNo>0' in db,
    'daughter and son values are independently editable': 'OutlinedTextField(daughter' in ui and 'OutlinedTextField(son' in ui,
    'collection checkbox is displayed per person': 'Checkbox(checked=collected' in ui,
    'user can add a row for the selected month': 'db.addPersonalRow(monthId)' in ui,
    'user can promote a row to recurring template': 'db.savePersonalTemplate' in ui,
    'template application does not overwrite month data': 'applyPersonalTemplatesIfEmpty' in db and 'تحميل القائمة الأساسية' in ui,
    'confirmed screenshot amount is prefilled': '70167' in db,
    'deductions have a separate monthly table': 'CREATE TABLE IF NOT EXISTS personal_rent_deductions' in db,
    'five initial deduction rows are created for a new month': 'for(i in 1..5) db.insertOrThrow("personal_rent_deductions"' in db,
    'deduction rows are editable and can be extended': 'fun savePersonalDeduction' in db and 'fun addPersonalDeduction' in db and 'db.personalDeductions(monthId)' in ui,
    'net balance subtracts deductions separately': 'total-expenseTotal-deductionsTotal' in ui,
}
for name, ok in checks.items(): print(('PASS' if ok else 'FAIL') + ' - ' + name)
assert all(checks.values()), 'Personal notebook monthly-template regression'
print(f'{len(checks)}/{len(checks)} checks passed')
