#!/usr/bin/env python3
"""Verify every workbook receipt image has a usable two-cell anchor geometry."""
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
D=json.loads((ROOT/'app/src/main/assets/receipt_templates/receipt_template_catalog_v1.json').read_text(encoding='utf-8'))
assert len(D['templates']) == 88
for t in D['templates']:
    imgs=t['grid']['images']
    assert len(imgs)==1, t['template_id']
    im=imgs[0]
    for k in ('fromCol','fromRow','fromColOffEmu','fromRowOffEmu','toCol','toRow','toColOffEmu','toRowOffEmu'):
        assert k in im, (t['template_id'],k)
    cols=list(t['grid']['columnWidths'].values())
    rows=list(t['grid']['rowHeights'].values())
    def start(vals,n): return sum(vals[:max(0,min(n,len(vals)))])
    x1=start(cols,im['fromCol'])+im['fromColOffEmu']/12700
    x2=start(cols,im['toCol'])+im['toColOffEmu']/12700
    y1=start(rows,im['fromRow'])+im['fromRowOffEmu']/12700
    y2=start(rows,im['toRow'])+im['toRowOffEmu']/12700
    assert x2>x1 and y2>y1, (t['template_id'],(x1,y1,x2,y2))
assert D['sourceWorkbook'].endswith('.xls')
print('PASS: all 88 side images carry workbook-derived two-cell anchors with positive bounds')
