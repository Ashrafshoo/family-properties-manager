#!/usr/bin/env python3
from pathlib import Path
p=Path(__file__).resolve().parents[1]/'app/src/main/java/com/example/rentals/features/printing/MonthlyCollectionScreen.kt'
s=p.read_text(encoding='utf-8')
assert 'value=aggregateExportDigits(period)' in s
assert 'onValueChange={period=aggregateImportDigits(it)}' in s
assert 'private fun aggregateImportDigits' in s
assert 'شهر التحصيل بصيغة سنة-شهر' in s
print('PASS: month period is displayed in Arabic-Indic digits while ISO-compatible western digits remain internal')
