from pathlib import Path

root = Path(__file__).resolve().parents[1]
db = (root / "app/src/main/java/com/example/rentals/data/RentalsDb.kt").read_text(encoding="utf-8")
ui = (root / "app/src/main/java/com/example/rentals/features/personal/PersonalRentNotebook.kt").read_text(encoding="utf-8")

for method in ("updatePersonalExpense", "deletePersonalExpense", "personalAnnualSummary"):
    assert f"fun {method}(" in db, f"Missing database method: {method}"
assert "(1..12).map" in db, "Annual summary must include all 12 months"
assert "LocalDate.parse(date)" in db, "Personal expense date must be validated"
assert "المصروف لا يقبل" not in db  # keep validation message stable and explicit
assert "تعديل المصروف" in ui and "حذف المصروف" in ui
assert "التقرير السنوي" in ui
assert "حفظ السطر" in ui, "Rows must be explicitly saved rather than writing every keystroke"
# Prevent the previous focus/cursor instability: edits should not persist from TextField callbacks.
notebook = ui[ui.index("fun PersonalRentNotebook"): ]
assert "{tenant=it;db.savePersonalRow" not in notebook
assert "{amount=it;val v=it.toDoubleOrNull()" not in notebook
print("Personal notebook feature checks passed")
assert 'المبالغ لا تقبل أكثر من منزلتين عشريتين' in db
assert 'require(changed==1)' in db[db.index('fun savePersonalRow'):db.index('fun addPersonalRow')]
assert 'OutlinedTextField(daughter' in notebook and 'OutlinedTextField(son' in notebook
assert 'Checkbox(checked=collected' in notebook
print('Personal notebook editable allocation and collection checks passed')
