import sqlite3

conn = sqlite3.connect(':memory:')
conn.execute('PRAGMA foreign_keys=ON')
conn.executescript('''
CREATE TABLE personal_rent_months(id INTEGER PRIMARY KEY AUTOINCREMENT,year INTEGER NOT NULL,month INTEGER NOT NULL,created_at INTEGER NOT NULL,UNIQUE(year,month));
CREATE TABLE personal_rent_rows(id INTEGER PRIMARY KEY AUTOINCREMENT,month_id INTEGER NOT NULL,row_no INTEGER NOT NULL,tenant TEXT NOT NULL DEFAULT '',total REAL NOT NULL DEFAULT 0,daughter REAL NOT NULL DEFAULT 0,son REAL NOT NULL DEFAULT 0,notes TEXT NOT NULL DEFAULT '',UNIQUE(month_id,row_no),FOREIGN KEY(month_id) REFERENCES personal_rent_months(id) ON DELETE CASCADE);
CREATE TABLE personal_rent_expenses(id INTEGER PRIMARY KEY AUTOINCREMENT,month_id INTEGER NOT NULL,title TEXT NOT NULL,amount REAL NOT NULL DEFAULT 0,expense_date TEXT NOT NULL DEFAULT '',notes TEXT NOT NULL DEFAULT '',FOREIGN KEY(month_id) REFERENCES personal_rent_months(id) ON DELETE CASCADE);
INSERT INTO personal_rent_months(year,month,created_at) VALUES(2026,10,1);
INSERT INTO personal_rent_rows(month_id,row_no,tenant,total,daughter,son,notes) VALUES(1,1,'اسم تاريخي',1000,100,200,'لا يمس');
''')
# Equivalent of the v16 -> v17 additive migration.
conn.execute("ALTER TABLE personal_rent_rows ADD COLUMN collected INTEGER NOT NULL DEFAULT 0")
conn.executescript('''
CREATE TABLE IF NOT EXISTS personal_rent_deductions(id INTEGER PRIMARY KEY AUTOINCREMENT,month_id INTEGER NOT NULL,row_no INTEGER NOT NULL,title TEXT NOT NULL DEFAULT '',amount REAL NOT NULL DEFAULT 0,notes TEXT NOT NULL DEFAULT '',UNIQUE(month_id,row_no),FOREIGN KEY(month_id) REFERENCES personal_rent_months(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS personal_rent_templates(id INTEGER PRIMARY KEY AUTOINCREMENT,tenant TEXT NOT NULL UNIQUE,total REAL NOT NULL DEFAULT 0,daughter REAL NOT NULL DEFAULT 0,son REAL NOT NULL DEFAULT 0,active INTEGER NOT NULL DEFAULT 1,created_at INTEGER NOT NULL);
''')
old = conn.execute('SELECT tenant,total,daughter,son,notes,collected FROM personal_rent_rows WHERE month_id=1 AND row_no=1').fetchone()
assert old == ('اسم تاريخي',1000.0,100.0,200.0,'لا يمس',0), old
conn.execute("INSERT INTO personal_rent_templates(tenant,total,daughter,son,created_at) VALUES('اسم جديد',700,100,200,2)")
conn.execute("INSERT INTO personal_rent_months(year,month,created_at) VALUES(2026,11,2)")
month_id = conn.execute('SELECT id FROM personal_rent_months WHERE year=2026 AND month=11').fetchone()[0]
conn.execute("INSERT INTO personal_rent_rows(month_id,row_no,tenant,total,daughter,son) SELECT ?,1,tenant,total,daughter,son FROM personal_rent_templates WHERE active=1", (month_id,))
for i in range(1,6): conn.execute('INSERT INTO personal_rent_deductions(month_id,row_no) VALUES(?,?)',(month_id,i))
assert conn.execute('SELECT tenant,total FROM personal_rent_rows WHERE month_id=?',(month_id,)).fetchone()==('اسم جديد',700.0)
assert conn.execute('SELECT COUNT(*) FROM personal_rent_deductions WHERE month_id=?',(month_id,)).fetchone()[0]==5
conn.execute('UPDATE personal_rent_rows SET collected=1 WHERE month_id=?',(month_id,))
assert conn.execute('SELECT collected FROM personal_rent_rows WHERE month_id=?',(month_id,)).fetchone()[0]==1
assert conn.execute('SELECT collected FROM personal_rent_rows WHERE month_id=1').fetchone()[0]==0
print('PASS: v16->v17 adds monthly collection flags, recurring templates and deductions while preserving historical rows and isolating month state.')
