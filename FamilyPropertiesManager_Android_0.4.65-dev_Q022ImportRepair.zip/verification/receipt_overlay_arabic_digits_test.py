#!/usr/bin/env python3
from pathlib import Path
R=Path(__file__).resolve().parents[1]
for name in ('ReceiptPrintAdapter.kt','ReceiptPdfExporter.kt'):
    s=(R/'app/src/main/java/com/example/rentals/printing'/name).read_text(encoding='utf-8')
    assert 'ReceiptDateFormat.toArabicDigits(String.format(Locale.US, "%.2f", it))' in s,name
    assert 'ReceiptDateFormat.toArabicDigits(' in s,name
    assert 'ReceiptDateFormat.toArabicDigits(u.tenant)' in s or 'ReceiptDateFormat.toArabicDigits(receipt.tenant)' in s,name
    assert 'ReceiptDateFormat.toArabicDigits(unitDescription)' in s or 'ReceiptDateFormat.toArabicDigits(description)' in s,name
print('PASS: receipt amounts, tenant names, property/date details and receipt references normalize digits to Arabic-Indic')
