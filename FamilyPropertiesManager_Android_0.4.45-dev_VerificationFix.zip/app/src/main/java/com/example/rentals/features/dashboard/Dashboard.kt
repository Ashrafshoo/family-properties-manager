package com.example.rentals.features.dashboard

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.Image
import com.example.rentals.R
import com.example.rentals.domain.dashboard.DashboardUnitSnapshot
import com.example.rentals.domain.dashboard.BuildDashboardOverview
import com.example.rentals.navigation.AppTab
import java.text.NumberFormat
import java.util.Locale

private val Navy = Color(0xFF071B3B)
private val Gold = Color(0xFFFFC94A)
private val Emerald = Color(0xFF0D9B72)
private val Violet = Color(0xFF7652C7)
private val Sky = Color(0xFF087CCB)
private val Orange = Color(0xFFF29B18)

@Composable
fun Dashboard(units: List<DashboardUnitSnapshot>, onNavigate: (AppTab) -> Unit) {
    val overview = BuildDashboardOverview()(units)
    val operationalRatio = if (overview.totalRecords == 0) 0f else overview.includedOperationalRecords.toFloat() / overview.totalRecords
    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState()).padding(horizontal = 14.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(15.dp)
    ) {
        DashboardHero()
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text("لوحة تحكم أملاك العائلة", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
                Text("نظرة مباشرة على السجلات المسجلة • السجلات المشمولة تشغيليًا", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
            }
            Surface(shape = RoundedCornerShape(50), color = MaterialTheme.colorScheme.primaryContainer) {
                Row(Modifier.padding(horizontal = 10.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    Icon(Icons.Default.Verified, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(15.dp))
                    Text("ملخص فعلي", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
                }
            }
        }
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                DashboardMetric("الإيراد الإيجاري المسجل", dashboardMoney(overview.registeredRentTotal), Icons.Default.Payments, Emerald, Modifier.weight(1f)) { onNavigate(AppTab.Finance) }
                DashboardMetric("إجمالي الوحدات", overview.totalRecords.toString(), Icons.Default.Apartment, Sky, Modifier.weight(1f)) { onNavigate(AppTab.Units) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                DashboardMetric("السجلات التشغيلية", overview.includedOperationalRecords.toString(), Icons.Default.Domain, Orange, Modifier.weight(1f)) { onNavigate(AppTab.Units) }
                DashboardMetric("تحتاج إلى مراجعة", overview.needsReviewCount.toString(), Icons.Default.FactCheck, Violet, Modifier.weight(1f)) { onNavigate(AppTab.Review) }
            }
        }
        Card(
            modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = .35f)),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("مؤشر حالة السجلات", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        Text("نسبة السجلات التشغيلية من إجمالي السجلات", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                    }
                    Text("${(operationalRatio * 100).toInt()}٪", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.headlineSmall)
                }
                LinearProgressIndicator(progress = { operationalRatio }, modifier = Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(20.dp)), color = Emerald, trackColor = MaterialTheme.colorScheme.surfaceVariant)
                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    LegendDot("تشغيلي ${overview.includedOperationalRecords}", Emerald)
                    LegendDot("الإجمالي ${overview.totalRecords}", Sky)
                    LegendDot("مراجعة ${overview.needsReviewCount}", Violet)
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("الوصول السريع", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            TextButton(onClick = { onNavigate(AppTab.Settings) }) { Text("تخصيص الواجهة") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ShortcutTile("الوحدات", "العقارات والسجلات", Icons.Default.Apartment, Sky, Modifier.weight(1f)) { onNavigate(AppTab.Units) }
            ShortcutTile("التحصيل", "الدورة والإيصالات", Icons.Default.ReceiptLong, Emerald, Modifier.weight(1f)) { onNavigate(AppTab.Print) }
            ShortcutTile("دفتري", "دفتر شخصي مستقل", Icons.Default.MenuBook, Violet, Modifier.weight(1f)) { onNavigate(AppTab.Personal) }
        }
        DashboardShortcut("الدفتر المالي", "الحركات والتحصيل والمصروفات والتوزيعات", Icons.Default.AccountBalanceWallet, "الإدارة المالية") { onNavigate(AppTab.Finance) }
        DashboardShortcut("العقود والأرشيف", "العقود والتجديدات والمستندات والتنبيهات", Icons.Default.FolderOpen, "المستندات") { onNavigate(AppTab.Contracts) }
        DashboardShortcut("مركز المراجعة", "مطابقة البيانات ومراجعة السجلات", Icons.Default.FactCheck, "جودة البيانات") { onNavigate(AppTab.Review) }
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer), shape = RoundedCornerShape(20.dp)) {
            Row(Modifier.padding(14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.Top) {
                Icon(Icons.Default.Info, null, tint = MaterialTheme.colorScheme.secondary)
                Text("يُحدد يوم استحقاق الإيجار من العقد أو الاتفاق المسجل لكل وحدة؛ لا يُفترض أنه أول الشهر. الإيجار المسجل أو وجود إيصال لا يثبت التحصيل الفعلي؛ إثبات التحصيل يتم في دفتر الحركات المالية. لا يستنتج التطبيق المتأخرات من مجرد غياب الإيصال.", color = MaterialTheme.colorScheme.onSecondaryContainer, style = MaterialTheme.typography.bodySmall, lineHeight = 19.sp)
            }
        }
        Spacer(Modifier.height(6.dp))
    }
}

@Composable
private fun DashboardHero() {
    Box(Modifier.fillMaxWidth().height(224.dp).clip(RoundedCornerShape(26.dp))) {
        Image(painterResource(R.drawable.dashboard_estate_hero), null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Navy.copy(alpha = .28f), Color(0xFF0B5570).copy(alpha = .52f), Navy.copy(alpha = .94f)))))
        Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(color = Color.White.copy(alpha = .16f), shape = RoundedCornerShape(16.dp)) {
                    Icon(Icons.Default.Apartment, null, tint = Color.White, modifier = Modifier.padding(11.dp).size(26.dp))
                }
                Spacer(Modifier.width(10.dp))
                Column {
                    Text("أملاك العائلة", color = Color.White, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleLarge)
                    Text("إدارة العقارات والإيجارات", color = Color.White.copy(alpha = .88f), style = MaterialTheme.typography.labelMedium)
                }
                Spacer(Modifier.weight(1f))
                Icon(Icons.Default.AutoAwesome, null, tint = Gold, modifier = Modifier.size(26.dp))
            }
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("مرحبًا بك", color = Gold, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Text("كل أملاك العائلة… في مكان واحد", color = Color.White, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.headlineSmall)
                Text("تابع وحداتك وعقودك وحركاتك المالية بوضوح", color = Color.White.copy(alpha = .9f), style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun DashboardMetric(title: String, value: String, icon: ImageVector, color: Color, modifier: Modifier, onClick: () -> Unit) {
    Card(modifier.clickable(onClick = onClick), shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = color), elevation = CardDefaults.cardElevation(3.dp)) {
        Column(Modifier.fillMaxWidth().heightIn(min = 132.dp).padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(color = Color.White.copy(alpha = .2f), shape = RoundedCornerShape(12.dp)) { Icon(icon, null, tint = Color.White, modifier = Modifier.padding(8.dp).size(22.dp)) }
                Spacer(Modifier.weight(1f)); Icon(Icons.Default.ArrowOutward, null, tint = Color.White.copy(alpha = .85f), modifier = Modifier.size(17.dp))
            }
            Text(value, color = Color.White, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleLarge, maxLines = 1)
            Text(title, color = Color.White.copy(alpha = .94f), style = MaterialTheme.typography.labelMedium, lineHeight = 17.sp)
        }
    }
}

@Composable
private fun LegendDot(label: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        Box(Modifier.size(8.dp).clip(RoundedCornerShape(50)).background(color))
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun ShortcutTile(title: String, subtitle: String, icon: ImageVector, color: Color, modifier: Modifier, onClick: () -> Unit) {
    Card(modifier.clickable(onClick = onClick), shape = RoundedCornerShape(19.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), border = BorderStroke(1.dp, color.copy(alpha = .25f))) {
        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Surface(color = color.copy(alpha = .13f), shape = RoundedCornerShape(12.dp)) { Icon(icon, null, tint = color, modifier = Modifier.padding(9.dp).size(22.dp)) }
            Text(title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
            Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall, lineHeight = 15.sp)
        }
    }
}

@Composable
private fun DashboardShortcut(title: String, description: String, icon: ImageVector, category: String, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable(onClick = onClick), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = .4f))) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Surface(shape = RoundedCornerShape(13.dp), color = MaterialTheme.colorScheme.primaryContainer) { Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(10.dp).size(23.dp)) }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                Text(description, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                Text(category, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelSmall)
            }
            Icon(Icons.Default.ChevronLeft, null, tint = MaterialTheme.colorScheme.primary)
        }
    }
}

private fun dashboardMoney(value: Double): String = NumberFormat.getNumberInstance(Locale("ar", "EG")).format(value) + " ج.م"
