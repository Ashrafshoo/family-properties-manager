package com.example.rentals.domain.contracts

import com.example.rentals.domain.contracts.ContractLease
import com.example.rentals.domain.contracts.ContractAttachment

/** Data boundary for contracts, reminders and indexed attachments. */
interface ContractRepository {
    fun getLeases(): List<ContractLease>
    fun getAttachments(): List<ContractAttachment>
    fun getReminders(): List<String>
    fun saveLease(id: Long, unitId: Long, start: String, end: String, rent: Double?, status: String, notes: String): Long
    fun deleteLease(id: Long)
    fun addAttachment(ownerType: String, ownerId: String, uri: String, name: String, mime: String, notes: String = "", category: String = "مستند آخر")
    fun deleteAttachment(id: Long)
}
