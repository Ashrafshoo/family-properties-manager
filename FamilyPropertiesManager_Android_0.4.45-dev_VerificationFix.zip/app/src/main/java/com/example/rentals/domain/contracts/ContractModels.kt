package com.example.rentals.domain.contracts

data class ContractLease(
    val id: Long, val unitId: Long, val unitCode: String, val tenant: String,
    val startDate: String, val endDate: String, val rent: Double?, val status: String, val notes: String
)

data class ContractAttachment(
    val id: Long, val ownerType: String, val ownerId: String, val uri: String,
    val name: String, val mime: String, val createdAt: Long, val notes: String, val category: String
)
