package com.example.rentals.files

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import androidx.core.content.FileProvider
import java.io.File
import java.util.UUID

/** Owns the private-file lifecycle for imported attachments. Metadata deletion is intentionally separate. */
class AttachmentFileManager(private val context: Context) {
    data class StoredAttachment(val uri: String, val displayName: String, val mimeType: String, internal val backingFile: File)

    fun import(uri: Uri, ownerType: String, ownerId: String): StoredAttachment {
        require(ownerType.matches(Regex("[A-Za-z0-9_-]{1,32}"))) { "نوع الارتباط غير صالح" }
        require(ownerId.matches(Regex("[A-Za-z0-9_-]{1,80}"))) { "معرّف الارتباط غير صالح" }
        val resolver = context.contentResolver
        val mime = resolver.getType(uri) ?: "application/octet-stream"
        require(isSupported(mime)) { "نوع الملف غير مدعوم" }
        val name = queryDisplayName(uri).ifBlank { "مستند" }
        val extension = safeExtension(mime)
        val folder = File(context.filesDir, "attachments/archive/$ownerType/$ownerId").apply { mkdirs() }
        val destination = File(folder, "${System.currentTimeMillis()}_${UUID.randomUUID()}$extension")
        try {
            val input = resolver.openInputStream(uri) ?: error("تعذر قراءة الملف المحدد")
            input.use { source ->
                destination.outputStream().use { target ->
                    val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                    var total = 0L
                    while (true) {
                        val count = source.read(buffer)
                        if (count < 0) break
                        total += count
                        require(total <= MAX_FILE_BYTES) { "حجم الملف يتجاوز الحد المسموح (50 ميجابايت)" }
                        target.write(buffer, 0, count)
                    }
                }
            }
            require(destination.isFile && destination.length() > 0L) { "الملف المستورد فارغ" }
            val contentUri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", destination)
            return StoredAttachment(contentUri.toString(), name, mime, destination)
        } catch (error: Exception) {
            destination.delete()
            throw error
        }
    }

    /** Roll back a just-imported file only when its metadata insert failed. */
    fun discardUnindexed(stored: StoredAttachment) {
        val root = File(context.filesDir, "attachments").canonicalFile
        val candidate = stored.backingFile.canonicalFile
        require(candidate.path.startsWith(root.path + File.separator)) { "مسار الملف خارج مساحة المرفقات" }
        candidate.delete()
    }

    fun openIntent(uriText: String, mimeType: String): Intent {
        val uri = Uri.parse(uriText)
        require(uri.scheme == "content" || uri.scheme == "https" || uri.scheme == "http") { "مصدر الملف غير صالح" }
        return Intent(Intent.ACTION_VIEW).setDataAndType(uri, mimeType.ifBlank { "*/*" })
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }

    private fun queryDisplayName(uri: Uri): String = runCatching {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) cursor.getString(0).orEmpty() else ""
        }.orEmpty()
    }.getOrDefault("").replace(Regex("[\\r\\n\\\\/]"), "_").take(180)

    private fun isSupported(mime: String): Boolean = mime.startsWith("image/") || mime in setOf(
        "application/pdf", "application/msword",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    )

    private fun safeExtension(mime: String): String = when (mime.lowercase()) {
        "image/jpeg" -> ".jpg"
        "image/png" -> ".png"
        "image/webp" -> ".webp"
        "image/gif" -> ".gif"
        "image/heic", "image/heif" -> ".heic"
        "image/bmp" -> ".bmp"
        "application/pdf" -> ".pdf"
        "application/msword" -> ".doc"
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document" -> ".docx"
        else -> ".img"
    }

    companion object { private const val MAX_FILE_BYTES = 50L * 1024L * 1024L }
}
