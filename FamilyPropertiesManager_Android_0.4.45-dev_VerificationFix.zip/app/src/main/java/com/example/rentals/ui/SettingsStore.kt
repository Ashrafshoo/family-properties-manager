package com.example.rentals.ui

import android.content.Context

/** User interface preferences. Values are validated at the persistence boundary. */
data class UiSettings(
    val dark: Boolean = false,
    val fontScale: Float = 1f,
    val fontFamily: String = "noto",
    val boldText: Boolean = false,
    val backgroundTone: String = "mist",
    val textTone: String = "navy",
    val accent: String = "teal",
    val compact: Boolean = false,
    val aiConsent: Boolean = false,
    val receiptsPerPage: Int = 3,
    val marginMm: Float = 5f,
    val lockOnBackground: Boolean = true,
)

/** SharedPreferences adapter; invalid or legacy values are normalized, never propagated to UI. */
class SettingsStore(context: Context) {
    private val preferences = context.getSharedPreferences("ui_settings", Context.MODE_PRIVATE)

    fun read(): UiSettings = normalize(
        UiSettings(
            dark = preferences.getBoolean("dark", false),
            fontScale = preferences.getFloat("fontScale", 1f),
            fontFamily = preferences.getString("fontFamily", "noto") ?: "noto",
            boldText = preferences.getBoolean("boldText", false),
            backgroundTone = preferences.getString("backgroundTone", "mist") ?: "mist",
            textTone = preferences.getString("textTone", "navy") ?: "navy",
            accent = preferences.getString("accent", "teal") ?: "teal",
            compact = preferences.getBoolean("compact", false),
            aiConsent = preferences.getBoolean("aiConsent", false),
            receiptsPerPage = preferences.getInt("receiptsPerPage", 3),
            marginMm = preferences.getFloat("marginMm", 5f),
            lockOnBackground = preferences.getBoolean("lockOnBackground", true),
        )
    )

    fun save(settings: UiSettings) {
        val safe = normalize(settings)
        preferences.edit()
            .putBoolean("dark", safe.dark)
            .putFloat("fontScale", safe.fontScale)
            .putString("fontFamily", safe.fontFamily)
            .putBoolean("boldText", safe.boldText)
            .putString("backgroundTone", safe.backgroundTone)
            .putString("textTone", safe.textTone)
            .putString("accent", safe.accent)
            .putBoolean("compact", safe.compact)
            .putBoolean("aiConsent", safe.aiConsent)
            .putInt("receiptsPerPage", safe.receiptsPerPage)
            .putFloat("marginMm", safe.marginMm)
            .putBoolean("lockOnBackground", safe.lockOnBackground)
            .apply()
    }

    private fun normalize(value: UiSettings): UiSettings = value.copy(
        fontScale = value.fontScale.takeIf { it.isFinite() }?.coerceIn(MIN_FONT_SCALE, MAX_FONT_SCALE) ?: 1f,
        fontFamily = value.fontFamily.takeIf { it in FONT_FAMILIES } ?: "sans",
        backgroundTone = value.backgroundTone.takeIf { it in BACKGROUNDS } ?: "mist",
        textTone = value.textTone.takeIf { it in TEXT_TONES } ?: "navy",
        accent = value.accent.takeIf { it in ACCENTS } ?: "teal",
        receiptsPerPage = value.receiptsPerPage.coerceIn(MIN_RECEIPTS_PER_PAGE, MAX_RECEIPTS_PER_PAGE),
        marginMm = value.marginMm.takeIf { it.isFinite() }?.coerceIn(MIN_MARGIN_MM, MAX_MARGIN_MM) ?: 5f,
    )

    private companion object {
        const val MIN_FONT_SCALE = 0.65f
        const val MAX_FONT_SCALE = 1.35f
        const val MIN_RECEIPTS_PER_PAGE = 1
        const val MAX_RECEIPTS_PER_PAGE = 3
        const val MIN_MARGIN_MM = 2f
        const val MAX_MARGIN_MM = 12f
        val FONT_FAMILIES = setOf("noto", "sans", "serif", "mono")
        val ACCENTS = setOf("teal", "blue", "olive", "sand", "purple", "rose", "navy")
        val BACKGROUNDS = setOf("mist", "cream", "lavender", "mint", "slate")
        val TEXT_TONES = setOf("navy", "black", "brown", "plum")
    }
}
