package com.example.rentals.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Apartment
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Domain
import androidx.compose.material.icons.filled.FactCheck
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Settings
import androidx.compose.ui.graphics.vector.ImageVector

/** Top-level destinations. Kept independent from screen implementations. */
enum class AppTab(val label: String, val icon: ImageVector) {
    Home("الرئيسية", Icons.Default.Dashboard),
    Units("الوحدات", Icons.Default.Apartment),
    Finance("المالية", Icons.Default.AccountBalanceWallet),
    Print("التحصيل", Icons.Default.ReceiptLong),
    Personal("دفتري", Icons.Default.MenuBook),
    Review("المراجعة", Icons.Default.FactCheck),
    Contracts("العقود والأرشيف", Icons.Default.FolderOpen),
    Entities("العقارات والمستأجرون", Icons.Default.Domain),
    Settings("الإعدادات", Icons.Default.Settings),
}
