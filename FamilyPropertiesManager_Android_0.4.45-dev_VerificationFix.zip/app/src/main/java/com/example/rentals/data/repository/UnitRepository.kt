package com.example.rentals.data.repository

import com.example.rentals.data.RentalsDb
import com.example.rentals.data.UnitRecord

/** Read boundary for unit data. Feature screens should migrate to this contract gradually. */
interface UnitRepository {
    fun getAll(): List<UnitRecord>
}

/** SQLite-backed implementation; keeps the existing schema and query behavior unchanged. */
class SqliteUnitRepository(private val database: RentalsDb) : UnitRepository {
    override fun getAll(): List<UnitRecord> = database.units()
}
