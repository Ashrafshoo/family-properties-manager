package com.example.rentals.domain.entities

import com.example.rentals.data.PropertyRecord
import com.example.rentals.data.TenantRecord

/** Domain boundary for property and tenant directory management. */
interface EntityRepository {
    fun getProperties(): List<PropertyRecord>
    fun getTenants(): List<TenantRecord>
    fun saveProperty(item: PropertyRecord): Long
    fun saveTenant(item: TenantRecord): Long
    fun deleteProperty(id: Long)
    fun deleteTenant(id: Long)
}

data class EntityDirectorySnapshot(
    val properties: List<PropertyRecord>,
    val tenants: List<TenantRecord>
)
