package com.example.rentals.domain.contracts

/** Indexed document metadata boundary. Removing an index entry never deletes the stored file. */
interface DocumentRepository {
    fun list(ownerType: String, ownerId: String): List<ContractAttachment>
    fun add(ownerType: String, ownerId: String, uri: String, name: String, mime: String, notes: String = "", category: String = "مستند آخر")
    fun removeIndex(id: Long)
}
