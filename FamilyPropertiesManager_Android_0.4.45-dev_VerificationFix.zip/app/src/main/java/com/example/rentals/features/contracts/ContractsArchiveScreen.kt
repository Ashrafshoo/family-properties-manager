package com.example.rentals.features.contracts

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.fragment.app.FragmentActivity
import com.example.rentals.domain.contracts.ContractRepository
import com.example.rentals.domain.contracts.GetContractArchive
import com.example.rentals.domain.contracts.SaveContract
import com.example.rentals.domain.contracts.DeleteContract
import com.example.rentals.domain.contracts.AddContractAttachment
import com.example.rentals.domain.contracts.RemoveContractAttachment
import com.example.rentals.data.UnitRecord
import com.example.rentals.files.AttachmentFileManager
import com.example.rentals.ui.components.PremiumScreenHeader
import java.text.NumberFormat
import java.util.Locale

private fun formatContractMoney(value: Double): String =
    NumberFormat.getNumberInstance(Locale("ar", "EG")).format(value) + " ج.م"

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun ContractsArchiveScreen(activity:FragmentActivity,repository:ContractRepository,units:List<UnitRecord>){
    val archive = remember(repository) { GetContractArchive(repository) }
    val saveContract = remember(repository) { SaveContract(repository) }
    val deleteContract = remember(repository) { DeleteContract(repository) }
    val addAttachment = remember(repository) { AddContractAttachment(repository) }
    val removeAttachment = remember(repository) { RemoveContractAttachment(repository) }
    val fileManager = remember(activity) { AttachmentFileManager(activity) }
    var refresh by remember{mutableIntStateOf(0)}
    var showEditor by remember{mutableStateOf(false)}
    var editingLeaseId by remember{mutableLongStateOf(0L)}
    var selectedUnit by remember{mutableStateOf(units.firstOrNull()?.id?.toString()?: "")}
    var start by remember{mutableStateOf(java.time.LocalDate.now().toString())}
    var end by remember{mutableStateOf("")}
    var rent by remember{mutableStateOf("")}
    var status by remember{mutableStateOf("نشط")}
    var notes by remember{mutableStateOf("")}
    var message by remember{mutableStateOf("")}
    var attachOwnerType by remember{mutableStateOf("unit")}
    var attachOwnerId by remember{mutableStateOf(units.firstOrNull()?.id?.toString()?:"")}
    var confirmDeleteLease by remember{mutableStateOf<Long?>(null)}
    var confirmDeleteAttachment by remember{mutableStateOf<Long?>(null)}
    val snapshot = remember(refresh) { archive() }
    val attachments = snapshot.attachments
    val leases = snapshot.leases
    val reminders = snapshot.reminders
    val picker= rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->
        if(uri!=null){try{
            val stored = fileManager.import(uri, attachOwnerType, attachOwnerId)
            try {
                addAttachment(attachOwnerType,attachOwnerId,stored.uri,stored.displayName,stored.mimeType)
            } catch (error: Exception) { fileManager.discardUnindexed(stored); throw error }
            message="تم نسخ المستند إلى مساحة التطبيق الخاصة وربطه بالأرشيف";refresh++
        }catch(e:Exception){message="تعذر حفظ المستند: ${e.message}"}}
    }
    fun beginEdit(id:Long){
        val l=leases.firstOrNull{it.id==id} ?: return
        editingLeaseId=l.id;selectedUnit=l.unitId.toString();start=l.startDate;end=l.endDate
        rent=l.rent?.toString()?: "";status=l.status;notes=l.notes;showEditor=true
    }
    fun beginRenewal(id:Long){
        val previous=leases.firstOrNull{it.id==id} ?: return
        // A renewal is a new lease record; never overwrite the previous contract's dates or terms.
        editingLeaseId=0L;selectedUnit=previous.unitId.toString()
        start=java.time.LocalDate.now().toString();end="";rent=previous.rent?.toString()?:"";status="نشط"
        notes=("تجديد مستقل للعقد السابق رقم ${previous.id}. العقد السابق محفوظ كما هو.\n"+previous.notes).trim()
        showEditor=true
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
        PremiumScreenHeader("العقود والمستندات", "أرشيف العقود والتجديدات والمرفقات والتنبيهات", Icons.Default.Description)
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
            Button(onClick={editingLeaseId=0;selectedUnit=units.firstOrNull()?.id?.toString()?: "";start=java.time.LocalDate.now().toString();end="";rent="";status="نشط";notes="";showEditor=true},modifier=Modifier.weight(1f)){Text("إضافة عقد")}
            OutlinedButton(onClick={picker.launch(arrayOf("application/pdf","image/*","application/msword","application/vnd.openxmlformats-officedocument.wordprocessingml.document"))},modifier=Modifier.weight(1f)){Text("إضافة مستند")}
        }
        Text("العقود المسجلة",fontWeight=FontWeight.Bold)
        if(leases.isEmpty())Text("لا توجد عقود مسجلة بعد",color=MaterialTheme.colorScheme.onSurfaceVariant)
        leases.forEach{l->Card(Modifier.fillMaxWidth(), shape=androidx.compose.foundation.shape.RoundedCornerShape(20.dp), border=androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha=.35f)), elevation=CardDefaults.cardElevation(defaultElevation=1.dp)){
            Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){
                Text("الوحدة ${l.unitCode} – ${l.tenant}",fontWeight=FontWeight.Bold)
                Text("من ${l.startDate} إلى ${l.endDate.ifBlank{"غير محدد"}}")
                Text("الإيجار: ${l.rent?.let{formatContractMoney(it)}?:"غير محدد"} • ${l.status}")
                if(l.notes.isNotBlank())Text(l.notes)
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp),verticalAlignment=Alignment.CenterVertically){
                    TextButton(onClick={beginEdit(l.id)}){Text("تعديل البيانات")}
                    TextButton(onClick={beginRenewal(l.id)}){Text("تسجيل تجديد جديد")}
                    TextButton(onClick={confirmDeleteLease=l.id}){Text("حذف",color=MaterialTheme.colorScheme.error)}
                }
            }
        }}
        HorizontalDivider();Text("أرشيف المستندات",fontWeight=FontWeight.Bold)
        Text("اختر نوع الربط ورقمه قبل إضافة المستند. المستندات القديمة ذات الربط العام ستظل محفوظة.",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
        var ownerExpanded by remember{mutableStateOf(false)}
        ExposedDropdownMenuBox(expanded=ownerExpanded,onExpandedChange={ownerExpanded=it}){
            OutlinedTextField(value=if(attachOwnerType=="unit")"ربط بوحدة" else "ربط بعقد",onValueChange={},readOnly=true,label={Text("نوع المستند المرتبط")},modifier=Modifier.menuAnchor().fillMaxWidth())
            ExposedDropdownMenu(expanded=ownerExpanded,onDismissRequest={ownerExpanded=false}){
                DropdownMenuItem(text={Text("وحدة")},onClick={attachOwnerType="unit";attachOwnerId=units.firstOrNull()?.id?.toString()?: "";ownerExpanded=false})
                DropdownMenuItem(text={Text("عقد")},onClick={attachOwnerType="lease";attachOwnerId=leases.firstOrNull()?.id?.toString()?: "";ownerExpanded=false})
            }
        }
        var targetExpanded by remember{mutableStateOf(false)}
        val targetLabel=if(attachOwnerType=="unit") units.firstOrNull{it.id.toString()==attachOwnerId}?.let{"${it.code} – ${it.tenant}"} else leases.firstOrNull{it.id.toString()==attachOwnerId}?.let{"عقد ${it.id} – ${it.unitCode}"}
        ExposedDropdownMenuBox(expanded=targetExpanded,onExpandedChange={targetExpanded=it}){
            OutlinedTextField(value=targetLabel?:"اختر السجل المرتبط",onValueChange={},readOnly=true,label={Text("السجل المرتبط")},modifier=Modifier.menuAnchor().fillMaxWidth())
            ExposedDropdownMenu(expanded=targetExpanded,onDismissRequest={targetExpanded=false}){
                if(attachOwnerType=="unit") units.forEach{u->DropdownMenuItem(text={Text("${u.code} – ${u.tenant}")},onClick={attachOwnerId=u.id.toString();targetExpanded=false})}
                else leases.forEach{l->DropdownMenuItem(text={Text("عقد ${l.id} – ${l.unitCode}")},onClick={attachOwnerId=l.id.toString();targetExpanded=false})}
            }
        }
        if(attachments.isEmpty())Text("لا توجد مستندات محفوظة بعد",color=MaterialTheme.colorScheme.onSurfaceVariant)
        attachments.forEach{a->
            val ownerLabel=when(a.ownerType){"unit"->"وحدة رقم ${a.ownerId}";"lease"->"عقد رقم ${a.ownerId}";else->"أرشيف عام"}
            ListItem(headlineContent={Text(a.name)},supportingContent={Text("$ownerLabel • ${a.mime} • ${java.text.SimpleDateFormat("yyyy-MM-dd",Locale.US).format(java.util.Date(a.createdAt))}")},leadingContent={Icon(Icons.Default.AttachFile,null)},trailingContent={
                Row { IconButton(onClick={try{activity.startActivity(fileManager.openIntent(a.uri,a.mime))}catch(_:Exception){message="تعذر فتح المستند"}}){Icon(Icons.Default.OpenInNew,"فتح")};IconButton(onClick={confirmDeleteAttachment=a.id}){Icon(Icons.Default.Delete,"حذف",tint=MaterialTheme.colorScheme.error)} }
            })
        }
        HorizontalDivider();Text("التنبيهات",fontWeight=FontWeight.Bold)
        if(reminders.isEmpty())Text("لا توجد تنبيهات عقود قريبة وفق البيانات المسجلة.") else reminders.forEach{ListItem(headlineContent={Text(it)},leadingContent={Icon(Icons.Default.NotificationsActive,null,tint=MaterialTheme.colorScheme.primary)})}
        if(message.isNotBlank())Text(message,color=MaterialTheme.colorScheme.primary)
    }
    if(showEditor) AlertDialog(onDismissRequest={showEditor=false},title={Text(if(editingLeaseId>0)"تعديل بيانات العقد" else if(notes.startsWith("تجديد مستقل للعقد السابق"))"تسجيل تجديد جديد مع الاحتفاظ بالعقد السابق" else "إضافة عقد")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
        var expanded by remember{mutableStateOf(false)}
        ExposedDropdownMenuBox(expanded=expanded,onExpandedChange={expanded=it}){OutlinedTextField(value=units.firstOrNull{it.id.toString()==selectedUnit}?.let{"${it.code} – ${it.tenant}"}?:"اختر الوحدة",onValueChange={},readOnly=true,label={Text("الوحدة")},modifier=Modifier.menuAnchor().fillMaxWidth());ExposedDropdownMenu(expanded=expanded,onDismissRequest={expanded=false}){units.forEach{u->DropdownMenuItem(text={Text("${u.code} – ${u.tenant}")},onClick={selectedUnit=u.id.toString();if(rent.isBlank())rent=u.rent?.toString()?: "";expanded=false})}}}
        OutlinedTextField(start,{start=it},label={Text("بداية العقد YYYY-MM-DD")},singleLine=true)
        OutlinedTextField(end,{end=it},label={Text("نهاية العقد YYYY-MM-DD (اختياري)")},singleLine=true)
        OutlinedTextField(rent,{rent=it},label={Text("قيمة الإيجار (اختياري)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),singleLine=true)
        OutlinedTextField(status,{status=it},label={Text("حالة العقد")},singleLine=true)
        OutlinedTextField(notes,{notes=it},label={Text("ملاحظات")})
    }},confirmButton={TextButton(onClick={try{saveContract(editingLeaseId,selectedUnit.toLong(),start,end,rent.toDoubleOrNull(),status,notes);message=if(editingLeaseId>0)"تم تحديث العقد" else "تم حفظ العقد";showEditor=false;refresh++}catch(e:Exception){message=e.message?:"تعذر حفظ العقد"}}){Text("حفظ")}},dismissButton={TextButton(onClick={showEditor=false}){Text("إلغاء")}})
    if(confirmDeleteLease!=null)AlertDialog(onDismissRequest={confirmDeleteLease=null},title={Text("حذف العقد؟")},text={Text("سيتم حذف سجل العقد فقط. لن تُحذف المستندات المرتبطة به تلقائيًا حتى لا تفقد ملفاتك.")},confirmButton={TextButton(onClick={try{deleteContract(confirmDeleteLease!!);message="تم حذف سجل العقد؛ بقيت مرفقاته محفوظة";refresh++}catch(e:Exception){message=e.message?:"تعذر الحذف"};confirmDeleteLease=null}){Text("حذف")}},dismissButton={TextButton(onClick={confirmDeleteLease=null}){Text("إلغاء")}})
    if(confirmDeleteAttachment!=null)AlertDialog(onDismissRequest={confirmDeleteAttachment=null},title={Text("إزالة المستند من الأرشيف؟")},text={Text("سيُحذف ربط المستند من التطبيق فقط؛ لا نحذف الملف الأصلي من مزود الملفات.")},confirmButton={TextButton(onClick={try{removeAttachment(confirmDeleteAttachment!!);message="تمت إزالة المستند من فهرس الأرشيف";refresh++}catch(e:Exception){message=e.message?:"تعذر الإزالة"};confirmDeleteAttachment=null}){Text("إزالة")}},dismissButton={TextButton(onClick={confirmDeleteAttachment=null}){Text("إلغاء")}})
}

