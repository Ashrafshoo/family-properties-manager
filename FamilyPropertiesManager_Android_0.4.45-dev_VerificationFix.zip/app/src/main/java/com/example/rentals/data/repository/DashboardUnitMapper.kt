package com.example.rentals.data.repository

import com.example.rentals.data.UnitRecord
import com.example.rentals.domain.dashboard.DashboardUnitSnapshot

fun UnitRecord.toDashboardSnapshot(): DashboardUnitSnapshot =
    DashboardUnitSnapshot(rent = rent, status = status)
