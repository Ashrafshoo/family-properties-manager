package com.example.rentals.domain.collection

class PrepareMonthlyCollection(private val repository: MonthlyCollectionRepository) {
    operator fun invoke(period: String, issuedDate: String, unitIds: Set<Long>, propertyFilter: String = ""): Long {
        require(unitIds.isNotEmpty()) { "اختر وحدة واحدة على الأقل" }
        require(unitIds.all { it > 0 }) { "توجد وحدة بمعرّف غير صالح" }
        return repository.createBatch(period.trim(), issuedDate.trim(), unitIds, propertyFilter.trim())
    }
}
