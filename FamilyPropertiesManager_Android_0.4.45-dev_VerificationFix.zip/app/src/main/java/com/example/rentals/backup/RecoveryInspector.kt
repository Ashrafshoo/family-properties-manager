package com.example.rentals.backup

import android.content.Context
import android.net.Uri
import com.example.rentals.data.RentalsDb
import java.io.File

/** Read-only recovery readiness check; it never edits the live database or files. */
data class RecoveryReport(
    val integrity: String,
    val foreignKeyViolations: Int,
    val tableCounts: Map<String, Long>,
    val attachmentFiles: Int,
    val attachmentBytes: Long,
    val missingManagedFiles: Int,
    val externalReferences: Int,
) {
    val healthy: Boolean get() = integrity == "ok" && foreignKeyViolations == 0 && missingManagedFiles == 0 && externalReferences == 0
}

object RecoveryInspector {
    private val tables = listOf(
        "properties", "tenants", "units", "leases", "receipts", "ledger",
        "collector_receivables", "collection_batches", "expenses", "heirs",
        "heir_payouts", "attachments", "audit_log", "monthly_collection_batches",
        "monthly_collection_items", "personal_rent_months", "personal_rent_rows",
        "personal_rent_expenses", "legacy_import_records", "legacy_contract_archive"
    )

    fun inspect(context: Context): RecoveryReport {
        val db = RentalsDb.get(context).readableDatabase
        val integrity = db.rawQuery("PRAGMA integrity_check", null).use {
            if (it.moveToFirst()) it.getString(0) else "unknown"
        }
        val foreignKeys = db.rawQuery("PRAGMA foreign_key_check", null).use { cursor ->
            var count = 0
            while (cursor.moveToNext()) count++
            count
        }
        val counts = linkedMapOf<String, Long>()
        val existing = mutableSetOf<String>()
        db.rawQuery("SELECT name FROM sqlite_master WHERE type='table'", null).use { c ->
            while (c.moveToNext()) existing += c.getString(0)
        }
        tables.filter { it in existing }.forEach { table ->
            counts[table] = db.rawQuery("SELECT COUNT(*) FROM `$table`", null).use {
                if (it.moveToFirst()) it.getLong(0) else 0L
            }
        }
        val attachmentRoot = File(context.filesDir, "attachments")
        val files = if (attachmentRoot.exists()) attachmentRoot.walkTopDown().filter { it.isFile }.toList() else emptyList()
        val managedUris = linkedSetOf<String>()
        fun collect(sql: String, column: Int = 0) {
            runCatching {
                db.rawQuery(sql, null).use { c -> while (c.moveToNext()) c.getString(column)?.takeIf { it.isNotBlank() }?.let(managedUris::add) }
            }
        }
        collect("SELECT uri FROM attachments")
        collect("SELECT document_uri FROM leases")
        collect("SELECT attachment_uri FROM expenses")
        val appAuthority = "${context.packageName}.fileprovider"
        val external = managedUris.count { value ->
            val uri = runCatching { Uri.parse(value) }.getOrNull() ?: return@count true
            uri.scheme != "content" || uri.authority != appAuthority || !Uri.decode(uri.path.orEmpty()).startsWith("/private_attachments/")
        }
        val missing = managedUris.count { value ->
            val uri = runCatching { Uri.parse(value) }.getOrNull() ?: return@count false
            if (uri.scheme != "content" || uri.authority != appAuthority) return@count false
            val rawPath = Uri.decode(uri.path.orEmpty())
            if (!rawPath.startsWith("/private_attachments/")) return@count false
            val path = rawPath.removePrefix("/private_attachments/")
            path.isNotBlank() && !File(attachmentRoot, path).isFile
        }
        return RecoveryReport(
            integrity = integrity,
            foreignKeyViolations = foreignKeys,
            tableCounts = counts,
            attachmentFiles = files.size,
            attachmentBytes = files.sumOf { it.length() },
            missingManagedFiles = missing,
            externalReferences = external,
        )
    }
}
