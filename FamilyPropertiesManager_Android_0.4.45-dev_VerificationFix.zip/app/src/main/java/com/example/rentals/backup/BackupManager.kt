package com.example.rentals.backup

import android.content.Context
import android.net.Uri
import android.database.sqlite.SQLiteDatabase
import com.example.rentals.data.RentalsDb
import java.io.File
import java.security.MessageDigest
import java.util.Base64
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** Local ZIP backup. Attachments are copied into the archive, never referenced by external picker URIs. */
object BackupManager {
    private const val MAX_ENTRIES = 20_000
    private const val MAX_UNCOMPRESSED_BYTES = 1_500L * 1024L * 1024L
    private val requiredTables = setOf("units", "receipts", "ledger", "heirs", "expenses", "attachments")

    fun create(context: Context, destination: Uri, includeDatabase: Boolean, includeAttachments: Boolean) {
        require(includeDatabase || includeAttachments) { "اختر قاعدة البيانات أو المرفقات على الأقل" }
        val dbHelper = RentalsDb.get(context)
        val db = context.getDatabasePath("rentals_local.db")
        dbHelper.closeForBackup()
        try {
            context.contentResolver.openOutputStream(destination, "w")!!.use { out ->
                ZipOutputStream(out).use { zip ->
                    val manifest = mutableListOf<String>()
                    if (includeDatabase) {
                        require(db.exists() && db.length() > 0L) { "قاعدة البيانات غير موجودة" }
                        manifest += add(zip, db, "database/rentals_local.db")
                        // UI preferences are useful recovery data, but authentication secrets are never exported.
                        val uiSettings = File(context.applicationInfo.dataDir, "shared_prefs/ui_settings.xml")
                        if (uiSettings.isFile) manifest += add(zip, uiSettings, "app-settings/ui_settings.xml")
                    }
                    var fileCount = 0
                    if (includeAttachments) {
                        val dir = File(context.filesDir, "attachments")
                        if (dir.exists()) dir.walkTopDown().filter { it.isFile }.forEach { file ->
                            val relative = file.relativeTo(dir).path.replace(File.separatorChar, '/')
                            require(relative.isNotBlank() && !relative.split('/').any { it == ".." }) { "مسار مرفق غير صالح" }
                            manifest += add(zip, file, "attachments/$relative")
                            fileCount++
                        }
                    }
                    zip.putNextEntry(ZipEntry("backup-manifest.txt"))
                    zip.write(("# sha256	size	base64url-path\n" + manifest.joinToString("\n") + "\n").toByteArray(Charsets.UTF_8))
                    zip.closeEntry()
                    zip.putNextEntry(ZipEntry("backup-info.txt"))
                    val hasUiSettings = includeDatabase && File(context.applicationInfo.dataDir, "shared_prefs/ui_settings.xml").isFile
                    zip.write(("RentalsManager backup\nCreated: ${System.currentTimeMillis()}\n" +
                        "Database: $includeDatabase\nAttachments: $includeAttachments\nAttachment files: $fileCount\n" +
                        "UI settings: $hasUiSettings\nAuthentication secrets: excluded\nIntegrity: SHA-256\n").toByteArray())
                    zip.closeEntry()
                }
            }
        } finally {
            RentalsDb.reopen(context)
        }
    }

    /** Extracts and validates everything before touching live data; restores old data if any step fails. */
    fun restore(context: Context, source: Uri, restoreDatabase: Boolean, restoreAttachments: Boolean) {
        require(restoreDatabase || restoreAttachments) { "اختر ما تريد استعادته" }
        val temp = File(context.cacheDir, "restore-safe").apply { deleteRecursively(); mkdirs() }
        val liveDb = context.getDatabasePath("rentals_local.db")
        val rollbackDb = File(context.cacheDir, "restore-previous.db")
        val liveAttachments = File(context.filesDir, "attachments")
        val rollbackAttachments = File(context.cacheDir, "restore-previous-attachments")
        val liveUiSettings = File(context.applicationInfo.dataDir, "shared_prefs/ui_settings.xml")
        val candidateUiSettings = File(temp, "app-settings/ui_settings.xml")
        val rollbackUiSettings = File(context.cacheDir, "restore-previous-ui-settings.xml")
        var helperClosed = false
        var databaseChanged = false
        var attachmentsChanged = false
        var uiSettingsChanged = false
        var hadPreviousUiSettings = false
        var preserveRollbackFiles = false
        try {
            // Extract first. A malformed archive must never close or alter the live database.
            var entries = 0
            var totalBytes = 0L
            val seenEntries = mutableSetOf<String>()
            val root = temp.canonicalFile
            ZipInputStream(context.contentResolver.openInputStream(source)!!).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    entries++
                    require(entries <= MAX_ENTRIES) { "النسخة تحتوي عددًا غير معتاد من الملفات" }
                    val name = entry.name.replace('\\', '/')
                    require(seenEntries.add(name)) { "النسخة تحتوي ملفًا مكرر المسار: $name" }
                    require(!name.startsWith("/") && !name.split('/').any { it == ".." }) { "مسار ملف غير آمن داخل النسخة" }
                    val selected = name == "backup-info.txt" || name == "backup-manifest.txt" ||
                        (restoreDatabase && name in setOf("database/rentals_local.db", "app-settings/ui_settings.xml")) ||
                        (restoreAttachments && name.startsWith("attachments/") && name.length > "attachments/".length)
                    if (selected && !entry.isDirectory) {
                        val target = File(temp, name).canonicalFile
                        require(target.toPath().startsWith(root.toPath())) { "مسار ملف خارج مجلد الاستعادة" }
                        target.parentFile?.mkdirs()
                        target.outputStream().use { output ->
                            val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                            while (true) {
                                val count = zip.read(buffer)
                                if (count < 0) break
                                totalBytes += count
                                require(totalBytes <= MAX_UNCOMPRESSED_BYTES) { "حجم النسخة أكبر من الحد المسموح" }
                                output.write(buffer, 0, count)
                            }
                        }
                    } else {
                        // Count even ignored entries so a ZIP bomb cannot hide in an unselected folder.
                        val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                        while (true) {
                            val count = zip.read(buffer)
                            if (count < 0) break
                            totalBytes += count
                            require(totalBytes <= MAX_UNCOMPRESSED_BYTES) { "حجم النسخة أكبر من الحد المسموح" }
                        }
                    }
                    zip.closeEntry()
                    entry = zip.nextEntry
                }
            }

            verifyManifest(temp, restoreDatabase, restoreAttachments)
            val candidateDb = File(temp, "database/rentals_local.db")
            if (restoreDatabase) validateDatabase(candidateDb)
            val candidateAttachments = File(temp, "attachments")
            if (restoreAttachments) require(candidateAttachments.exists() || archiveHasNoAttachments(temp)) {
                "تعذر استخراج مجلد المرفقات من النسخة"
            }

            if (restoreDatabase) {
                RentalsDb.get(context).closeForBackup()
                helperClosed = true
                require(liveDb.exists()) { "قاعدة البيانات الحالية غير موجودة؛ أوقفنا الاستعادة لحمايتها" }
                liveDb.copyTo(rollbackDb, true)
                databaseChanged = true
                File(liveDb.path + "-wal").delete()
                File(liveDb.path + "-shm").delete()
                candidateDb.copyTo(liveDb, true)
                // Validate the installed copy while the helper is still closed. A successful
                // file copy alone is not proof that the live database can be reopened safely.
                validateDatabase(liveDb)
            }
            if (restoreAttachments) {
                rollbackAttachments.deleteRecursively()
                if (liveAttachments.exists()) liveAttachments.copyRecursively(rollbackAttachments, true)
                attachmentsChanged = true
                liveAttachments.deleteRecursively()
                if (candidateAttachments.exists()) candidateAttachments.copyRecursively(liveAttachments, true)
                verifyDirectoryMirror(candidateAttachments, liveAttachments)
            }
            // Older archives may not contain preferences; in that case retain current settings.
            if (restoreDatabase && candidateUiSettings.isFile) {
                liveUiSettings.parentFile?.mkdirs()
                hadPreviousUiSettings = liveUiSettings.isFile
                if (hadPreviousUiSettings) liveUiSettings.copyTo(rollbackUiSettings, true)
                uiSettingsChanged = true
                candidateUiSettings.copyTo(liveUiSettings, true)
            }
        } catch (e: Exception) {
            // Attempt every rollback independently. A failure restoring one component must
            // never prevent us from restoring the database or settings as well.
            val rollbackFailures = mutableListOf<String>()
            if (attachmentsChanged) runCatching {
                liveAttachments.deleteRecursively()
                if (rollbackAttachments.exists()) rollbackAttachments.copyRecursively(liveAttachments, true)
            }.onFailure { rollbackFailures += "المرفقات: ${it.message ?: "تعذر الاسترجاع"}" }
            if (databaseChanged && rollbackDb.exists()) runCatching {
                liveDb.delete()
                rollbackDb.copyTo(liveDb, true)
                validateDatabase(liveDb)
            }.onFailure { rollbackFailures += "قاعدة البيانات: ${it.message ?: "تعذر الاسترجاع"}" }
            if (uiSettingsChanged) runCatching {
                if (hadPreviousUiSettings && rollbackUiSettings.exists()) rollbackUiSettings.copyTo(liveUiSettings, true)
                else liveUiSettings.delete()
            }.onFailure { rollbackFailures += "إعدادات الواجهة: ${it.message ?: "تعذر الاسترجاع"}" }
            if (rollbackFailures.isNotEmpty()) {
                // Keep the rollback material in cache for manual recovery; do not erase the
                // only remaining copy when automatic rollback itself has failed.
                preserveRollbackFiles = true
                throw IllegalStateException(
                    "فشلت الاستعادة، وتعذر إرجاع بعض البيانات تلقائيًا. احتُفظ بنسخ التراجع داخل مساحة التطبيق. " + rollbackFailures.joinToString("؛ "),
                    e
                )
            }
            throw e
        } finally {
            if (helperClosed) RentalsDb.reopen(context)
            if (!preserveRollbackFiles) {
                rollbackDb.delete()
                rollbackAttachments.deleteRecursively()
                rollbackUiSettings.delete()
            }
            temp.deleteRecursively()
        }
    }

    /** Confirms that every extracted attachment was copied byte-for-byte to its live location. */
    private fun verifyDirectoryMirror(source: File, destination: File) {
        val sourceFiles = if (source.exists()) source.walkTopDown().filter { it.isFile }.toList() else emptyList()
        val destinationFiles = if (destination.exists()) destination.walkTopDown().filter { it.isFile }.toList() else emptyList()
        val sourcePaths = sourceFiles.map { it.relativeTo(source).invariantSeparatorsPath }.toSet()
        val destinationPaths = destinationFiles.map { it.relativeTo(destination).invariantSeparatorsPath }.toSet()
        require(sourcePaths == destinationPaths) { "قائمة المرفقات بعد الاستعادة لا تطابق النسخة" }
        sourceFiles.forEach { original ->
            val restored = File(destination, original.relativeTo(source).path)
            require(original.length() == restored.length()) { "حجم مرفق بعد الاستعادة غير مطابق: ${original.name}" }
            val expected = sha256(original)
            val actual = sha256(restored)
            require(expected.contentEquals(actual)) { "تعذر التحقق من مرفق بعد الاستعادة: ${original.name}" }
        }
    }

    private fun sha256(file: File): ByteArray {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                digest.update(buffer, 0, count)
            }
        }
        return digest.digest()
    }

    private fun archiveHasNoAttachments(temp: File): Boolean {
        val info = File(temp, "backup-info.txt").takeIf { it.exists() }?.readText() ?: return false
        return info.contains("Attachments: true") && info.contains("Attachment files: 0")
    }

    /** New backups carry per-file hashes. Older backups remain restorable for compatibility. */
    private fun verifyManifest(temp: File, restoreDatabase: Boolean, restoreAttachments: Boolean) {
        val manifest = File(temp, "backup-manifest.txt")
        if (!manifest.exists()) return
        val root = temp.canonicalFile
        val manifestedSelected = mutableSetOf<String>()
        manifest.readLines(Charsets.UTF_8).drop(1).filter { it.isNotBlank() }.forEach { line ->
            val parts = line.split('\t')
            require(parts.size == 3) { "سجل سلامة النسخة غير صالح" }
            val expectedHash = parts[0]
            val expectedSize = parts[1].toLongOrNull() ?: throw IllegalArgumentException("حجم ملف غير صالح في سجل السلامة")
            val name = String(Base64.getUrlDecoder().decode(parts[2]), Charsets.UTF_8)
            val selected = (restoreDatabase && name in setOf("database/rentals_local.db", "app-settings/ui_settings.xml")) ||
                (restoreAttachments && name.startsWith("attachments/") && name.length > "attachments/".length)
            if (!selected) return@forEach
            require(manifestedSelected.add(name)) { "سجل السلامة يحتوي مسارًا مكررًا" }
            require(!name.startsWith("/") && !name.contains('\\') && !name.split('/').any { it == ".." || it.isBlank() }) { "مسار غير آمن في سجل السلامة" }
            val file = File(temp, name).canonicalFile
            require(file.toPath().startsWith(root.toPath()) && file.isFile) { "ملف مفقود من النسخة: $name" }
            require(file.length() == expectedSize) { "حجم الملف لا يطابق سجل السلامة: $name" }
            val digest = MessageDigest.getInstance("SHA-256")
            file.inputStream().use { input ->
                val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                while (true) { val n = input.read(buffer); if (n < 0) break; digest.update(buffer, 0, n) }
            }
            val actualHash = digest.digest().joinToString("") { "%02x".format(it) }
            require(actualHash.equals(expectedHash, ignoreCase = true)) { "فشل التحقق من سلامة الملف: $name" }
        }
        val extractedSelected = mutableSetOf<String>()
        if (restoreDatabase && File(temp, "database/rentals_local.db").isFile) extractedSelected += "database/rentals_local.db"
        if (restoreDatabase && File(temp, "app-settings/ui_settings.xml").isFile) extractedSelected += "app-settings/ui_settings.xml"
        if (restoreAttachments) {
            val attachmentRoot = File(temp, "attachments")
            if (attachmentRoot.exists()) attachmentRoot.walkTopDown().filter { it.isFile }.forEach { f ->
                extractedSelected += "attachments/" + f.relativeTo(attachmentRoot).path.replace(File.separatorChar, '/')
            }
        }
        require(extractedSelected == manifestedSelected) { "ملفات النسخة لا تطابق سجل السلامة؛ أُوقفت الاستعادة" }
    }

    private fun validateDatabase(file: File) {
        require(file.exists() && file.length() > 0L) { "النسخة لا تحتوي قاعدة بيانات" }
        val check = SQLiteDatabase.openDatabase(file.absolutePath, null, SQLiteDatabase.OPEN_READONLY)
        try {
            val integrity = check.rawQuery("PRAGMA integrity_check", null).use { if (it.moveToFirst()) it.getString(0) else "" }
            require(integrity == "ok") { "قاعدة البيانات داخل النسخة غير سليمة: $integrity" }
            val found = mutableSetOf<String>()
            check.rawQuery("SELECT name FROM sqlite_master WHERE type='table'", null).use { cursor ->
                while (cursor.moveToNext()) found += cursor.getString(0)
            }
            require(found.containsAll(requiredTables)) { "النسخة لا تحتوي جداول النظام الأساسية" }
        } finally {
            check.close()
        }
    }

    /** Writes one entry and returns a manifest row: hash, byte count, encoded path. */
    private fun add(zip: ZipOutputStream, file: File, name: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        var size = 0L
        zip.putNextEntry(ZipEntry(name))
        file.inputStream().use { input ->
            val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                digest.update(buffer, 0, count)
                zip.write(buffer, 0, count)
                size += count
            }
        }
        zip.closeEntry()
        val hash = digest.digest().joinToString("") { "%02x".format(it) }
        val encodedPath = Base64.getUrlEncoder().withoutPadding().encodeToString(name.toByteArray(Charsets.UTF_8))
        return "$hash\t$size\t$encodedPath"
    }
}
