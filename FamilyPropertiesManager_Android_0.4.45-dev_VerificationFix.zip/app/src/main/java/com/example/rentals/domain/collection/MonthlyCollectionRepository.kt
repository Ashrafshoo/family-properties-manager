package com.example.rentals.domain.collection

import com.example.rentals.data.RentalsDb
import com.example.rentals.data.ReceiptRecord

/** Domain-facing boundary for monthly collector batches. */
interface MonthlyCollectionRepository {
    fun createBatch(period: String, issuedDate: String, selectedUnitIds: Set<Long>, propertyFilter: String = ""): Long
    fun getBatches(): List<RentalsDb.MonthlyBatch>
    fun getBatchReceipts(batchId: Long): List<ReceiptRecord>
    fun getBatchItems(batchId: Long): List<Array<String>>
    fun recordCollectorResult(itemId: Long, status: String, amount: Double?, date: String, notes: String)
}
