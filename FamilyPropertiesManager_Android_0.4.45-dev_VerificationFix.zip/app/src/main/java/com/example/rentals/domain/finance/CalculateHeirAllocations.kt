package com.example.rentals.domain.finance

import java.math.BigDecimal
import java.math.RoundingMode

/** Allocates whole currency cents by largest remainder, without floating-point cent drift. */
class CalculateHeirAllocations {
    operator fun invoke(total: Double, heirs: List<HeirShare>): Map<Long, Double> {
        require(total.isFinite() && total > 0.0) { "أدخل صافي مبلغ موجبًا وصحيحًا" }
        val scaled = total * 100.0
        require(scaled.isFinite() && scaled <= Long.MAX_VALUE.toDouble()) { "المبلغ أكبر من الحد الذي يمكن توزيعه بأمان" }
        require(kotlin.math.abs(scaled - kotlin.math.round(scaled)) < 0.000001) {
            "المبلغ يجب ألا يتجاوز منزلتين عشريتين"
        }
        require(heirs.isNotEmpty()) { "لا توجد قائمة ورثة نشطة للتوزيع" }
        require(heirs.all { it.id > 0L }) { "معرّف أحد الورثة غير صالح" }
        require(heirs.map { it.id }.distinct().size == heirs.size) { "يوجد وارث مكرر في قائمة التوزيع" }
        require(heirs.all { it.share.isFinite() && it.share >= 0.0 }) { "نسب الأنصبة غير صالحة" }
        require(kotlin.math.abs(heirs.sumOf { it.share } - 1.0) < 0.0002) {
            "مجموع أنصبة الورثة النشطين يجب أن يساوي 100٪ قبل التوزيع"
        }

        val totalCents = kotlin.math.round(scaled).toLong()
        val raw = heirs.map { heir ->
            val exact = BigDecimal.valueOf(totalCents).multiply(BigDecimal.valueOf(heir.share))
            val floor = exact.setScale(0, RoundingMode.FLOOR).longValueExact()
            Triple(heir.id, floor, exact.subtract(BigDecimal.valueOf(floor)))
        }
        val remainder = (totalCents - raw.sumOf { it.second }).coerceAtLeast(0L)
        val extraIds = raw.sortedWith(compareByDescending<Triple<Long, Long, BigDecimal>> { it.third }.thenBy { it.first })
            .take(remainder.coerceAtMost(heirs.size.toLong()).toInt()).map { it.first }.toSet()
        return raw.associate { (id, cents, _) ->
            id to (cents + if (id in extraIds) 1L else 0L) / 100.0
        }
    }
}
