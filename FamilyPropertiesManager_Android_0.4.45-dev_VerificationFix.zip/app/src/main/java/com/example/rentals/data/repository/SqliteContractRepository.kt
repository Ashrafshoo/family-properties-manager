package com.example.rentals.data.repository

import com.example.rentals.data.RentalsDb
import com.example.rentals.domain.contracts.ContractRepository
import com.example.rentals.domain.contracts.ContractLease
import com.example.rentals.domain.contracts.ContractAttachment

/** SQLite adapter; preserves the existing schema and database validation rules. */
class SqliteContractRepository(private val database: RentalsDb) : ContractRepository {
    override fun getLeases() = database.leases().map { ContractLease(it.id, it.unitId, it.unitCode, it.tenant, it.startDate, it.endDate, it.rent, it.status, it.notes) }
    override fun getAttachments() = database.attachments().map { ContractAttachment(it.id, it.ownerType, it.ownerId, it.uri, it.name, it.mime, it.createdAt, it.notes, it.category) }
    override fun getReminders() = database.reminders()
    override fun saveLease(id: Long, unitId: Long, start: String, end: String, rent: Double?, status: String, notes: String) =
        database.saveLease(id, unitId, start, end, rent, status, notes)
    override fun deleteLease(id: Long) = database.deleteLease(id)
    override fun addAttachment(ownerType: String, ownerId: String, uri: String, name: String, mime: String, notes: String, category: String) =
        database.addAttachment(ownerType, ownerId, uri, name, mime, notes, category)
    override fun deleteAttachment(id: Long) = database.deleteAttachment(id)
}
