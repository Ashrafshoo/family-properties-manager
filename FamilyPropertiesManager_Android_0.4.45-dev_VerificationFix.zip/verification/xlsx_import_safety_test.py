from pathlib import Path

root = Path(__file__).resolve().parents[1]
source = (root / "app/src/main/java/com/example/rentals/io/WorkbookImporter.kt").read_text()
settings = (root / "app/src/main/java/com/example/rentals/features/settings/SettingsScreen.kt").read_text()

checks = {
    "bounded ZIP entry count": "MAX_ZIP_ENTRIES = 10_000" in source,
    "bounded per-entry expansion": "MAX_ENTRY_BYTES = 32L * 1024L * 1024L" in source,
    "bounded total expansion": "MAX_TOTAL_BYTES = 96L * 1024L * 1024L" in source,
    "duplicate ZIP paths rejected": "!entries.containsKey(name)" in source,
    "unsafe ZIP paths rejected": 'name.split(\'/\').any { it == ".." || it == "." }' in source,
    "relationship traversal rejected": 'normalizedTarget.split(\'/\').any { it == ".." || it == "." }' in source,
    "sheet count bounded": "MAX_SHEETS = 200" in source,
    "row count bounded": "parsedRowCount <= MAX_ROWS_PER_SHEET" in source,
    "column count bounded": "col in 0 until MAX_COLUMNS_PER_SHEET" in source,
    "cell count bounded": "cellCount<=MAX_CELLS_PER_SHEET" in source,
    "rich inline strings are concatenated": "inlineText.append(p.nextText())" in source and '"inlineStr"->inlineText.toString()' in source,
    "Q022 import offered through reviewed staging": 'importQ022.launch(' in settings,
    "Q023 readiness disclosed": "استيراد Q023 الشامل — قيد التجهيز، غير متاح بعد" in settings,
    "Q022 identified as current reference": "ملف Q022 هو مرجع البيانات الحالي" in settings,
}
for label, ok in checks.items():
    print(("PASS" if ok else "FAIL") + ": " + label)
assert all(checks.values())
