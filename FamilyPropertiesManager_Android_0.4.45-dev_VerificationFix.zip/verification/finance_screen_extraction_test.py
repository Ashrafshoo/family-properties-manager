from pathlib import Path

root = Path(__file__).resolve().parents[1]
main = (root / "app/src/main/java/com/example/rentals/MainActivity.kt").read_text(encoding="utf-8")
feature = (root / "app/src/main/java/com/example/rentals/features/finance/FinanceScreen.kt").read_text(encoding="utf-8")
assert "import com.example.rentals.features.finance.FinanceScreen" in main
assert "Tab.Finance->FinanceScreen(financeRepository)" in main
assert "remember(db) { SqliteFinanceRepository(db) }" in main
assert "private fun FinanceScreen" not in main
assert "private fun HeirDistributionDialog" not in main
assert "@Composable\nfun FinanceScreen(repository: FinanceRepository)" in feature
assert "@Composable\nprivate fun HeirDistributionDialog" in feature
for token in (
    "repository.getSummary()", "repository.addLedger(", "repository.addCollectorReceivable(",
    "repository.handoverCollector(", "repository.addExpense(", "repository.getActiveHeirs()",
    "repository.payHeirs(", "CalculateHeirAllocations()",
    "طريقة استلام المبلغ من المحصل مستقلة عن طريقة الدفع لكل وارث",
    "total > available + 0.000001",
):
    assert token in feature, token
assert "formatFinanceMoney(value)" in feature
repo = (root / "app/src/main/java/com/example/rentals/data/repository/FinanceRepository.kt").read_text(encoding="utf-8")
assert "interface FinanceRepository" in repo
assert "class SqliteFinanceRepository" in (root / "app/src/main/java/com/example/rentals/data/repository/SqliteFinanceRepository.kt").read_text(encoding="utf-8")
printing = (root / "app/src/main/java/com/example/rentals/features/printing/MonthlyCollectionScreen.kt").read_text(encoding="utf-8")
assert "import com.example.rentals.features.printing.MonthlyCollectionScreen" in main
assert "Tab.Print->MonthlyCollectionScreen(activity,monthlyCollectionRepository,units,settings)" in main
assert "private fun PrintScreen" not in main
assert "private fun collectionStatusArabic" not in main
for token in ("repository.getBatches()", "repository.getBatchReceipts(", "ReceiptPrintAdapter(activity,rs,3", "ISO_A4", "CollectorSheetPdfExporter.export", "WorkbookExporter.exportRows", "repository.recordCollectorResult(", "تم تجهيز دفعة التحصيل"):
    assert token in printing, token
assert "لا يسجل سدادًا ولا يضيف قيدًا ماليًا" in printing
print("PASS: finance ledger, heir distribution and monthly collection/printing screens extracted with workflows and safeguards preserved.")
