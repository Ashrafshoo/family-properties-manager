from pathlib import Path
root = Path(__file__).resolve().parents[1]
main = (root / 'app/src/main/java/com/example/rentals/MainActivity.kt').read_text(encoding='utf-8')
feature = (root / 'app/src/main/java/com/example/rentals/features/units/UnitsScreen.kt').read_text(encoding='utf-8')
assert 'import com.example.rentals.features.units.UnitsScreen' in main
assert 'Tab.Units->UnitsScreen(activity,db,units,settings.compact' in main
assert 'private fun UnitsScreen' not in main
assert '@Composable fun UnitsScreen' in feature
for token in ('UnitEditor(', 'UnitDocumentsDialog(', 'ActivityResultContracts.TakePicture()', 'ActivityResultContracts.OpenMultipleDocuments()', 'SqliteDocumentRepository(db)', 'AddOwnerDocument(documents)', 'GetOwnerDocuments(documents)', 'getDocuments("unit",unit.id.toString())', 'FileProvider.getUriForFile', 'application/pdf', 'application/msword', 'wordprocessingml.document'):
    assert token in feature, f'missing unit workflow: {token}'
print('PASS: units screen, editor, camera and document workflows extracted and connected')
