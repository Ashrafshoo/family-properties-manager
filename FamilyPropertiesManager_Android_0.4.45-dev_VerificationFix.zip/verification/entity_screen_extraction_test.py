from pathlib import Path
root = Path(__file__).resolve().parents[1]
main = (root / "app/src/main/java/com/example/rentals/MainActivity.kt").read_text(encoding="utf-8")
feature = (root / "app/src/main/java/com/example/rentals/features/entities/EntityManagementScreen.kt").read_text(encoding="utf-8")
assert "import com.example.rentals.features.entities.EntityManagementScreen" in main
assert "Tab.Entities->EntityManagementScreen(entityRepository)" in main and "SqliteEntityRepository(db)" in main
assert "private fun EntityManagementScreen" not in main
assert "@Composable fun EntityManagementScreen(repository: EntityRepository)" in feature
assert "GetEntityDirectory(repository)" in feature
assert "saveProperty(item.copy" in feature and "saveTenant(item.copy" in feature
assert "deleteProperty(p.id)" in feature and "deleteTenant(t.id)" in feature
print("PASS: entity management screen uses the repository boundary and remains connected to SQLite.")
