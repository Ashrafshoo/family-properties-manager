from pathlib import Path
root = Path(__file__).resolve().parents[1]
ui = (root / 'app/src/main/java/com/example/rentals/MainActivity.kt').read_text()
settings = (root / 'app/src/main/java/com/example/rentals/features/settings/SettingsScreen.kt').read_text()
combined = ui + settings
checks = {
    'document picker lifecycle exempted while active': 'event == Lifecycle.Event.ON_STOP && !pickerInProgressState.value' in ui,
    'Q022 picker is reachable from settings': 'importQ022.launch(' in settings,
    'picker activity flag cleared on return': 'importQ022=rememberLauncherForActivityResult' in settings and 'setExternalPickerInProgress(false)' in settings,
    'one confirmation stages and migrates': 'ReviewedRentalsWorkbookImporter.stage(ctx.contentResolver,selectedUri,db.writableDatabase)' in settings and 'db.migrateUniquelyMatchedLegacyUnitsToReview()' in settings,
    'work moved off main thread': 'withContext(Dispatchers.IO)' in settings,
    'completion summary displayed after import': 'onImportComplete(completedSummary!!)' in settings and 'importSummary.isNotBlank()' in ui,
    'bottom navigation opens full-height section menu': 'onClick = { moreExpanded = true }' in ui and 'ModalBottomSheet(' in ui and 'Tab.Settings' in ui and 'كل أقسام أملاك العائلة' in ui,
    'navigation labels kept to one line': 'maxLines = 1, softWrap = false, fontSize = 10.sp' in ui,
    'Q022 current source and Q023 pending are disclosed': 'ملف Q022 هو مرجع البيانات الحالي' in settings and 'استيراد Q023 الشامل — قيد التجهيز، غير متاح بعد' in settings,
    'Q022 import is staged and non-financial': 'حفظه للمراجعة' in settings and 'لن ينشئ هذا الاستيراد إيصالات مدفوعة أو تحصيلات أو قيودًا مالية' in settings,
}
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + name)
assert all(checks.values())
