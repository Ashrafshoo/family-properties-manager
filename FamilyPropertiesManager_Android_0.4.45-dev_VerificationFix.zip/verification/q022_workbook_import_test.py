from pathlib import Path
root = Path(__file__).resolve().parents[1]
importer = (root / "app/src/main/java/com/example/rentals/io/ReviewedRentalsWorkbookImporter.kt").read_text()
settings = (root / "app/src/main/java/com/example/rentals/features/settings/SettingsScreen.kt").read_text()
review = (root / "app/src/main/java/com/example/rentals/features/review/ReviewScreen.kt").read_text()
checks = {
    "Q022 unique-name match sheet is staged": '"مطابقة الإيصالات Q022" to "receipt_match_q022_source"' in importer,
    "Q022 duplicate-name sheet is staged separately": '"حالات الاسم المكرر Q022" to "receipt_duplicate_q022_source"' in importer,
    "Q022 summary and closure sheets are preserved": '"ملخص مطابقة Q022"' in importer and '"متابعة الإغلاق Q022"' in importer,
    "Q022 header rows are recognized": 'joined.contains("رقم الإيصال في التفاصيل")' in importer and 'joined.contains("نتيجة المطابقة الآلية بالاسم")' in importer,
    "Q022 match evidence is explicitly non-final": 'لا يمثل اعتمادًا نهائيًا' in importer and 'لا تدمج الوحدات' in importer,
    "XLSX input and expansion are bounded": 'MAX_WORKBOOK_BYTES' in importer and 'MAX_ENTRY_BYTES' in importer and 'MAX_TOTAL_EXPANDED_BYTES' in importer,
    "XLSX sheet, row, column and cell counts are bounded": all(k in importer for k in ['MAX_SHEETS', 'MAX_ROWS_PER_SHEET', 'MAX_COLUMNS_PER_SHEET', 'MAX_CELLS_PER_SHEET']),
    "worksheet relationship paths are validated": 'مسار ورقة غير آمن داخل ملف Q022' in importer and 'target.startsWith("/xl/")' in importer,
    "absolute OPC worksheet targets are normalized safely": 'target.removePrefix("/").removePrefix("./")' in importer and 'normalizedTarget.startsWith("xl/")' in importer,
    "staging uses a database transaction": 'db.beginTransaction()' in importer and 'db.setTransactionSuccessful()' in importer,
    "source Excel row numbers are preserved across blank rows": 'currentRowNumber = p.getAttributeValue(null, "r")' in importer and 'while (rows.size < currentRowNumber - 1)' in importer,
    "Q022 picker is visible": 'اختيار ملف Q022 الحالي وحفظه للمراجعة' in settings,
    "Q022 evidence types are filterable in review center": all(k in review for k in ['receipt_match_q022_source', 'receipt_match_summary_q022_source', 'receipt_duplicate_q022_source', 'receipt_match_followup_q022_source']),
    "Q022 does not auto-create receipts or financial entries": 'لن ينشئ هذا الاستيراد إيصالات مدفوعة أو تحصيلات أو قيودًا مالية' in settings,
}
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + name)
assert all(checks.values())
