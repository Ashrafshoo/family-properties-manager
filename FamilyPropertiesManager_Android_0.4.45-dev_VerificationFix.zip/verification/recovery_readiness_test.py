from pathlib import Path

root = Path(__file__).resolve().parents[1]
backup = (root / 'app/src/main/java/com/example/rentals/backup/BackupManager.kt').read_text()
encrypted = (root / 'app/src/main/java/com/example/rentals/backup/EncryptedBackup.kt').read_text()
inspector = (root / 'app/src/main/java/com/example/rentals/backup/RecoveryInspector.kt').read_text()
settings = (root / 'app/src/main/java/com/example/rentals/features/settings/SettingsScreen.kt').read_text()

assert 'app-settings/ui_settings.xml' in backup
assert 'app-settings/ui_settings.xml' in encrypted
assert 'Authentication secrets: excluded' in backup
assert 'Authentication secrets: excluded' in encrypted
assert 'candidateUiSettings.copyTo(liveUiSettings, true)' in backup
assert 'rollbackUiSettings.copyTo(liveUiSettings, true)' in backup
assert 'validateDatabase(candidateDb)' in backup
assert 'verifyManifest(temp, restoreDatabase, restoreAttachments)' in backup
assert 'PRAGMA integrity_check' in inspector
assert 'PRAGMA foreign_key_check' in inspector
assert 'missingManagedFiles' in inspector
assert 'externalReferences' in inspector
assert 'مراجع ملفات خارجية غير مضمونة في النسخة' in settings
assert 'RecoveryInspector.inspect(ctx)' in settings
assert 'إنشاء نسخة احتياطية كاملة (ZIP)' in settings
assert 'استعادة نسخة احتياطية ZIP' in settings
assert 'قاعدة البيانات والمرفقات معًا' in settings
print('PASS: complete backup includes database, attachments and UI settings; restore validation, rollback and readiness diagnostics are wired.')
