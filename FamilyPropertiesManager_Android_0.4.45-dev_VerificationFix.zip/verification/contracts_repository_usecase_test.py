from pathlib import Path
import subprocess
import tempfile

root = Path(__file__).resolve().parents[1]
base = root / 'app/src/main/java/com/example/rentals/domain/contracts'
repository = base / 'ContractRepository.kt'
models = base / 'ContractModels.kt'
usecases = base / 'ContractUseCases.kt'
adapter = root / 'app/src/main/java/com/example/rentals/data/repository/SqliteContractRepository.kt'
program = r'''import com.example.rentals.domain.contracts.*
import com.example.rentals.data.RentalsDb
import com.example.rentals.data.repository.SqliteContractRepository

private class FakeContracts : ContractRepository {
    val leaseRows = mutableListOf(ContractLease(1, 10, "U-10", "مستأجر", "2026-01-01", "2026-12-31", 1200.0, "نشط", "قديم"))
    val attachmentRows = mutableListOf(ContractAttachment(2, "lease", "1", "content://doc", "عقد.pdf", "application/pdf", 10L, "", "عقد"))
    val reminderRows = listOf("تنبيه تجريبي")
    var savedId = -1L
    var deletedLease = -1L
    var deletedAttachment = -1L
    override fun getLeases() = leaseRows.toList()
    override fun getAttachments() = attachmentRows.toList()
    override fun getReminders() = reminderRows
    override fun saveLease(id: Long, unitId: Long, start: String, end: String, rent: Double?, status: String, notes: String): Long { savedId = if (id > 0) id else 99L; return savedId }
    override fun deleteLease(id: Long) { deletedLease = id }
    override fun addAttachment(ownerType: String, ownerId: String, uri: String, name: String, mime: String, notes: String, category: String) { attachmentRows += ContractAttachment(3, ownerType, ownerId, uri, name, mime, 11L, notes, category) }
    override fun deleteAttachment(id: Long) { deletedAttachment = id }
}
fun main() {
    val repo = FakeContracts()
    val snapshot = GetContractArchive(repo)()
    check(snapshot.leases.single().tenant == "مستأجر")
    check(snapshot.attachments.single().name == "عقد.pdf")
    check(snapshot.reminders == listOf("تنبيه تجريبي"))
    check(SaveContract(repo)(0, 10, "2026-11-13", "", 1200.0, "نشط", "تجديد") == 99L)
    DeleteContract(repo)(1); check(repo.deletedLease == 1L)
    AddContractAttachment(repo)("unit", "10", "content://new", "صورة.jpg", "image/jpeg")
    check(repo.attachmentRows.size == 2)
    RemoveContractAttachment(repo)(2); check(repo.deletedAttachment == 2L)
    val db = RentalsDb()
    val sqlite = SqliteContractRepository(db)
    check(sqlite.getLeases().single().unitCode == "DB-U")
    check(sqlite.getAttachments().single().name == "DB.pdf")
    check(sqlite.saveLease(0, 5, "2026-11-13", "", 50.0, "نشط", "") == 77L)
    sqlite.addAttachment("unit", "5", "content://db", "x", "image/jpeg")
    sqlite.deleteLease(77L); sqlite.deleteAttachment(8L)
    check(db.deletedLease == 77L && db.deletedAttachment == 8L)
    println("PASS: contract repository/use cases and SQLite adapter contract; archive read, save, delete, attachment lifecycle")
}
'''
with tempfile.TemporaryDirectory() as td:
    src = Path(td) / 'ContractUseCaseCheck.kt'
    stub = Path(td) / 'RentalsDbStub.kt'
    stub.write_text("""package com.example.rentals.data
class RentalsDb {
    data class LeaseRow(val id:Long,val unitId:Long,val unitCode:String,val tenant:String,val startDate:String,val endDate:String,val rent:Double?,val status:String,val notes:String)
    data class AttachmentRow(val id:Long,val ownerType:String,val ownerId:String,val uri:String,val name:String,val mime:String,val createdAt:Long,val notes:String,val category:String)
    var deletedLease=0L; var deletedAttachment=0L
    fun leases()=listOf(LeaseRow(4,5,\"DB-U\",\"Tenant\",\"2026-01-01\",\"\",50.0,\"نشط\",\"\"))
    fun attachments()=listOf(AttachmentRow(8,\"unit\",\"5\",\"content://db\",\"DB.pdf\",\"application/pdf\",1L,\"\",\"عقد\"))
    fun reminders()=listOf(\"Reminder\")
    fun saveLease(id:Long,unitId:Long,start:String,end:String,rent:Double?,status:String,notes:String)=77L
    fun deleteLease(id:Long){deletedLease=id}
    fun addAttachment(ownerType:String,ownerId:String,uri:String,name:String,mime:String,notes:String,category:String){}
    fun deleteAttachment(id:Long){deletedAttachment=id}
}
""", encoding='utf-8')
    jar = Path(td) / 'check.jar'
    src.write_text(program, encoding='utf-8')
    compile = subprocess.run(['kotlinc', str(models), str(repository), str(usecases), str(adapter), str(stub), str(src), '-include-runtime', '-d', str(jar)], capture_output=True, text=True)
    if compile.returncode:
        raise RuntimeError(compile.stderr)
    result = subprocess.run(['java', '-jar', str(jar)], check=True, capture_output=True, text=True)
    print(result.stdout.strip())
