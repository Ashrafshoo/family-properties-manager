from pathlib import Path
root = Path(__file__).resolve().parents[1]
main = (root / 'app/src/main/java/com/example/rentals/MainActivity.kt').read_text(encoding='utf-8')
dashboard = (root / 'app/src/main/java/com/example/rentals/features/dashboard/Dashboard.kt').read_text(encoding='utf-8')
repo = (root / 'app/src/main/java/com/example/rentals/data/repository/UnitRepository.kt').read_text(encoding='utf-8')
mapper = (root / 'app/src/main/java/com/example/rentals/data/repository/DashboardUnitMapper.kt').read_text(encoding='utf-8')
usecase = (root / 'app/src/main/java/com/example/rentals/domain/dashboard/DashboardOverview.kt').read_text(encoding='utf-8')
assert 'import com.example.rentals.features.dashboard.Dashboard' in main
assert 'Tab.Home->Dashboard(units.map { it.toDashboardSnapshot() }){tab=it}' in main
assert 'private fun Dashboard(' not in main
assert 'remember(db) { SqliteUnitRepository(db) }' in main
assert 'unitRepository.getAll()' in main
assert 'interface UnitRepository' in repo and 'class SqliteUnitRepository' in repo
assert 'class BuildDashboardOverview' in usecase
assert 'data class DashboardUnitSnapshot' in usecase
assert 'toDashboardSnapshot' in mapper
assert 'Tab.Home->Dashboard(units.map { it.toDashboardSnapshot() }){tab=it}' in main
assert 'fun Dashboard(units: List<DashboardUnitSnapshot>, onNavigate: (AppTab) -> Unit)' in dashboard
for tab in ('AppTab.Units', 'AppTab.Finance', 'AppTab.Review', 'AppTab.Print', 'AppTab.Contracts', 'AppTab.Settings'):
    assert tab in dashboard, f'missing dashboard navigation: {tab}'
assert 'clickable(onClick = onClick)' in dashboard
assert 'لا يُفترض أنه أول الشهر' in dashboard
assert 'السجلات المشمولة' in dashboard
assert 'الإيجار المسجل أو وجود إيصال لا يثبت التحصيل الفعلي' in dashboard
assert 'أول كل شهر ميلادي' not in dashboard
print('PASS: dashboard corrected and connected to a first SQLite repository/use-case boundary')
