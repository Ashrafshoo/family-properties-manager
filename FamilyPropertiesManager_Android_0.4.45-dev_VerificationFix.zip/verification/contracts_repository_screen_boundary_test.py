from pathlib import Path
root = Path(__file__).resolve().parents[1]
screen = (root / 'app/src/main/java/com/example/rentals/features/contracts/ContractsArchiveScreen.kt').read_text(encoding='utf-8')
main = (root / 'app/src/main/java/com/example/rentals/MainActivity.kt').read_text(encoding='utf-8')
adapter = (root / 'app/src/main/java/com/example/rentals/data/repository/SqliteContractRepository.kt').read_text(encoding='utf-8')
checks = {
    'contracts screen depends on domain repository': 'repository:ContractRepository' in screen and 'RentalsDb' not in screen,
    'screen delegates archive reads to use case': 'GetContractArchive(repository)' in screen,
    'screen delegates all writes to use cases': all(x in screen for x in ['SaveContract(repository)', 'DeleteContract(repository)', 'AddContractAttachment(repository)', 'RemoveContractAttachment(repository)']),
    'SQLite adapter remains the only database adapter': 'database.saveLease' in adapter and 'database.addAttachment' in adapter,
    'application injects repository': 'SqliteContractRepository(db)' in main and 'ContractsArchiveScreen(activity,contractRepository,units)' in main,
    'domain models do not expose RentalsDb types': 'RentalsDb' not in (root / 'app/src/main/java/com/example/rentals/domain/contracts/ContractModels.kt').read_text(encoding='utf-8'),
}
for label, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + label)
if not all(checks.values()):
    raise SystemExit(1)
