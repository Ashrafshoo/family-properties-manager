from pathlib import Path
import subprocess
import tempfile

root = Path(__file__).resolve().parents[1]
models = root / 'app/src/main/java/com/example/rentals/domain/finance/FinanceModels.kt'
usecase = root / 'app/src/main/java/com/example/rentals/domain/finance/CalculateHeirAllocations.kt'
program = r'''import com.example.rentals.domain.finance.HeirShare
import com.example.rentals.domain.finance.CalculateHeirAllocations

fun main() {
    val heirs = listOf(HeirShare(1, "أ", 1.0/7.0), HeirShare(2, "ب", 2.0/7.0), HeirShare(3, "ج", 4.0/7.0))
    val result = CalculateHeirAllocations()(100.0, heirs)
    check(result[1] == 14.29 && result[2] == 28.57 && result[3] == 57.14) { "largest remainder must distribute cents deterministically: $result" }
    check(kotlin.math.abs(result.values.sum() - 100.0) < 0.000001) { "allocated cents must equal the source total" }
    check(runCatching { CalculateHeirAllocations()(1.001, heirs) }.isFailure) { "more than two decimals must be rejected" }
    check(runCatching { CalculateHeirAllocations()(Double.NaN, heirs) }.isFailure) { "non-finite total must be rejected" }
    check(runCatching { CalculateHeirAllocations()(100.0, heirs + heirs.first()) }.isFailure) { "duplicate heir IDs must be rejected" }
    check(runCatching { CalculateHeirAllocations()(100.0, heirs.dropLast(1)) }.isFailure) { "shares not totaling 100% must be rejected" }
    check(runCatching { CalculateHeirAllocations()(100.0, heirs.map { it.copy(id = 0) }) }.isFailure) { "invalid heir IDs must be rejected" }
    check(runCatching { CalculateHeirAllocations()(Double.MAX_VALUE, heirs) }.isFailure) { "cent overflow must be rejected" }
    val equal = CalculateHeirAllocations()(0.05, listOf(HeirShare(11, "أ", 0.5), HeirShare(12, "ب", 0.5)))
    check(equal.values.sum() == 0.05 && equal[11] == 0.03 && equal[12] == 0.02) { "equal fractional cents must resolve deterministically by heir ID: $equal" }
    println("PASS: heir allocation use case; deterministic cents, 100% share validation, and invalid-input guards")
}
'''
with tempfile.TemporaryDirectory() as td:
    source = Path(td) / 'FinanceAllocationCheck.kt'
    jar = Path(td) / 'check.jar'
    source.write_text(program, encoding='utf-8')
    subprocess.run(['kotlinc', str(models), str(usecase), str(source), '-include-runtime', '-d', str(jar)], check=True, capture_output=True, text=True)
    result = subprocess.run(['java', '-jar', str(jar)], check=True, capture_output=True, text=True)
    print(result.stdout.strip())
