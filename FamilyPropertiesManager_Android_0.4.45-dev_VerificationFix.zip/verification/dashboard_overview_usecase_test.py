from pathlib import Path
import subprocess
import tempfile

root = Path(__file__).resolve().parents[1]
usecase = root / 'app/src/main/java/com/example/rentals/domain/dashboard/DashboardOverview.kt'
program = r'''import com.example.rentals.domain.dashboard.DashboardUnitSnapshot
import com.example.rentals.domain.dashboard.BuildDashboardOverview

fun main() {
    val units = listOf(
        DashboardUnitSnapshot(rent=1000.0, status="نشطة"),
        DashboardUnitSnapshot(rent=500.0, status="متوقف عن الدفع"),
        DashboardUnitSnapshot(rent=null, status="تغيير مستأجر"),
        DashboardUnitSnapshot(rent=300.0, status="مغلقة"),
        DashboardUnitSnapshot(rent=400.0, status="مباعة"),
        DashboardUnitSnapshot(rent=200.0, status="مكرر"),
        DashboardUnitSnapshot(rent=Double.NaN, status="نشطة")
    )
    val result = BuildDashboardOverview()(units)
    check(result.totalRecords == 7) { "all source records must remain countable" }
    check(result.includedOperationalRecords == 4) { "payment stoppage must not be treated as a sold/closed unit" }
    check(result.registeredRentTotal == 1500.0) { "registered rent total must exclude closed/sold/duplicate records" }
    check(result.needsReviewCount == 2) { "missing current rent must be flagged for review" }
    println("PASS: dashboard overview semantics; no collection or arrears inference")
}
'''
with tempfile.TemporaryDirectory() as td:
    test_file = Path(td) / 'DashboardOverviewCheck.kt'
    jar = Path(td) / 'check.jar'
    test_file.write_text(program, encoding='utf-8')
    subprocess.run(['kotlinc', str(usecase), str(test_file), '-include-runtime', '-d', str(jar)], check=True, capture_output=True, text=True)
    result = subprocess.run(['java', '-jar', str(jar)], check=True, capture_output=True, text=True)
    print(result.stdout.strip())
