from pathlib import Path
p = Path(__file__).resolve().parents[1] / 'app/src/main/java/com/example/rentals/features/personal/PersonalRentNotebook.kt'
s = p.read_text(encoding='utf-8')
assert 'import androidx.compose.material.icons.filled.ShowChart' in s
assert 'Icons.Default.ShowChart' in s
assert 'AutoGraph' not in s
print('PASS: personal notebook uses the supported ShowChart material icon; unresolved AutoGraph reference removed.')
