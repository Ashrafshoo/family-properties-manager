from pathlib import Path
root = Path(__file__).resolve().parents[1]
finance = (root / "app/src/main/java/com/example/rentals/features/finance/FinanceScreen.kt").read_text()
components = (root / "app/src/main/java/com/example/rentals/ui/components/PropertyComponents.kt").read_text()
checks = {
    "FinanceScreen imports Modifier": "import androidx.compose.ui.Modifier" in finance,
    "FinanceScreen imports Icons receiver": "import androidx.compose.material.icons.Icons" in finance,
    "FinanceScreen imports AccountBalanceWallet extension": "import androidx.compose.material.icons.filled.AccountBalanceWallet" in finance,
    "material icons extended dependency exists": 'implementation("androidx.compose.material:material-icons-extended")' in (root / "app/build.gradle.kts").read_text(),
    "PropertyComponents imports KeyboardOptions from foundation.text": "import androidx.compose.foundation.text.KeyboardOptions" in components,
    "PropertyComponents no longer imports KeyboardOptions from ui.text.input": "import androidx.compose.ui.text.input.KeyboardOptions" not in components,
}
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + name)
assert all(checks.values())
