from pathlib import Path
root = Path(__file__).resolve().parents[1]
base = root / 'app/src/main'
theme = (base / 'java/com/example/rentals/design/AppTheme.kt').read_text(encoding='utf-8')
dashboard = (base / 'java/com/example/rentals/features/dashboard/Dashboard.kt').read_text(encoding='utf-8')
components = (base / 'java/com/example/rentals/ui/components/PropertyComponents.kt').read_text(encoding='utf-8')
main = (base / 'java/com/example/rentals/MainActivity.kt').read_text(encoding='utf-8')
settings = (base / 'java/com/example/rentals/features/settings/SettingsScreen.kt').read_text(encoding='utf-8')
gradle = (root / 'app/build.gradle.kts').read_text(encoding='utf-8')
for token in ('DeepNavy', 'Gold', 'Teal', 'primaryContainer', 'surfaceVariant', 'displayLarge =', 'labelSmall =', 'ArabicFontFamily', 'noto_sans_arabic_regular'):
    assert token in theme, f'missing design token/style: {token}'
for token in ('DashboardHero()', 'Brush.linearGradient', 'RoundedCornerShape(26.dp)', 'DashboardMetric(', 'DashboardShortcut(', 'لا يثبت التحصيل الفعلي'):
    assert token in dashboard, f'missing dashboard experience feature: {token}'
for token in ('RoundedCornerShape(15.dp)', 'RoundedCornerShape(19.dp)', 'OutlinedTextFieldDefaults.colors', 'fun BrandTopBar', 'app_logo_master', 'horizontalGradient'):
    assert token in components, f'missing shared component/brand styling: {token}'
for token in ('BrandTopBar(onBack =', 'onRefresh =', 'NavigationBar(', 'ModalBottomSheet(', 'skipPartiallyExpanded = true', 'statusBarColor = if (settings.dark)'):
    assert token in main, f'missing app shell appearance: {token}'
for name in ('noto_sans_arabic_regular.ttf', 'noto_sans_arabic_medium.ttf', 'noto_sans_arabic_semibold.ttf', 'noto_sans_arabic_bold.ttf'):
    assert (base / 'res/font' / name).is_file(), f'missing bundled Arabic font: {name}'
for relative in (
    'java/com/example/rentals/features/review/ReviewScreen.kt',
    'java/com/example/rentals/features/entities/EntityManagementScreen.kt',
    'java/com/example/rentals/features/personal/PersonalRentNotebook.kt',
    'java/com/example/rentals/features/units/UnitsScreen.kt',
    'java/com/example/rentals/features/contracts/ContractsArchiveScreen.kt',
    'java/com/example/rentals/features/finance/FinanceScreen.kt',
    'java/com/example/rentals/features/printing/MonthlyCollectionScreen.kt',
    'java/com/example/rentals/features/settings/SettingsScreen.kt',
):
    source = (base / relative).read_text(encoding='utf-8')
    assert 'PremiumScreenHeader' in source, f'missing specialist screen header: {relative}'
assert 'versionCode = 72' in gradle and 'versionName = "0.4.48-dev"' in gradle, 'release identity mismatch'
assert 'Noto Sans Arabic' in settings and 'خط عريض وواضح' in settings and 's.boldText' in settings and 'لون خلفية التطبيق' in settings and 'لون الكتابة' in settings, 'bundled Arabic font is not exposed in settings'
assert 'backgroundTone' in theme and 'textTone' in theme
assert 'دفتري الخاص' in (base / 'java/com/example/rentals/features/personal/PersonalRentNotebook.kt').read_text(encoding='utf-8')
assert 'كل أقسام أملاك العائلة' in main and 'boldText' in theme
print('PASS: brand shell, full-height section menu, typography controls, personal notebook redesign, bundled Arabic font, specialist headers, dashboard design, and release identity.')
