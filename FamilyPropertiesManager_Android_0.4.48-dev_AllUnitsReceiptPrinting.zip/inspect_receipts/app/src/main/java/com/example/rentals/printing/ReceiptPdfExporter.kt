package com.example.rentals.printing

import android.content.ContentResolver
import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import android.net.Uri
import com.example.rentals.data.ReceiptRecord
import java.util.Locale

/** Creates a standalone PDF containing the same original receipt artwork used by Android printing. */
object ReceiptPdfExporter {
    fun export(context: Context, resolver: ContentResolver, uri: Uri, receipts: List<ReceiptRecord>, perPage: Int = 3, marginMm: Float = 5f, oldLawTemplate: Boolean = true) {
        require(receipts.isNotEmpty()) { "لا توجد إيصالات في هذه الدفعة" }
        val count = perPage.coerceIn(1, 3)
        val document = PdfDocument()
        val bitmaps = mutableMapOf<Int, android.graphics.Bitmap>()
        try {
            val pages = (receipts.size + count - 1) / count
            for (pageNo in 0 until pages) {
                val page = document.startPage(PdfDocument.PageInfo.Builder(595, 842, pageNo + 1).create())
                val margin = marginMm * 2.8346f
                val gap = 5f
                val slotHeight = (842f - 2f * margin - (count - 1) * gap) / count
                for (slot in 0 until count) {
                    val index = pageNo * count + slot
                    if (index >= receipts.size) break
                    val receipt = receipts[index]
                    val suffix = (slot + 1).coerceIn(1, 3)
                    val name = "receipt_${if (oldLawTemplate) "old" else "new"}_$suffix"
                    val drawableId = context.resources.getIdentifier(name, "drawable", context.packageName)
                    require(drawableId != 0) { "قالب الإيصال غير موجود: $name" }
                    val bitmap = bitmaps.getOrPut(slot) { BitmapFactory.decodeResource(context.resources, drawableId) ?: error("تعذر تحميل قالب الإيصال: $name") }
                    val rect = RectF(margin, margin + slot * (slotHeight + gap), 595f - margin, margin + slot * (slotHeight + gap) + slotHeight)
                    page.canvas.drawBitmap(bitmap, null, rect, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
                    drawRtl(page.canvas, receipt.amount?.let { String.format(Locale.US, "%.2f", it) }.orEmpty(), rect.left + rect.width()*.62f, rect.top+rect.height()*.205f, rect.width()*.16f, 12f, true)
                    drawRtl(page.canvas, receipt.tenant, rect.right-rect.width()*.10f, rect.top+rect.height()*.315f, rect.width()*.80f, 11f, false)
                    drawRtl(page.canvas, "${receipt.property} • ${receipt.paidDate}", rect.right-rect.width()*.12f, rect.top+rect.height()*.505f, rect.width()*.53f, 9f, false)
                    val description = listOf("إيصال ${receipt.receiptNo}", "عن فترة ${receipt.period}", receipt.unitCode).filter { it.isNotBlank() }.joinToString(" – ")
                    drawRtl(page.canvas, description, rect.right-rect.width()*.12f, rect.top+rect.height()*.585f, rect.width()*.58f, 9f, false)
                }
                document.finishPage(page)
            }
            resolver.openOutputStream(uri, "w")?.use { document.writeTo(it) } ?: error("تعذر فتح ملف PDF للحفظ")
        } finally {
            document.close()
            bitmaps.values.forEach { it.recycle() }
        }
    }

    private fun drawRtl(canvas: Canvas, text: String, right: Float, top: Float, width: Float, size: Float, bold: Boolean) {
        if (text.isBlank()) return
        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xff111111.toInt(); textSize = size
            typeface = Typeface.create("sans-serif", if (bold) Typeface.BOLD else Typeface.NORMAL)
        }
        val safe = text.take(100)
        val layout = StaticLayout.Builder.obtain(safe, 0, safe.length, paint, width.toInt().coerceAtLeast(40))
            .setAlignment(Layout.Alignment.ALIGN_OPPOSITE).setTextDirection(TextDirectionHeuristics.RTL)
            .setIncludePad(false).setMaxLines(2).build()
        canvas.save(); canvas.translate(right-width, top); layout.draw(canvas); canvas.restore()
    }
}
