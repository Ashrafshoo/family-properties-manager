#!/usr/bin/env python3
from pathlib import Path
s=(Path(__file__).resolve().parents[1]/'app/build.gradle.kts').read_text(encoding='utf-8')
assert 'versionCode = 87' in s
assert 'versionName = "0.4.63-dev"' in s
print('PASS: release source version is 0.4.63-dev / versionCode 87')
