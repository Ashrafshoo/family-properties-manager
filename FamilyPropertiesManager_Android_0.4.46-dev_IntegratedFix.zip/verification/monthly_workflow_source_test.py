from pathlib import Path
root=Path(__file__).resolve().parents[1]
db=(root/'app/src/main/java/com/example/rentals/data/RentalsDb.kt').read_text()
ui=(root/'app/src/main/java/com/example/rentals/MainActivity.kt').read_text()
printing=(root/'app/src/main/java/com/example/rentals/features/printing/MonthlyCollectionScreen.kt').read_text()
repo=(root/'app/src/main/java/com/example/rentals/data/repository/SqliteMonthlyCollectionRepository.kt').read_text()
ui_all=ui+'\n'+printing+'\n'+repo
checks={
 'schema version 17':'rentals_local.db", null, 17' in db,
 'monthly batches persist period and title':'CREATE TABLE IF NOT EXISTS monthly_collection_batches' in db and 'CREATE TABLE IF NOT EXISTS monthly_collection_items' in db,
 'batch stores selected-unit snapshots':'UNIQUE(batch_id,unit_id)' in db and 'put("batch_id",batchId)' in db,
 'batch creation requires explicit selection':'require(selectedUnitIds.isNotEmpty())' in db,
 'monthly batch does not create paid receipts':'fun createMonthlyCollectionBatch' in db and 'put("collection_status","not_recorded")' in db,
 'batch receipt snapshots are retrievable':'fun monthlyBatchReceipts(batchId:Long)' in db,
 'shared issue date is persisted':'issued_date TEXT NOT NULL' in db and 'b.issued_date' in db,
 'v14 databases gain the issue-date field':'oldVersion in 14 until 15' in db,
 'personal notebook isolated tables':'personal_rent_months' in db and 'personal_rent_rows' in db and 'personal_rent_expenses' in db,
 'personal row has notes column':'notes TEXT NOT NULL DEFAULT' in db,
 'personal notebook reachable from bottom navigation':'Tab.Personal->PersonalRentNotebook(db)' in ui and 'Tab.Personal' in ui,
 'bulk selection and select all controls':'تحديد الكل' in ui_all and 'selected+eligible.map' in ui_all,
 'three receipts per A4 monthly print':'ReceiptPrintAdapter(activity,rs,3' in ui_all,
 'collector sheet only from batch items':'getBatchItems(batchId)' in ui_all,
 'collector PDF and Excel exports':'CollectorSheetPdfExporter.export' in ui_all and 'WorkbookExporter.exportRows' in ui_all,
 'collector outcomes validated and persisted':'fun updateMonthlyCollectionResult' in db and 'status in setOf("not_recorded","paid","partial","unpaid","unreachable")' in db,
 'collector outcome does not auto-post financial entries':'Intentionally no receipt/ledger write here' in db,
 'duplicate monthly batch prevention':'exact unit set already exists' in db and 'دفعة محفوظة بالفعل' in db,
 'collector outcome editor visible':'تسجيل / تعديل نتيجة مرور المحصّل' in ui_all and 'حفظ نتيجة مرور المحصّل دون إنشاء قيد مالي' in ui_all,
 'exports include actual collection outcome':'المبلغ المحصل فعليًا' in ui_all and 'collectionStatusArabic(it[5])' in ui_all,
 'collector PDF includes actual collected amount':'المحصل فعليًا' in (root/'app/src/main/java/com/example/rentals/printing/CollectorSheetPdfExporter.kt').read_text(),
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+': '+name)
assert all(checks.values())
