from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
source = (ROOT / "app/src/main/java/com/example/rentals/ui/SettingsStore.kt").read_text()
build = (ROOT / "app/build.gradle.kts").read_text()

checks = {
    "font scale lower and upper bounds": "coerceIn(MIN_FONT_SCALE, MAX_FONT_SCALE)" in source,
    "non-finite font scale fallback": "?.coerceIn(MIN_FONT_SCALE, MAX_FONT_SCALE) ?: 1f" in source,
    "supported font families allowlist": 'setOf("noto", "sans", "serif", "mono")' in source,
    "background palette allowlist": 'setOf("mist", "cream", "lavender", "mint", "slate")' in source,
    "text color allowlist": 'setOf("navy", "black", "brown", "plum")' in source,
    "bold preference persisted": 'putBoolean("boldText", safe.boldText)' in source,
    "supported accent allowlist": 'setOf("teal", "blue", "olive", "sand", "purple", "rose", "navy")' in source,
    "receipt count bounds": "coerceIn(MIN_RECEIPTS_PER_PAGE, MAX_RECEIPTS_PER_PAGE)" in source,
    "print margin bounds": "coerceIn(MIN_MARGIN_MM, MAX_MARGIN_MM)" in source,
    "legacy preferences retained": 'getSharedPreferences("ui_settings"' in source,
    "version incremented": 'versionCode = 70' in build and 'versionName = "0.4.46-dev"' in build,
}
for label, passed in checks.items():
    print(("PASS" if passed else "FAIL") + " - " + label)
assert all(checks.values()), "Settings validation regression"
print(f"{len(checks)}/{len(checks)} checks passed")
