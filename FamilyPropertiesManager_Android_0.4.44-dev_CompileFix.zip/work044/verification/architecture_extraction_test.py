from pathlib import Path
root = Path(__file__).resolve().parents[1]
main = (root / 'app/src/main/java/com/example/rentals/MainActivity.kt').read_text()
tabs = (root / 'app/src/main/java/com/example/rentals/navigation/AppTab.kt').read_text()
theme = (root / 'app/src/main/java/com/example/rentals/design/AppTheme.kt').read_text()
assert 'typealias Tab = AppTab' in main
assert 'private enum class Tab' not in main
assert 'enum class AppTab' in tabs
for key in ['Home(', 'Units(', 'Finance(', 'Print(', 'Personal(', 'Review(', 'Contracts(', 'Entities(', 'Settings(']:
    assert key in tabs, key
assert 'appColorScheme(settings)' in main and 'appTypography(settings' in main
for key in ['"blue"', '"olive"', '"sand"', '"purple"', '"rose"', '"navy"']:
    assert key in theme, key
assert 'fontScale' in theme and 'fontFamily' in theme
print('PASS: navigation destinations and theme mapping extracted without changing feature names or settings contract.')

settings = (root / 'app/src/main/java/com/example/rentals/features/settings/SettingsScreen.kt').read_text()
assert 'import com.example.rentals.features.settings.SettingsScreen' in main
assert '@Composable fun SettingsScreen(' in settings
assert '@Composable private fun SettingsScreen(' not in main
for workflow in ('rememberLauncherForActivityResult', 'BackupManager.create', 'BackupManager.restore', 'EncryptedBackup.create', 'EncryptedBackup.restore', 'ReviewedRentalsWorkbookImporter.preview', 'WorkbookImporter.preview', 'DatabaseTransfer.import', 'HeirSharesDialog', 'ChangePinDialog'):
    assert workflow in settings, workflow
assert 'fun SettingsScreen(' not in main
print('PASS: settings feature screen and its security, backup, restore and import flows extracted intact.')
