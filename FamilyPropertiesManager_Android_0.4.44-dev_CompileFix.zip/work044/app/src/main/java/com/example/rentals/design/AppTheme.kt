package com.example.rentals.design

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontWeight
import com.example.rentals.R
import com.example.rentals.ui.UiSettings

/** Premium visual system shared by every screen; user accent and accessibility scale remain respected. */
private val DeepNavy = Color(0xFF10243A)
private val RoyalBlue = Color(0xFF285B91)
private val Gold = Color(0xFFC69A45)
private val Teal = Color(0xFF16877F)
private val LightCanvas = Color(0xFFF3F6F9)
private val DarkCanvas = Color(0xFF0D1722)

fun appColorScheme(settings: UiSettings): ColorScheme {
    val selectedAccent = when (settings.accent) {
        "blue" -> Color(0xFF3977A8)
        "olive" -> Color(0xFF71845A)
        "sand" -> Color(0xFFA77C52)
        "purple" -> Color(0xFF7656A5)
        "rose" -> Color(0xFFB45F72)
        "navy" -> Color(0xFF365477)
        else -> Teal
    }
    val lightCanvas = when (settings.backgroundTone) {
        "cream" -> Color(0xFFFAF3E8)
        "lavender" -> Color(0xFFF3EFFA)
        "mint" -> Color(0xFFECF5F1)
        "slate" -> Color(0xFFE9EEF3)
        else -> LightCanvas
    }
    val lightText = when (settings.textTone) {
        "black" -> Color(0xFF171717)
        "brown" -> Color(0xFF49372C)
        "plum" -> Color(0xFF3D294B)
        else -> DeepNavy
    }
    return if (settings.dark) {
        val darkCanvas = when (settings.backgroundTone) {
            "cream" -> Color(0xFF211F1B)
            "lavender" -> Color(0xFF211D29)
            "mint" -> Color(0xFF172522)
            "slate" -> Color(0xFF151D27)
            else -> DarkCanvas
        }
        darkColorScheme(
            primary = selectedAccent,
            onPrimary = Color.White,
            primaryContainer = Color(0xFF233B52),
            onPrimaryContainer = Color(0xFFE5EFF8),
            secondary = Gold,
            onSecondary = Color(0xFF241A08),
            secondaryContainer = Color(0xFF4A3A1D),
            onSecondaryContainer = Color(0xFFF5E8C9),
            tertiary = Color(0xFF55BDB1),
            background = darkCanvas,
            onBackground = Color(0xFFE8EEF4),
            surface = Color(0xFF172535),
            onSurface = Color(0xFFE8EEF4),
            surfaceVariant = Color(0xFF263849),
            onSurfaceVariant = Color(0xFFB8C6D2),
            outline = Color(0xFF526779),
        )
    } else {
        lightColorScheme(
            primary = selectedAccent,
            onPrimary = Color.White,
            primaryContainer = Color(0xFFE2ECF5),
            onPrimaryContainer = DeepNavy,
            secondary = Gold,
            onSecondary = Color(0xFF241A08),
            secondaryContainer = Color(0xFFF5EBD7),
            onSecondaryContainer = Color(0xFF493719),
            tertiary = Teal,
            background = lightCanvas,
            onBackground = lightText,
            surface = Color.White,
            onSurface = lightText,
            surfaceVariant = Color(0xFFE8EEF3),
            onSurfaceVariant = Color(0xFF607184),
            outline = Color(0xFFCAD4DE),
        )
    }
}

private val ArabicFontFamily = FontFamily(
    Font(R.font.noto_sans_arabic_regular, FontWeight.Normal),
    Font(R.font.noto_sans_arabic_medium, FontWeight.Medium),
    Font(R.font.noto_sans_arabic_semibold, FontWeight.SemiBold),
    Font(R.font.noto_sans_arabic_bold, FontWeight.Bold),
)

fun appTypography(settings: UiSettings, base: Typography): Typography {
    val family = when (settings.fontFamily) {
        "serif" -> FontFamily.Serif
        "mono" -> FontFamily.Monospace
        else -> ArabicFontFamily
    }
    fun androidx.compose.ui.text.TextStyle.scaled() = copy(
        fontSize = fontSize * settings.fontScale,
        lineHeight = lineHeight * settings.fontScale,
        fontFamily = family,
        fontWeight = if (settings.boldText) FontWeight.SemiBold else fontWeight,
    )
    return base.copy(
        displayLarge = base.displayLarge.scaled(), displayMedium = base.displayMedium.scaled(), displaySmall = base.displaySmall.scaled(),
        headlineLarge = base.headlineLarge.scaled(), headlineMedium = base.headlineMedium.scaled(), headlineSmall = base.headlineSmall.scaled(),
        titleLarge = base.titleLarge.scaled(), titleMedium = base.titleMedium.scaled(), titleSmall = base.titleSmall.scaled(),
        bodyLarge = base.bodyLarge.scaled(), bodyMedium = base.bodyMedium.scaled(), bodySmall = base.bodySmall.scaled(),
        labelLarge = base.labelLarge.scaled(), labelMedium = base.labelMedium.scaled(), labelSmall = base.labelSmall.scaled(),
    )
}
