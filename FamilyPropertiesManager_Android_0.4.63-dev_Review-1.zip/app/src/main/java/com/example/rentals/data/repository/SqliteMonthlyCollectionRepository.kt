package com.example.rentals.data.repository

import com.example.rentals.data.RentalsDb
import com.example.rentals.data.ReceiptRecord
import com.example.rentals.data.AggregateReceiptItem
import com.example.rentals.data.AggregateReceiptStatement
import com.example.rentals.domain.collection.MonthlyCollectionRepository

/** SQLite adapter; collector observations remain separate from receipts and ledger entries. */
class SqliteMonthlyCollectionRepository(private val database: RentalsDb) : MonthlyCollectionRepository {
    override fun createBatch(period: String, issuedDate: String, selectedUnitIds: Set<Long>, propertyFilter: String): Long =
        database.createMonthlyCollectionBatch(period, issuedDate, selectedUnitIds, propertyFilter)

    override fun getBatches(): List<RentalsDb.MonthlyBatch> = database.monthlyBatches()
    override fun getBatchReceipts(batchId: Long): List<ReceiptRecord> = database.monthlyBatchReceipts(batchId)
    override fun getBatchItems(batchId: Long): List<Array<String>> = database.monthlyBatchItems(batchId)

    override fun recordCollectorResult(itemId: Long, status: String, amount: Double?, date: String, notes: String) =
        database.updateMonthlyCollectionResult(itemId, status, amount, date, notes)
    override fun getOrCreateAggregateStatement(period: String, type: String, issuedDate: String): Long = database.getOrCreateAggregateStatement(period,type,issuedDate)
    override fun getAggregateStatements(period: String): List<AggregateReceiptStatement> = database.aggregateReceiptStatements(period)
    override fun addAggregateReceiptItem(statementId: Long, item: AggregateReceiptItem): Long = database.addAggregateReceiptItem(statementId,item)
    override fun updateAggregateReceiptItem(item: AggregateReceiptItem) = database.updateAggregateReceiptItem(item)
    override fun deleteAggregateReceiptItem(statementId: Long, itemId: Long) = database.deleteAggregateReceiptItem(statementId,itemId)
}
