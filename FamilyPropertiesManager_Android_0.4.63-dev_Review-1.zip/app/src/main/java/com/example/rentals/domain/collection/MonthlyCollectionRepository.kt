package com.example.rentals.domain.collection

import com.example.rentals.data.RentalsDb
import com.example.rentals.data.ReceiptRecord
import com.example.rentals.data.AggregateReceiptItem
import com.example.rentals.data.AggregateReceiptStatement

/** Domain-facing boundary for monthly collector batches. */
interface MonthlyCollectionRepository {
    fun createBatch(period: String, issuedDate: String, selectedUnitIds: Set<Long>, propertyFilter: String = ""): Long
    fun getBatches(): List<RentalsDb.MonthlyBatch>
    fun getBatchReceipts(batchId: Long): List<ReceiptRecord>
    fun getBatchItems(batchId: Long): List<Array<String>>
    fun recordCollectorResult(itemId: Long, status: String, amount: Double?, date: String, notes: String)
    fun getOrCreateAggregateStatement(period: String, type: String, issuedDate: String): Long
    fun getAggregateStatements(period: String): List<AggregateReceiptStatement>
    fun addAggregateReceiptItem(statementId: Long, item: AggregateReceiptItem): Long
    fun updateAggregateReceiptItem(item: AggregateReceiptItem)
    fun deleteAggregateReceiptItem(statementId: Long, itemId: Long)
}
