package com.example.rentals.io

import android.content.ContentResolver
import android.content.Context
import android.net.Uri
import com.example.rentals.data.AggregateReceiptItem
import org.w3c.dom.Document
import org.w3c.dom.Element
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import javax.xml.XMLConstants
import javax.xml.parsers.DocumentBuilderFactory
import javax.xml.transform.OutputKeys
import javax.xml.transform.TransformerFactory
import javax.xml.transform.dom.DOMSource
import javax.xml.transform.stream.StreamResult

/**
 * Fills the supplied workbook design instead of generating a plain data-only sheet.
 * All drawings, images, receipt layouts, print breaks, formulas and styles are copied
 * unchanged from the bundled workbook. Only source rows and period settings are edited.
 */
object AggregateStatementWorkbookExporter {
    private const val TEMPLATE_ASSET = "aggregate_statement_template.xlsx"
    private const val MAIN_NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"

    fun export(
        context: Context,
        resolver: ContentResolver,
        uri: Uri,
        items: List<AggregateReceiptItem>,
        period: String
    ) {
        require(items.isNotEmpty()) { "لا توجد أسماء محددة لتصديرها" }
        require(items.size <= 120) { "قالب الإيصالات المرجعي يجهز حاليًا حتى ١٢٠ إيصالًا؛ لا يمكن تجاوز هذا العدد قبل توسيع صفحات القالب وحساباته" }
        val parts = period.trim().split('-', '/', '\\')
        require(parts.size >= 2) { "الفترة غير صحيحة؛ استخدم سنة-شهر" }
        val year = parts[0].toIntOrNull() ?: error("سنة الكشف غير صحيحة")
        val month = parts[1].toIntOrNull() ?: error("شهر الكشف غير صحيح")
        require(month in 1..12) { "شهر الكشف يجب أن يكون من ١ إلى ١٢" }

        val source = context.assets.open(TEMPLATE_ASSET)
        val output = resolver.openOutputStream(uri, "w") ?: error("تعذر فتح ملف Excel للحفظ")
        source.use { input -> output.use { raw ->
            ZipInputStream(input).use { zin -> ZipOutputStream(raw).use { zout ->
                var foundUnits = false
                var foundSettings = false
                var entry = zin.nextEntry
                while (entry != null) {
                    val name = entry.name
                    val bytes = readEntry(zin)
                    val updated = when (name) {
                        "xl/worksheets/sheet1.xml" -> {
                            foundUnits = true
                            updateUnitsSheet(bytes, items)
                        }
                        "xl/worksheets/sheet2.xml" -> clearIncreaseSheet(bytes)
                        "xl/worksheets/sheet4.xml" -> {
                            foundSettings = true
                            updateSettingsSheet(bytes, month, year)
                        }
                        "xl/workbook.xml" -> updateCalculationMode(bytes)
                        else -> bytes
                    }
                    val copy = ZipEntry(name).apply {
                        time = entry.time
                        comment = entry.comment
                    }
                    zout.putNextEntry(copy)
                    zout.write(updated)
                    zout.closeEntry()
                    zin.closeEntry()
                    entry = zin.nextEntry
                }
                require(foundUnits && foundSettings) { "القالب لا يحتوي أوراق الكشف والإعدادات المتوقعة" }
            } }
        } }
        verifyWorkbook(resolver, uri)
    }

    private fun readEntry(input: ZipInputStream): ByteArray {
        val out = ByteArrayOutputStream()
        val buffer = ByteArray(8192)
        while (true) {
            val count = input.read(buffer)
            if (count < 0) break
            out.write(buffer, 0, count)
        }
        return out.toByteArray()
    }

    private fun parse(bytes: ByteArray): Document {
        val factory = DocumentBuilderFactory.newInstance().apply {
            isNamespaceAware = true
            setFeature("http://apache.org/xml/features/disallow-doctype-decl", true)
            setFeature("http://xml.org/sax/features/external-general-entities", false)
            setFeature("http://xml.org/sax/features/external-parameter-entities", false)
            runCatching { setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, "") }
            runCatching { setAttribute(XMLConstants.ACCESS_EXTERNAL_SCHEMA, "") }
        }
        return factory.newDocumentBuilder().parse(ByteArrayInputStream(bytes))
    }

    private fun serialize(document: Document): ByteArray {
        val factory = TransformerFactory.newInstance().apply {
            runCatching { setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, "") }
            runCatching { setAttribute(XMLConstants.ACCESS_EXTERNAL_STYLESHEET, "") }
        }
        val transformer = factory.newTransformer().apply {
            setOutputProperty(OutputKeys.ENCODING, "UTF-8")
            setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "no")
        }
        return ByteArrayOutputStream().also { transformer.transform(DOMSource(document), StreamResult(it)) }.toByteArray()
    }

    private fun elements(parent: Element, localName: String): List<Element> {
        val nodes = parent.getElementsByTagNameNS(MAIN_NS, localName)
        return (0 until nodes.length).mapNotNull { nodes.item(it) as? Element }
    }

    private fun updateUnitsSheet(bytes: ByteArray, items: List<AggregateReceiptItem>): ByteArray {
        val doc = parse(bytes)
        val sheetData = elements(doc.documentElement, "sheetData").firstOrNull()
            ?: error("ورقة الوحدات لا تحتوي بيانات قابلة للتحديث")
        val rows = elements(sheetData, "row").associateBy { it.getAttribute("r").toIntOrNull() ?: -1 }.toMutableMap()
        for (rowNumber in 2..1000) {
            val row = rows[rowNumber] ?: doc.createElementNS(MAIN_NS, "row").also {
                it.setAttribute("r", rowNumber.toString())
                sheetData.appendChild(it)
                rows[rowNumber] = it
            }
            val cells = directCells(row).associateBy { it.getAttribute("r").replace(Regex("[0-9]"), "") }
            // Preserve the original auto-number formula in column U; clear sample data elsewhere.
            directCells(row).filter { columnOf(it.getAttribute("r")) != "U" }.forEach { clearCell(it) }
            val item = items.getOrNull(rowNumber - 2)
            if (item != null) {
                val code = item.unitCode.ifBlank { "AGG-${(rowNumber - 1).toString().padStart(3, '0')}" }
                setInline(doc, row, cells, "A", rowNumber, code)
                setInline(doc, row, cells, "B", rowNumber, item.tenant)
                setInline(doc, row, cells, "C", rowNumber, item.property)
                setInline(doc, row, cells, "D", rowNumber, item.address)
                setInline(doc, row, cells, "E", rowNumber, item.unitCode)
                setNumber(doc, row, cells, "I", rowNumber, item.amount)
                setInline(doc, row, cells, "L", rowNumber, item.description)
                setInline(doc, row, cells, "M", rowNumber, item.notes)
                // Explicit receipt name prevents an inferred title from changing the user's entered name.
                setInline(doc, row, cells, "S", rowNumber, item.tenant)
            }
        }
        // Keep row order deterministic after appending any missing rows.
        val sortedRows = rows.values.sortedBy { it.getAttribute("r").toIntOrNull() ?: Int.MAX_VALUE }
        sortedRows.forEach { sheetData.appendChild(it) }
        return serialize(doc)
    }

    private fun directCells(row: Element): List<Element> {
        val out = mutableListOf<Element>()
        var child = row.firstChild
        while (child != null) {
            if (child is Element && child.localName == "c") out += child
            child = child.nextSibling
        }
        return out
    }

    private fun columnOf(reference: String): String = reference.takeWhile { it.isLetter() }

    private fun clearCell(cell: Element) {
        while (cell.firstChild != null) cell.removeChild(cell.firstChild)
        cell.removeAttribute("t")
    }

    private fun findOrCreateCell(doc: Document, row: Element, cache: Map<String, Element>, column: String, rowNumber: Int): Element {
        return cache[column] ?: doc.createElementNS(MAIN_NS, "c").also {
            it.setAttribute("r", "$column$rowNumber")
            row.appendChild(it)
        }
    }

    private fun setInline(doc: Document, row: Element, cache: Map<String, Element>, column: String, rowNumber: Int, value: String) {
        if (value.isEmpty()) return
        val cell = findOrCreateCell(doc, row, cache, column, rowNumber)
        clearCell(cell)
        cell.setAttribute("t", "inlineStr")
        val inline = doc.createElementNS(MAIN_NS, "is")
        val text = doc.createElementNS(MAIN_NS, "t")
        text.setAttributeNS(XMLConstants.XML_NS_URI, "xml:space", "preserve")
        text.appendChild(doc.createTextNode(value))
        inline.appendChild(text)
        cell.appendChild(inline)
    }

    private fun setNumber(doc: Document, row: Element, cache: Map<String, Element>, column: String, rowNumber: Int, value: Double) {
        require(value.isFinite() && value >= 0.0) { "قيمة الإيجار غير صالحة" }
        val cell = findOrCreateCell(doc, row, cache, column, rowNumber)
        clearCell(cell)
        val v = doc.createElementNS(MAIN_NS, "v")
        v.appendChild(doc.createTextNode(value.toString()))
        cell.appendChild(v)
    }


    private fun clearIncreaseSheet(bytes: ByteArray): ByteArray {
        val doc = parse(bytes)
        val sheetData = elements(doc.documentElement, "sheetData").firstOrNull() ?: return bytes
        elements(sheetData, "row").filter { (it.getAttribute("r").toIntOrNull() ?: 1) > 1 }.forEach { row ->
            directCells(row).forEach(::clearCell)
        }
        return serialize(doc)
    }

    private fun updateSettingsSheet(bytes: ByteArray, month: Int, year: Int): ByteArray {
        val doc = parse(bytes)
        val sheetData = elements(doc.documentElement, "sheetData").firstOrNull() ?: return bytes
        val rows = elements(sheetData, "row").associateBy { it.getAttribute("r").toIntOrNull() ?: -1 }
        setExistingCell(doc, rows[1], "B1", month.toString())
        setExistingCell(doc, rows[2], "B2", year.toString())
        return serialize(doc)
    }

    private fun setExistingCell(doc: Document, row: Element?, reference: String, value: String) {
        if (row == null) return
        val cell = directCells(row).firstOrNull { it.getAttribute("r") == reference } ?: return
        clearCell(cell)
        val v = doc.createElementNS(MAIN_NS, "v")
        v.appendChild(doc.createTextNode(value))
        cell.appendChild(v)
    }

    private fun updateCalculationMode(bytes: ByteArray): ByteArray {
        val doc = parse(bytes)
        val root = doc.documentElement
        val calc = elements(root, "calcPr").firstOrNull() ?: doc.createElementNS(MAIN_NS, "calcPr").also {
            root.appendChild(it)
        }
        calc.setAttribute("calcMode", "auto")
        calc.setAttribute("fullCalcOnLoad", "1")
        calc.setAttribute("forceFullCalc", "1")
        return serialize(doc)
    }

    private fun verifyWorkbook(resolver: ContentResolver, uri: Uri) {
        val input = resolver.openInputStream(uri) ?: error("تعذر التحقق من ملف Excel بعد الحفظ")
        input.use { stream ->
            ZipInputStream(stream).use { zip ->
                var hasWorkbook = false
                var hasUnits = false
                var hasReceiptImages = false
                var entry = zip.nextEntry
                while (entry != null) {
                    when (entry.name) {
                        "xl/workbook.xml" -> hasWorkbook = true
                        "xl/worksheets/sheet1.xml" -> hasUnits = true
                        "xl/drawings/drawing1.xml" -> hasReceiptImages = true
                    }
                    zip.closeEntry()
                    entry = zip.nextEntry
                }
                require(hasWorkbook && hasUnits && hasReceiptImages) { "ملف Excel الناتج لا يحتوي جميع مكونات القالب الأصلي" }
            }
        }
    }
}
