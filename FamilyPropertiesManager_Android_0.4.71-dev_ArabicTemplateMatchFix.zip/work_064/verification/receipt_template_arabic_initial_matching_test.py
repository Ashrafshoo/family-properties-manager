from pathlib import Path
import json, re, unicodedata
root = Path(__file__).resolve().parents[1]
renderer = (root / 'app/src/main/java/com/example/rentals/printing/OriginalReceiptTemplateRenderer.kt').read_text(encoding='utf-8')
ui = (root / 'app/src/main/java/com/example/rentals/features/printing/MonthlyCollectionScreen.kt').read_text(encoding='utf-8')
catalog = json.loads((root / 'app/src/main/assets/receipt_templates/receipt_template_catalog_v1.json').read_text(encoding='utf-8'))
assert 'م|ا)' not in renderer, 'unsafe single-letter honorific stripping returned'
assert 'batchTemplateOptions.none { it.first == receipt.template }' in ui, 'old invalid/missing template IDs must be rematched on batch reopen'
assert 'ابرهيم", "ابراهيم"' in renderer
assert 'تم تعيين قالب نوفمبر لكل الإيصالات' in ui
assert 'يلزم اختيار قالب فقط للإيصالات غير المطابقة تلقائيًا' in ui

def key(value):
    value = unicodedata.normalize('NFD', value.strip())
    value = ''.join(ch for ch in value if unicodedata.category(ch) != 'Mn')
    value = value.replace('ـ', ' ').replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا').replace('ى', 'ي').lower()
    value = re.sub(r'^(?:(?:السيد|السادة|السيدة|مدام)\s*/?\s*|م\s*/\s*)', '', value)
    value = value.replace('ابرهيم', 'ابراهيم')
    return re.sub(r'[^\w]', '', value, flags=re.UNICODE)

# Three names visible in the user's attached November 2026 PDF.
receipts = {
    'محمد إبراهيم حسين ابراهيم': 'T001',
    'احمد ناصر محمد حسن حنفي': 'T002',
    'محمود يوسف عيد عواد': 'T003',
}
for tenant, expected_id in receipts.items():
    matches = [t for t in catalog['templates'] if t.get('monthlyEligible', True) and key(t.get('tenant_text', '')) == key(tenant)]
    assert len(matches) == 1, (tenant, [(t['template_id'], t['tenant_text']) for t in matches])
    assert matches[0]['template_id'] == expected_id, (tenant, matches[0]['template_id'])
print('PASS: Arabic initial letters are preserved; the three attached PDF tenants resolve uniquely to T001/T002/T003.')
