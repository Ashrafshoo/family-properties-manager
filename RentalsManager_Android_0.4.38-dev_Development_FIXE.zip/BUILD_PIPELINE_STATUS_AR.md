# حالة خط البناء — أملاك العائلة 0.4.38-dev

- الإصدار الحالي: 0.4.38-dev / versionCode 63.
- التطبيق Android Native: Kotlin + Jetpack Compose + SQLite.
- applicationId: `com.example.rentals`.
- GitHub Actions يحتوي مرحلتين: اختبارات المصدر ثم Android `assembleDebug` باستخدام JDK 17 وGradle 8.9 وAndroid SDK 35.
- تم تحديث اسم artifact ليطابق 0.4.38-dev.
- لا يوجد Gradle executable أو Android SDK في بيئة المراجعة المحلية؛ لذلك لم ينفذ Gradle Sync أو assembleDebug ولم ينتج APK.
- نجاح اختبارات Python المصدرية لا يعادل ترجمة Kotlin/Compose ولا اختبار التشغيل على هاتف.
- لم يتم تشغيل GitHub Actions من هذه البيئة ولم يتم اختبار طابعة أو استعادة على هاتف فعلي.
