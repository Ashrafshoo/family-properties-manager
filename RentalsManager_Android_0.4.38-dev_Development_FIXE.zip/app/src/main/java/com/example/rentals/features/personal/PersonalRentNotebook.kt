package com.example.rentals.features.personal

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.rentals.data.RentalsDb
import java.text.NumberFormat
import java.util.Locale

private fun personalMoney(value: Double): String = NumberFormat.getNumberInstance(Locale("ar", "EG")).format(value) + " ج.م"

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun PersonalRentNotebook(db:RentalsDb){
    val now=java.time.YearMonth.now()
    var yearText by remember{mutableStateOf(now.year.toString())}
    var monthText by remember{mutableStateOf(now.monthValue.toString())}
    var monthId by remember{mutableLongStateOf(db.personalMonthId(now.year,now.monthValue))}
    var refresh by remember{mutableIntStateOf(0)}
    var expenseTitle by remember{mutableStateOf("")};var expenseAmount by remember{mutableStateOf("")};var expenseDate by remember{mutableStateOf(java.time.LocalDate.now().toString())};var expenseNotes by remember{mutableStateOf("")}
    var editingExpense by remember{mutableStateOf<Array<String>?>(null)}
    var annualVisible by remember{mutableStateOf(false)}
    var message by remember{mutableStateOf("")}
    val rows=remember(monthId,refresh){db.personalRows(monthId)}
    val expenses=remember(monthId,refresh){db.personalExpenses(monthId)}
    val total=rows.sumOf{it[2].toDoubleOrNull()?:0.0};val expenseTotal=expenses.sumOf{it[2].toDoubleOrNull()?:0.0}
    val annual=remember(yearText,refresh){yearText.toIntOrNull()?.takeIf{it in 2000..2200}?.let{db.personalAnnualSummary(it)}?: emptyList()}
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
        Text("دفتر الإيجارات الشخصي",fontSize=22.sp,fontWeight=FontWeight.Bold)
        Text("دفتر مستقل تمامًا عن حسابات أملاك العائلة. التعديلات لا تؤثر في دفتر الحركات الرئيسي.",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
            OutlinedTextField(yearText,{yearText=it.filter(Char::isDigit).take(4)},label={Text("السنة")},modifier=Modifier.weight(1f),singleLine=true)
            OutlinedTextField(monthText,{monthText=it.filter(Char::isDigit).take(2)},label={Text("الشهر 1–12")},modifier=Modifier.weight(1f),singleLine=true)
            Button(onClick={try{monthId=db.personalMonthId(yearText.toInt(),monthText.toInt());message="";refresh++}catch(e:Exception){message=e.message?:"راجع السنة والشهر"}},modifier=Modifier.align(Alignment.CenterVertically)){Text("فتح")}
        }
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
            OutlinedButton(onClick={try{val y=yearText.toInt();val m=monthText.toInt();val prev=java.time.YearMonth.of(y,m).minusMonths(1);val source=db.personalMonthId(prev.year,prev.monthValue);monthId=db.copyPersonalNames(source,y,m);refresh++;message="تم ترحيل الأسماء فقط دون المبالغ أو المصروفات"}catch(e:Exception){message=e.message?:"تعذر ترحيل الأسماء"}},modifier=Modifier.weight(1f)){Text("ترحيل أسماء الشهر السابق")}
            OutlinedButton(onClick={annualVisible=!annualVisible}){Text(if(annualVisible)"إخفاء السنوي" else "التقرير السنوي")}
        }
        if(annualVisible){
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){
                Text("ملخص السنة $yearText",fontWeight=FontWeight.Bold)
                if(annual.isEmpty()) Text("لا توجد بيانات مسجلة لهذه السنة.",color=MaterialTheme.colorScheme.onSurfaceVariant)
                annual.forEach{a->val income=a[1].toDoubleOrNull()?:0.0;val cost=a[2].toDoubleOrNull()?:0.0;Row(verticalAlignment=Alignment.CenterVertically){Text("${a[0]}",modifier=Modifier.weight(0.5f));Text("إيراد ${personalMoney(income)}",modifier=Modifier.weight(1.3f),fontSize=11.sp);Text("صافي ${personalMoney(income-cost)}",modifier=Modifier.weight(1.2f),fontSize=11.sp)}}
                val annualIncome=annual.sumOf{it[1].toDoubleOrNull()?:0.0};val annualExpenses=annual.sumOf{it[2].toDoubleOrNull()?:0.0}
                HorizontalDivider();Text("إجمالي السنة: ${personalMoney(annualIncome)} • المصروفات: ${personalMoney(annualExpenses)} • الصافي: ${personalMoney(annualIncome-annualExpenses)}",fontWeight=FontWeight.Bold)
            }}
        }
        Text("بيان توزيع عن شهر $monthText لسنة $yearText",fontWeight=FontWeight.Bold)
        Text("المستأجر • الإجمالي • نصيب البنت (1/7) • نصيب الولد (2/7) • ملاحظات",fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
        rows.forEach{r->
            val rowNo=r[0].toIntOrNull()?:1
            var tenant by remember(monthId,rowNo,r[1]){mutableStateOf(r[1])}
            var amount by remember(monthId,rowNo,r[2]){mutableStateOf(r[2])}
            var notes by remember(monthId,rowNo,r[5]){mutableStateOf(r[5])}
            val value=amount.toDoubleOrNull()?:0.0
            val daughterShare=java.math.BigDecimal.valueOf(value.coerceAtLeast(0.0)).divide(java.math.BigDecimal("7"),2,java.math.RoundingMode.HALF_UP).toDouble()
            val sonShare=java.math.BigDecimal.valueOf(value.coerceAtLeast(0.0)).multiply(java.math.BigDecimal("2")).divide(java.math.BigDecimal("7"),2,java.math.RoundingMode.HALF_UP).toDouble()
            Card(Modifier.fillMaxWidth()){
                Column(Modifier.padding(8.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){
                    Text("السطر $rowNo",fontWeight=FontWeight.SemiBold,fontSize=11.sp)
                    OutlinedTextField(tenant,{tenant=it},label={Text("اسم المستأجر")},modifier=Modifier.fillMaxWidth(),singleLine=true)
                    Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){
                        OutlinedTextField(amount,{amount=it.filter{c->c.isDigit()||c=='.'}},label={Text("الإجمالي")},modifier=Modifier.weight(1f),singleLine=true)
                        Column(Modifier.weight(1f)){Text("البنت: ${personalMoney(daughterShare)}",fontSize=12.sp);Text("الولد: ${personalMoney(sonShare)}",fontSize=12.sp)}
                    }
                    OutlinedTextField(notes,{notes=it},label={Text("ملاحظات")},modifier=Modifier.fillMaxWidth(),singleLine=true)
                    Button(onClick={try{db.savePersonalRow(monthId,rowNo,tenant,value,daughterShare,sonShare,notes);refresh++;message="تم حفظ السطر $rowNo"}catch(e:Exception){message=e.message?:"تعذر حفظ السطر"}},modifier=Modifier.align(Alignment.End)){Text("حفظ السطر")}
                }
            }
        }
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)){Text("إجمالي الإيرادات: ${personalMoney(total)} جنيه",fontWeight=FontWeight.Bold);Text("إجمالي المصروفات: ${personalMoney(expenseTotal)} جنيه");Text("الصافي: ${personalMoney(total-expenseTotal)} جنيه",fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary)} }
        HorizontalDivider();Text("المصروفات الأخرى",fontWeight=FontWeight.Bold)
        OutlinedTextField(expenseTitle,{expenseTitle=it},label={Text("بيان المصروف")},modifier=Modifier.fillMaxWidth())
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
            OutlinedTextField(expenseAmount,{expenseAmount=it},label={Text("المبلغ")},modifier=Modifier.weight(1f),singleLine=true)
            OutlinedTextField(expenseDate,{expenseDate=it},label={Text("التاريخ YYYY-MM-DD")},modifier=Modifier.weight(1f),singleLine=true)
        }
        OutlinedTextField(expenseNotes,{expenseNotes=it},label={Text("ملاحظات المصروف")},modifier=Modifier.fillMaxWidth())
        Button(onClick={try{db.addPersonalExpense(monthId,expenseTitle,expenseAmount.toDouble(),expenseDate,expenseNotes);expenseTitle="";expenseAmount="";expenseNotes="";refresh++;message="تمت إضافة المصروف"}catch(e:Exception){message=e.message?:"تعذر إضافة المصروف"}},enabled=expenseTitle.isNotBlank()&&(expenseAmount.toDoubleOrNull()?:-1.0)>=0,modifier=Modifier.fillMaxWidth()){Text("إضافة مصروف")}
        expenses.forEach{e->
            Card(Modifier.fillMaxWidth()){ListItem(headlineContent={Text(e[1])},supportingContent={Text("${e[3]} • ${e[4]}")},trailingContent={Row(verticalAlignment=Alignment.CenterVertically){Text(personalMoney(e[2].toDoubleOrNull()?:0.0),fontSize=11.sp);IconButton(onClick={editingExpense=e}){Icon(Icons.Default.Edit,"تعديل المصروف")};IconButton(onClick={try{db.deletePersonalExpense(e[0].toLong());refresh++;message="تم حذف المصروف"}catch(ex:Exception){message=ex.message?:"تعذر الحذف"}}){Icon(Icons.Default.Delete,"حذف المصروف")}}})}
        }
        if(message.isNotBlank()) Text(message,color=MaterialTheme.colorScheme.primary,fontSize=12.sp)
    }
    editingExpense?.let{e->
        var title by remember(e[0]){mutableStateOf(e[1])};var amount by remember(e[0]){mutableStateOf(e[2])};var date by remember(e[0]){mutableStateOf(e[3])};var notes by remember(e[0]){mutableStateOf(e[4])}
        AlertDialog(onDismissRequest={editingExpense=null},title={Text("تعديل المصروف")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){OutlinedTextField(title,{title=it},label={Text("البيان")});OutlinedTextField(amount,{amount=it},label={Text("المبلغ")});OutlinedTextField(date,{date=it},label={Text("التاريخ YYYY-MM-DD")});OutlinedTextField(notes,{notes=it},label={Text("ملاحظات")})}},confirmButton={TextButton(onClick={try{db.updatePersonalExpense(e[0].toLong(),title,amount.toDouble(),date,notes);editingExpense=null;refresh++;message="تم تعديل المصروف"}catch(ex:Exception){message=ex.message?:"تعذر تعديل المصروف"}}){Text("حفظ")}},dismissButton={TextButton(onClick={editingExpense=null}){Text("إلغاء")}})
    }
}

