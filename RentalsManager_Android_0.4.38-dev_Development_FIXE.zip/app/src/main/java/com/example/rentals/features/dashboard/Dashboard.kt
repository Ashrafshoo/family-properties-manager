package com.example.rentals.features.dashboard

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.rentals.domain.dashboard.DashboardUnitSnapshot
import com.example.rentals.domain.dashboard.BuildDashboardOverview
import com.example.rentals.navigation.AppTab
import java.text.NumberFormat
import java.util.Locale

@Composable
fun Dashboard(units: List<DashboardUnitSnapshot>, onNavigate: (AppTab) -> Unit) {
    val overview = BuildDashboardOverview()(units)
    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        DashboardHero()
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("نظرة عامة", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("ملخص تشغيلي مستمد من سجلات التطبيق", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            DashboardMetric("إجمالي سجلات الوحدات", overview.totalRecords.toString(), Icons.Default.Apartment, Modifier.weight(1f), "إدارة الوحدات") { onNavigate(AppTab.Units) }
            DashboardMetric("السجلات المشمولة", overview.includedOperationalRecords.toString(), Icons.Default.HomeWork, Modifier.weight(1f), "عرض الوحدات") { onNavigate(AppTab.Units) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            DashboardMetric("الإيجار المسجل", dashboardMoney(overview.registeredRentTotal), Icons.Default.Payments, Modifier.weight(1f), "الدفتر المالي") { onNavigate(AppTab.Finance) }
            DashboardMetric("تحتاج إلى مراجعة", overview.needsReviewCount.toString(), Icons.Default.PendingActions, Modifier.weight(1f), "مركز المراجعة") { onNavigate(AppTab.Review) }
        }
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.secondary.copy(alpha = .25f))
        ) {
            Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.Top) {
                Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.secondary.copy(alpha = .16f)) {
                    Icon(Icons.Default.GppGood, contentDescription = null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.padding(10.dp).size(24.dp))
                }
                Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text("تنبيه محاسبي مهم", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSecondaryContainer)
                    Text(
                        "يُحدد يوم استحقاق الإيجار من العقد أو الاتفاق المسجل لكل وحدة؛ لا يُفترض أنه أول الشهر. وعبارة «مشاهرة» وحدها لا تحدد يوم الاستحقاق. كما أن الإيجار المسجل أو وجود إيصال لا يثبت التحصيل الفعلي؛ يُثبت التحصيل في دفتر الحركات.",
                        color = MaterialTheme.colorScheme.onSecondaryContainer,
                        style = MaterialTheme.typography.bodySmall,
                        lineHeight = 20.sp
                    )
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("الوصول السريع", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            Text("الأقسام", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelMedium)
        }
        DashboardShortcut("الوحدات والعقارات", "الوحدات والمستأجرون والمستندات", Icons.Default.Domain, "إدارة الأصول") { onNavigate(AppTab.Units) }
        DashboardShortcut("الدفتر المالي", "الحركات والتحصيل والمصروفات والتوزيعات", Icons.Default.AccountBalanceWallet, "الإدارة المالية") { onNavigate(AppTab.Finance) }
        DashboardShortcut("التحصيل والطباعة", "إعداد دفعات التحصيل وإيصالات الشهر", Icons.Default.ReceiptLong, "الدورة الشهرية") { onNavigate(AppTab.Print) }
        DashboardShortcut("العقود والأرشيف", "العقود والتجديدات والمستندات والتنبيهات", Icons.Default.FolderOpen, "المستندات") { onNavigate(AppTab.Contracts) }
        DashboardShortcut("مركز المراجعة", "مطابقة البيانات ومراجعة السجلات", Icons.Default.FactCheck, "جودة البيانات") { onNavigate(AppTab.Review) }
        DashboardShortcut("الإعدادات والنسخ الاحتياطي", "التفضيلات والاستيراد والنسخ والاستعادة", Icons.Default.Settings, "إدارة التطبيق") { onNavigate(AppTab.Settings) }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun DashboardHero() {
    Box(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp))
            .background(Brush.linearGradient(listOf(ColorNavy, ColorBlue, ColorTeal)))
    ) {
        Column(Modifier.padding(horizontal = 20.dp, vertical = 22.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(color = androidx.compose.ui.graphics.Color.White.copy(alpha = .14f), shape = RoundedCornerShape(14.dp)) {
                    Icon(Icons.Default.Apartment, contentDescription = null, tint = androidx.compose.ui.graphics.Color.White, modifier = Modifier.padding(10.dp).size(25.dp))
                }
                Spacer(Modifier.width(10.dp))
                Column {
                    Text("أملاك العائلة", color = androidx.compose.ui.graphics.Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                    Text("إدارة العقارات والإيرادات", color = androidx.compose.ui.graphics.Color.White.copy(alpha = .78f), style = MaterialTheme.typography.bodySmall)
                }
                Spacer(Modifier.weight(1f))
                Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = ColorGold, modifier = Modifier.size(25.dp))
            }
            Text("إدارة أوضح… وقرارات أدق", color = androidx.compose.ui.graphics.Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("كل سجلاتك الأساسية في مكان واحد، مع متابعة دقيقة للعقود والتحصيل والحركة المالية.", color = androidx.compose.ui.graphics.Color.White.copy(alpha = .84f), style = MaterialTheme.typography.bodyMedium, lineHeight = 21.sp)
        }
    }
}

@Composable
private fun DashboardMetric(title: String, value: String, icon: ImageVector, modifier: Modifier = Modifier, action: String, onClick: () -> Unit) {
    Card(
        modifier = modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = .55f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(shape = RoundedCornerShape(11.dp), color = MaterialTheme.colorScheme.primaryContainer) {
                    Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(8.dp).size(20.dp))
                }
                Spacer(Modifier.weight(1f))
                Icon(Icons.Default.ArrowOutward, contentDescription = "فتح $action", tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(16.dp))
            }
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface, maxLines = 1)
            Text(title, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, minLines = 2, lineHeight = 17.sp)
            Text("$action ←", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun DashboardShortcut(title: String, description: String, icon: ImageVector, category: String, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = .45f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Surface(shape = RoundedCornerShape(13.dp), color = MaterialTheme.colorScheme.primaryContainer) {
                Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(11.dp).size(23.dp))
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(title, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.titleSmall)
                Text(description, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                Text(category, color = MaterialTheme.colorScheme.tertiary, style = MaterialTheme.typography.labelSmall)
            }
            Icon(Icons.Default.ChevronLeft, contentDescription = "فتح $title", tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

private val ColorNavy = androidx.compose.ui.graphics.Color(0xFF10243A)
private val ColorBlue = androidx.compose.ui.graphics.Color(0xFF285B91)
private val ColorTeal = androidx.compose.ui.graphics.Color(0xFF16877F)
private val ColorGold = androidx.compose.ui.graphics.Color(0xFFE2B85F)

private fun dashboardMoney(value: Double): String = NumberFormat.getNumberInstance(Locale("ar", "EG")).format(value) + " ج.م"
