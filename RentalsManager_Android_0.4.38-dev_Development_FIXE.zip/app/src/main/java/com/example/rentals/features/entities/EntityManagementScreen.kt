package com.example.rentals.features.entities

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.rentals.domain.entities.EntityRepository
import com.example.rentals.domain.entities.GetEntityDirectory
import com.example.rentals.domain.entities.SaveProperty
import com.example.rentals.domain.entities.SaveTenant
import com.example.rentals.domain.entities.DeleteProperty
import com.example.rentals.domain.entities.DeleteTenant
import com.example.rentals.data.PropertyRecord
import com.example.rentals.data.TenantRecord
import com.example.rentals.ui.components.AppField

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun EntityManagementScreen(repository: EntityRepository) {
    var refresh by remember { mutableIntStateOf(0) }
    val directory=remember(refresh, repository){GetEntityDirectory(repository)()}
    val properties=directory.properties
    val tenants=directory.tenants
    val saveProperty=remember(repository){SaveProperty(repository)}
    val saveTenant=remember(repository){SaveTenant(repository)}
    val deleteProperty=remember(repository){DeleteProperty(repository)}
    val deleteTenant=remember(repository){DeleteTenant(repository)}
    var editingProperty by remember { mutableStateOf<PropertyRecord?>(null) }
    var editingTenant by remember { mutableStateOf<TenantRecord?>(null) }
    var message by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Text("إدارة العقارات والمستأجرين",fontSize=21.sp,fontWeight=FontWeight.Bold)
        Text("سجلات مستقلة مرتبطة بالوحدات والعقود، مع الاحتفاظ بتاريخ المستأجرين السابقين.",color=MaterialTheme.colorScheme.onSurfaceVariant,fontSize=13.sp)
        Row(verticalAlignment=Alignment.CenterVertically) { Text("العقارات (${properties.size})",fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f)); Button(onClick={editingProperty=PropertyRecord(name="")}) { Icon(Icons.Default.Add,null);Text("إضافة عقار") } }
        if(properties.isEmpty()) Text("لا توجد سجلات عقارات مستقلة بعد. ستُنشأ السجلات تلقائيًا أيضًا عند حفظ الوحدات.",color=MaterialTheme.colorScheme.onSurfaceVariant)
        properties.forEach { p ->
            Card(Modifier.fillMaxWidth()) { ListItem(headlineContent={Text(p.name,fontWeight=FontWeight.SemiBold)},supportingContent={Text("${p.address.ifBlank{"دون عنوان تفصيلي"}} • ${p.linkedUnits} وحدة")},trailingContent={Row { IconButton(onClick={editingProperty=p}){Icon(Icons.Default.Edit,"تعديل العقار")};IconButton(onClick={try{deleteProperty(p.id);refresh++;message="تم حذف العقار"}catch(e:Exception){message=e.message?:"تعذر الحذف"}}){Icon(Icons.Default.Delete,"حذف العقار")} }}) }
        }
        HorizontalDivider()
        Row(verticalAlignment=Alignment.CenterVertically) { Text("المستأجرون (${tenants.size})",fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f)); Button(onClick={editingTenant=TenantRecord(name="")}) { Icon(Icons.Default.Add,null);Text("إضافة مستأجر") } }
        Text("تغيير اسم المستأجر المرتبط بوحدة يتم من بطاقة الوحدة، حتى يُسجل النظام تغيير المستأجر وينشئ إيصالًا جديدًا دون المساس بالسجل التاريخي.",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
        if(tenants.isEmpty()) Text("لا توجد سجلات مستأجرين مستقلة بعد. ستُنشأ تلقائيًا عند حفظ الوحدات.",color=MaterialTheme.colorScheme.onSurfaceVariant)
        tenants.forEach { t ->
            Card(Modifier.fillMaxWidth()) { ListItem(headlineContent={Text(t.name,fontWeight=FontWeight.SemiBold)},supportingContent={Text("${t.phone.ifBlank{"لا يوجد هاتف"}} • ${t.linkedUnits} وحدة حالية • ${t.linkedLeases} عقد")},trailingContent={Row { IconButton(onClick={editingTenant=t}){Icon(Icons.Default.Edit,"تعديل بيانات المستأجر")};IconButton(onClick={try{deleteTenant(t.id);refresh++;message="تم حذف المستأجر"}catch(e:Exception){message=e.message?:"تعذر الحذف"}}){Icon(Icons.Default.Delete,"حذف المستأجر")} }}) }
        }
        if(message.isNotBlank()) Text(message,color=MaterialTheme.colorScheme.primary,fontSize=12.sp)
    }
    editingProperty?.let { item ->
        var name by remember(item.id){mutableStateOf(item.name)}; var address by remember(item.id){mutableStateOf(item.address)}; var notes by remember(item.id){mutableStateOf(item.notes)}
        AlertDialog(onDismissRequest={editingProperty=null},title={Text(if(item.id==0L)"إضافة عقار" else "تعديل العقار")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){AppField("اسم العقار",name,onChange={name=it});AppField("العنوان",address,onChange={address=it});OutlinedTextField(notes,{notes=it},label={Text("ملاحظات")},modifier=Modifier.fillMaxWidth())}},confirmButton={TextButton(onClick={try{saveProperty(item.copy(name=name,address=address,notes=notes));editingProperty=null;refresh++;message="تم حفظ العقار وربطه بوحداته"}catch(e:Exception){message=e.message?:"تعذر الحفظ"}}){Text("حفظ")}},dismissButton={TextButton(onClick={editingProperty=null}){Text("إلغاء")}})
    }
    editingTenant?.let { item ->
        var name by remember(item.id){mutableStateOf(item.name)}; var phone by remember(item.id){mutableStateOf(item.phone)}; var notes by remember(item.id){mutableStateOf(item.notes)}
        AlertDialog(onDismissRequest={editingTenant=null},title={Text(if(item.id==0L)"إضافة مستأجر" else "تعديل بيانات المستأجر")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){AppField("اسم المستأجر",name,onChange={name=it});AppField("رقم الهاتف",phone,KeyboardType.Phone,onChange={phone=it});OutlinedTextField(notes,{notes=it},label={Text("ملاحظات")},modifier=Modifier.fillMaxWidth())}},confirmButton={TextButton(onClick={try{saveTenant(item.copy(name=name,phone=phone,notes=notes));editingTenant=null;refresh++;message="تم حفظ بيانات المستأجر"}catch(e:Exception){message=e.message?:"تعذر الحفظ"}}){Text("حفظ")}},dismissButton={TextButton(onClick={editingTenant=null}){Text("إلغاء")}})
    }
}

