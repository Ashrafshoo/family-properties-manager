from pathlib import Path
root = Path(__file__).resolve().parents[1]
theme = (root / 'app/src/main/java/com/example/rentals/design/AppTheme.kt').read_text(encoding='utf-8')
dashboard = (root / 'app/src/main/java/com/example/rentals/features/dashboard/Dashboard.kt').read_text(encoding='utf-8')
components = (root / 'app/src/main/java/com/example/rentals/ui/components/PropertyComponents.kt').read_text(encoding='utf-8')
main = (root / 'app/src/main/java/com/example/rentals/MainActivity.kt').read_text(encoding='utf-8')
for token in ('DeepNavy', 'Gold', 'Teal', 'primaryContainer', 'surfaceVariant', 'displayLarge =', 'labelSmall ='):
    assert token in theme, f'missing design token/style: {token}'
for token in ('DashboardHero()', 'Brush.linearGradient', 'RoundedCornerShape(26.dp)', 'DashboardMetric(', 'DashboardShortcut(', 'لا يثبت التحصيل الفعلي'):
    assert token in dashboard, f'missing dashboard experience feature: {token}'
for token in ('RoundedCornerShape(15.dp)', 'RoundedCornerShape(19.dp)', 'OutlinedTextFieldDefaults.colors'):
    assert token in components, f'missing shared component styling: {token}'
for token in ('containerColor = MaterialTheme.colorScheme.background', 'NavigationBar(containerColor = MaterialTheme.colorScheme.surface', 'statusBarColor = if (settings.dark)'):
    assert token in main, f'missing app shell appearance: {token}'
print('PASS: premium theme, dashboard hero/cards, shared form styling, and adaptive system/navigation bars.')
