from pathlib import Path
root = Path(__file__).resolve().parents[1]
ui = (root / 'app/src/main/java/com/example/rentals/MainActivity.kt').read_text()
settings = (root / 'app/src/main/java/com/example/rentals/features/settings/SettingsScreen.kt').read_text()
combined = ui + settings
checks = {
    'document picker lifecycle exempted while active': 'event == Lifecycle.Event.ON_STOP && !pickerInProgressState.value' in ui,
    'legacy Q012 picker is not launchable from settings': 'importQ012.launch(' not in settings,
    'picker activity flag cleared on return': 'importQ012=rememberLauncherForActivityResult' in settings and 'setExternalPickerInProgress(false)' in settings,
    'one confirmation stages and migrates': 'LegacyQ012Importer.stage(ctx.contentResolver,selectedUri,db.writableDatabase)' in settings and 'db.migrateUniquelyMatchedLegacyUnitsToReview()' in settings,
    'work moved off main thread': 'withContext(Dispatchers.IO)' in settings,
    'completion summary displayed after import': 'onImportComplete(completedSummary!!)' in settings and 'importSummary.isNotBlank()' in ui,
    'bottom navigation has overflow menu': 'NavigationBarItem(selected=tab==Tab.Review||tab==Tab.Contracts||tab==Tab.Entities||tab==Tab.Settings' in ui and 'DropdownMenuItem(text={Text("الإعدادات والاستيراد")}' in ui,
    'navigation labels kept to one line': 'maxLines=1,softWrap=false,fontSize=10.sp' in ui,
    'Q022 current source and Q023 pending are disclosed': 'ملف Q022 هو مرجع البيانات الحالي' in settings and 'استيراد Q023 الشامل — قيد التجهيز، غير متاح بعد' in settings,
}
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + name)
assert all(checks.values())
