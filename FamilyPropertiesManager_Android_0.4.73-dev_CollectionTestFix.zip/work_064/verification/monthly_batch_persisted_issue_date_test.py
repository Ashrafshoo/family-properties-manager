from pathlib import Path
p=Path('app/src/main/java/com/example/rentals/features/printing/MonthlyCollectionScreen.kt').read_text()
assert 'AggregateReceiptPdfExporter.export(activity,context.contentResolver,uri,items,receipts.first().paidDate' in p
assert '},receipts.first().paidDate,3,settings.marginMm)' in p
assert '},rs.first().paidDate,3,settings.marginMm)' in p
assert 'issuedDate,3,settings.marginMm)' not in p[p.index('val exportReceiptsPdf='):p.index('Column(Modifier.fillMaxSize')]
print('PASS: saved monthly receipt exports and prints use the batch-stored issue date, not the current screen date')
