from pathlib import Path
p=Path('app/src/main/java/com/example/rentals/features/printing/MonthlyCollectionScreen.kt').read_text()
assert 'require(receipts.isNotEmpty())' in p
assert 'receipts.all{it.amount!=null && it.amount!!>0.0}' in p
assert 'اختر قالب نوفمبر الصحيح لكل إيصال قبل إنشاء Excel' in p
assert 'اختر قالب نوفمبر الصحيح لكل إيصال قبل إنشاء PDF' in p
assert 'rs.any{r->batchTemplateOptions.none{it.first==r.template}}' in p
print('PASS: PDF and Excel monthly exports reject empty batches, invalid amounts, and unassigned templates')
