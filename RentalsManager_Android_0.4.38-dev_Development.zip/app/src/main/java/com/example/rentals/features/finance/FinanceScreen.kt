import androidx.compose.ui.Modifier
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
package com.example.rentals.features.finance

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.rentals.data.repository.FinanceRepository
import com.example.rentals.domain.finance.CalculateHeirAllocations
import com.example.rentals.domain.finance.HeirPayout
import com.example.rentals.ui.components.AppField
import com.example.rentals.ui.components.PremiumScreenHeader
import java.text.NumberFormat
import java.util.Locale

private fun formatFinanceMoney(value: Double): String =
    NumberFormat.getNumberInstance(Locale("ar", "EG")).format(value) + " ج.م"

@Composable
fun FinanceScreen(repository: FinanceRepository) {
    var summary by remember { mutableStateOf(repository.getSummary()) }
    var dialog by remember { mutableStateOf("") }
    var title by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var method by remember { mutableStateOf("نقدًا") }
    var notes by remember { mutableStateOf("") }
    var period by remember { mutableStateOf(java.time.LocalDate.now().toString().take(7)) }
    var collector by remember { mutableStateOf("المحصل") }
    var expenses by remember { mutableStateOf("0") }
    var distributeDialog by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        PremiumScreenHeader(
    "الدفتر المالي",
    "المستحقات والتحصيل الفعلي وأموال المحصّل والمصروفات والتوزيعات",
    Icons.Default.AccountBalanceWallet
)
        Spacer(Modifier.height(12.dp))
        listOf(
            "الرصيد المستحق من المستأجرين" to summary.due,
            "التحصيلات التي تسلمتها من المحصل" to summary.received,
            "مبالغ محصلة وما زالت لدى المحصل" to summary.collectorHeld,
            "مصروفات مسجلة" to summary.expenses,
            "صافي غير موزع على الورثة" to summary.undistributed,
            "استلامات تاريخية تحتاج تحديد فترتها" to summary.unassignedLegacy,
            "مصروفات تاريخية تحتاج تحديد فترتها" to summary.unassignedLegacyExpenses
        ).forEach { (label, value) ->
            Card(Modifier.fillMaxWidth().padding(vertical = 3.dp), shape = androidx.compose.foundation.shape.RoundedCornerShape(18.dp), border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = .35f)), elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)) {
                ListItem(headlineContent = { Text(label) }, trailingContent = { Text(formatFinanceMoney(value), fontWeight = FontWeight.Bold) })
            }
        }
        Spacer(Modifier.height(12.dp))
        Button(onClick = { dialog = "استحقاق إيجار"; error = "" }, modifier = Modifier.fillMaxWidth()) { Text("تسجيل استحقاق إيجار") }
        OutlinedButton(onClick = { dialog = "تحصيل من مستأجر"; error = "" }, modifier = Modifier.fillMaxWidth()) { Text("تسجيل تحصيل من مستأجر") }
        OutlinedButton(onClick = { dialog = "تحصيل لدى المحصل"; error = "" }, modifier = Modifier.fillMaxWidth()) { Text("إثبات مبلغ حصّله المحصل ولم يسلّمه بعد") }
        OutlinedButton(onClick = { dialog = "استلام من المحصل"; error = "" }, modifier = Modifier.fillMaxWidth()) { Text("تسجيل استلام مبلغ من المحصل") }
        OutlinedButton(onClick = { dialog = "مصروف"; error = "" }, modifier = Modifier.fillMaxWidth()) { Text("تسجيل مصروف") }
        OutlinedButton(onClick = { distributeDialog = true }, modifier = Modifier.fillMaxWidth()) { Text("توزيع صافي المبلغ – وسيلة دفع مستقلة لكل وارث") }
        Text("طريقة استلام المبلغ من المحصل مستقلة عن طريقة الدفع لكل وارث. لا تسجل مبلغًا محصلًا لدى المحصل على أنه وصل إليك قبل الاستلام الفعلي.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }

    if (dialog.isNotBlank()) {
        AlertDialog(
            onDismissRequest = { dialog = "" },
            title = { Text(dialog) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (dialog.contains("المحصل")) AppField("اسم المحصل", collector, onChange = { v -> collector = v })
                    if (dialog == "استلام من المحصل") {
                        AppField("مصروفات تخصم من المبلغ", expenses, KeyboardType.Decimal, onChange = { v -> expenses = v })
                    }
                    AppField(if (dialog == "مصروف") "بيان المصروف" else "اسم المستأجر / الوحدة / البيان", title, onChange = { v -> title = v })
                    AppField("المبلغ بالجنيه", amount, KeyboardType.Decimal, onChange = { v -> amount = v })
                    AppField("الفترة YYYY-MM", period, onChange = { v -> period = v })
                    if (dialog == "تحصيل من مستأجر" || dialog == "استلام من المحصل" || dialog == "توزيع صافي على الورثة") {
                        AppField("طريقة الاستلام/الدفع", method, onChange = { v -> method = v })
                    }
                    AppField("ملاحظات", notes, onChange = { v -> notes = v })
                    if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val value = amount.toDoubleOrNull() ?: 0.0
                    val today = java.time.LocalDate.now().toString()
                    try {
                        when (dialog) {
                            "استحقاق إيجار" -> repository.addLedger("", title, today, period, "استحقاق", value, 0.0, "", notes)
                            "تحصيل من مستأجر" -> repository.addLedger("", title, today, period, "تحصيل", 0.0, value, method, notes)
                            "تحصيل لدى المحصل" -> repository.addCollectorReceivable(collector, period, today, value, notes)
                            "استلام من المحصل" -> repository.handoverCollector(collector, today, value, method, expenses.toDoubleOrNull() ?: 0.0, 0.0, period, notes)
                            "مصروف" -> repository.addExpense(title, value, today, period, "عام", notes)
                        }
                        summary = repository.getSummary()
                        dialog = ""; title = ""; amount = ""; notes = ""; error = ""
                    } catch (e: Exception) {
                        error = e.message ?: "تعذر حفظ الحركة"
                    }
                }) { Text("حفظ الحركة") }
            },
            dismissButton = { TextButton(onClick = { dialog = "" }) { Text("إلغاء") } }
        )
    }
    if (distributeDialog) {
        HeirDistributionDialog(repository, onClose = { distributeDialog = false }, onSaved = { summary = repository.getSummary(); distributeDialog = false })
    }
}

@Composable
private fun HeirDistributionDialog(repository: FinanceRepository, onClose: () -> Unit, onSaved: () -> Unit) {
    val heirs = remember { repository.getActiveHeirs() }
    var net by remember { mutableStateOf("") }
    var period by remember { mutableStateOf(java.time.LocalDate.now().toString().take(7)) }
    val amounts = remember { androidx.compose.runtime.mutableStateMapOf<Long, String>() }
    val methods = remember { androidx.compose.runtime.mutableStateMapOf<Long, String>() }
    var error by remember { mutableStateOf("") }
    LaunchedEffect(net, heirs) {
        val value = net.toDoubleOrNull()
        if (value != null && value.isFinite() && value > 0.0 && heirs.isNotEmpty()) {
            runCatching { CalculateHeirAllocations()(value, heirs) }
                .onSuccess { allocations -> error = ""; allocations.forEach { (id, amount) -> amounts[id] = String.format(Locale.US, "%.2f", amount) } }
                .onFailure { error = it.message ?: "تعذر حساب الأنصبة" }
        }
    }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("توزيع صافي المبلغ على الورثة") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                AppField("صافي المبلغ المراد توزيعه", net, KeyboardType.Decimal, onChange = { v -> net = v })
                AppField("فترة الأموال YYYY-MM", period, onChange = { v -> period = v })
                heirs.forEach { (id, name, share) ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(10.dp)) {
                            Text("$name  •  ${(share * 100).toInt()}%", fontWeight = FontWeight.Bold)
                            OutlinedTextField(amounts[id] ?: "", { amounts[id] = it }, label = { Text("مبلغ $name") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                            OutlinedTextField(methods[id] ?: "نقدًا", { methods[id] = it }, label = { Text("طريقة دفع $name") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        }
                    }
                }
                if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val available = net.toDoubleOrNull() ?: 0.0
                val total = heirs.sumOf { (id, _, _) -> amounts[id]?.toDoubleOrNull() ?: 0.0 }
                when {
                    available <= 0 || !available.isFinite() -> error = "أدخل صافي مبلغ صحيحًا"
                    kotlin.math.abs(available * 100.0 - kotlin.math.round(available * 100.0)) >= 0.000001 -> error = "المبلغ يجب ألا يتجاوز منزلتين عشريتين"
                    total <= 0 || kotlin.math.abs(total * 100.0 - kotlin.math.round(total * 100.0)) >= 0.000001 || total > available + 0.000001 -> error = "راجع مجموع الدفعات؛ يجب أن يكون موجبًا وبحد أقصى صافي المبلغ وبمنزلتين عشريتين"
                    else -> {
                        val today = java.time.LocalDate.now().toString()
                        val payouts = heirs.mapNotNull { (id, _, _) ->
                            val value = amounts[id]?.toDoubleOrNull() ?: 0.0
                            if (value > 0) HeirPayout(id, value, methods[id] ?: "نقدًا") else null
                        }
                        try {
                            repository.payHeirs(payouts, today, period)
                            onSaved()
                        } catch (e: Exception) {
                            error = e.message ?: "تعذر حفظ التوزيع"
                        }
                    }
                }
            }) { Text("حفظ التوزيع") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("إلغاء") } }
    )
}

