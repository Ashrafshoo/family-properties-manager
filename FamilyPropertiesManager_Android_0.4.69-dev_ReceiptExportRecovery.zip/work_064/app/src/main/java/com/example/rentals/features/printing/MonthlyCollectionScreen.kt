package com.example.rentals.features.printing

import android.print.PrintAttributes
import android.print.PrintManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.fragment.app.FragmentActivity
import com.example.rentals.domain.collection.MonthlyCollectionRepository
import com.example.rentals.domain.collection.PrepareMonthlyCollection
import com.example.rentals.data.UnitRecord
import com.example.rentals.data.AggregateReceiptItem
import com.example.rentals.ui.UiSettings
import com.example.rentals.printing.OriginalReceiptTemplateRenderer
import com.example.rentals.printing.ReceiptDateFormat
import com.example.rentals.printing.AggregateReceiptPdfExporter
import com.example.rentals.printing.AggregateReceiptPrintAdapter
import com.example.rentals.printing.CollectorSheetPdfExporter
import com.example.rentals.ui.components.PremiumScreenHeader
import com.example.rentals.io.WorkbookExporter
import com.example.rentals.io.AggregateStatementWorkbookExporter
import java.text.NumberFormat
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private fun formatCollectionMoney(value: Double): String =
    NumberFormat.getNumberInstance(Locale("ar", "EG")).format(value) + " ج.م"

private fun aggregateExportDigits(value: String): String = value.map { ch ->
    if (ch in '0'..'9') ('٠'.code + (ch - '0')).toChar() else ch
}.joinToString("")

private fun aggregateImportDigits(value: String): String = value.map { ch ->
    if (ch in '٠'..'٩') ('0'.code + (ch - '٠')).toChar() else ch
}.joinToString("")

private fun aggregateExportMoney(value: Double): String {
    val western = java.text.NumberFormat.getNumberInstance(java.util.Locale.US).format(value)
    return aggregateExportDigits(western)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun MonthlyCollectionScreen(activity:FragmentActivity,repository:MonthlyCollectionRepository,units:List<UnitRecord>,settings:UiSettings,setExternalPickerInProgress:(Boolean)->Unit){
    val prepareMonthlyCollection = remember(repository) { PrepareMonthlyCollection(repository) }
    var period by remember { mutableStateOf(java.time.YearMonth.now().toString()) }
    var issuedDate by remember { mutableStateOf(ReceiptDateFormat.toSheet(java.time.LocalDate.now().toString())) }
    var propertyFilter by remember { mutableStateOf("الكل") }
    var selected by remember { mutableStateOf<Set<Long>>(emptySet()) }
    var refresh by remember { mutableIntStateOf(0) }
    var activeBatch by remember { mutableStateOf<Long?>(null) }
    var message by remember { mutableStateOf("") }
    val properties=remember(units){units.map{it.property}.filter{it.isNotBlank()}.distinct().sorted()}
    // Printing is a user-selected document workflow, not an eligibility/approval workflow.
    // Keep every unit visible; unit status must not block receipt preparation or export.
    val displayedUnits=remember(units,propertyFilter){units.filter{propertyFilter=="الكل"||it.property==propertyFilter}}
    LaunchedEffect(displayedUnits) { selected = selected.intersect(displayedUnits.map { it.id }.toSet()) }
    val batches=remember(refresh){repository.getBatches()}
    val batchReceipts=remember(activeBatch,refresh){activeBatch?.let{repository.getBatchReceipts(it)}?: emptyList()}
    val printManager=activity.getSystemService(android.content.Context.PRINT_SERVICE) as PrintManager
    val context= LocalContext.current
    val exportScope= rememberCoroutineScope()
    var exportBusy by remember { mutableStateOf(false) }
    var templateMenuFor by remember { mutableStateOf<Long?>(null) }
    val batchTemplateOptions = remember { runCatching { OriginalReceiptTemplateRenderer(context).templateIds(monthlyOnly = true) }.getOrDefault(emptyList()) }
    var exportBatchId by remember{mutableLongStateOf(0L)}
    var editingCollectionItem by remember{mutableStateOf<Array<String>?>(null)}
    var aggregateExportItems by remember { mutableStateOf<List<AggregateReceiptItem>>(emptyList()) }
    val exportAggregatePdf = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        setExternalPickerInProgress(false)
        if (uri != null && aggregateExportItems.isNotEmpty() && !exportBusy) {
            exportBusy = true
            val items = aggregateExportItems
            exportScope.launch { try {
                withContext(Dispatchers.IO) { AggregateReceiptPdfExporter.export(activity, context.contentResolver, uri, items, issuedDate, 3, settings.marginMm) }
                message = "تم حفظ إيصالات الكشف المجمع PDF دون تسجيل سداد."
            } catch (e: Exception) { message = "تعذر حفظ PDF: ${e.message}" } finally { exportBusy = false } }
        }
    }
    val exportAggregateExcel = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")) { uri ->
        setExternalPickerInProgress(false)
        if (uri != null && aggregateExportItems.isNotEmpty() && !exportBusy) {
            exportBusy = true
            val items = aggregateExportItems
            exportScope.launch { try {
                withContext(Dispatchers.IO) { AggregateStatementWorkbookExporter.export(context, context.contentResolver, uri, items, period) }
                message = "تم تصدير بيانات الإيصالات المحددة إلى Excel."
            } catch (e: Exception) { message = "تعذر تصدير Excel: ${e.message}" } finally { exportBusy = false } }
        }
    }
    val exportCollectorPdf=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")){uri->setExternalPickerInProgress(false);if(uri!=null&&exportBatchId>0&&!exportBusy){exportBusy=true;val id=exportBatchId;exportScope.launch{try{withContext(Dispatchers.IO){val b=repository.getBatches().first{it.id==id};val rows=repository.getBatchItems(id).map{arrayOf(it[1],it[2],it[3],it[4],collectionStatusArabic(it[5]),it[6],it[8])};CollectorSheetPdfExporter.export(context.contentResolver,uri,b.title,rows)};message="تم إنشاء كشف المحصّل PDF للوحدات المحددة فقط."}catch(e:Exception){message="تعذر إنشاء PDF: ${e.message}"}finally{exportBusy=false}}}}
    val exportCollectorXlsx=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")){uri->setExternalPickerInProgress(false);if(uri!=null&&exportBatchId>0&&!exportBusy){exportBusy=true;val id=exportBatchId;exportScope.launch{try{withContext(Dispatchers.IO){val b=repository.getBatches().first{it.id==id};val data=repository.getBatchItems(id);WorkbookExporter.exportRows(context.contentResolver,uri,b.title,listOf("كود الوحدة","العقار","المستأجر","قيمة الإيجار","حالة التحصيل","المبلغ المحصل فعليًا","تاريخ التحصيل","ملاحظات"),data.map{listOf(it[1],it[2],it[3],it[4],collectionStatusArabic(it[5]),it[6],it[7],it[8])})};message="تم تصدير كشف المحصّل Excel للوحدات المحددة فقط."}catch(e:Exception){message="تعذر إنشاء Excel: ${e.message}"}finally{exportBusy=false}}}}
    val exportReceiptsPdf=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")){uri->setExternalPickerInProgress(false);if(uri!=null&&exportBatchId>0&&!exportBusy){exportBusy=true;val id=exportBatchId;exportScope.launch{try{withContext(Dispatchers.IO){val receipts=repository.getBatchReceipts(id);val items=receipts.map{r->AggregateReceiptItem(statementId=0L,tenant=r.tenant,amount=r.amount?:error("قيمة الإيجار غير محددة للمستأجر ${r.tenant}"),property=r.property,unitCode="",description="",address="",templateId=r.template,notes=r.notes)};require(items.all{item->batchTemplateOptions.any{it.first==item.templateId}}){"اختر قالب نوفمبر الصحيح لكل إيصال قبل إنشاء PDF"};AggregateReceiptPdfExporter.export(activity,context.contentResolver,uri,items,issuedDate,3,settings.marginMm)};message="تم إنشاء PDF بالقوالب الأصلية المختارة، ثلاثة إيصالات في صفحة A4."}catch(e:Exception){message="تعذر إنشاء PDF للإيصالات: ${e.message}"}finally{exportBusy=false}}}}
    val exportReceiptsXlsx=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")){uri->setExternalPickerInProgress(false);if(uri!=null&&exportBatchId>0&&!exportBusy){exportBusy=true;val id=exportBatchId;exportScope.launch{try{withContext(Dispatchers.IO){val b=repository.getBatches().first{it.id==id};val receipts=repository.getBatchReceipts(id);val items=receipts.map{r->AggregateReceiptItem(statementId=0L,tenant=r.tenant,amount=r.amount?:error("قيمة الإيجار غير محددة للمستأجر ${r.tenant}"),property=r.property,unitCode=r.unitCode,description="",address="",templateId=r.template,notes=r.notes)};AggregateStatementWorkbookExporter.export(context,context.contentResolver,uri,items,b.period)};message="تم تصدير إيصالات الدفعة داخل قالب Excel الأصلي."}catch(e:Exception){message="تعذر إنشاء Excel للإيصالات: ${e.message}"}finally{exportBusy=false}}}}
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal=12.dp, vertical=10.dp),verticalArrangement=Arrangement.spacedBy(9.dp)) {
        PremiumScreenHeader("التحصيل الشهري والإيصالات", "حدد الوحدات والفترة ثم جهّز الإيصالات للطباعة أو التصدير PDF وExcel. إنشاء الدفعة لا يثبت السداد الفعلي ولا ينشئ قيدًا ماليًا.", Icons.Default.ReceiptLong)
        Text("اختر الوحدات وحدد الشهر وتاريخ الإصدار، ثم اضغط إعداد الطباعة. لا تتطلب طباعة الإيصالات اعتماد حالة الوحدة.",fontSize=12.sp,color=MaterialTheme.colorScheme.primary)
        OutlinedTextField(value=aggregateExportDigits(period),onValueChange={period=aggregateImportDigits(it)},label={Text("شهر التحصيل بصيغة سنة-شهر")},singleLine=true,modifier=Modifier.fillMaxWidth())
        OutlinedTextField(value=issuedDate,onValueChange={issuedDate=it},label={Text("تاريخ إصدار الإيصالات (سنة/شهر/يوم)")},singleLine=true,modifier=Modifier.fillMaxWidth())
        AggregateStatementsPanel(
            period = period,
            issuedDate = issuedDate,
            repository = repository,
            refreshKey = refresh,
            onChanged = { refresh++ },
            onPrepareSelected = { items ->
                if (items.isNotEmpty()) {
                    val normalizedPrintDate = runCatching {
                        ReceiptDateFormat.toSheet(ReceiptDateFormat.toStorage(issuedDate))
                    }.getOrNull()
                    if (normalizedPrintDate == null) {
                        message = "تاريخ الإصدار غير صحيح؛ استخدم صيغة سنة/شهر/يوم."
                    } else {
                        val attributes = PrintAttributes.Builder()
                            .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                            .setResolution(PrintAttributes.Resolution("rentals", "طباعة", 300, 300))
                            .setMinMargins(PrintAttributes.Margins.NO_MARGINS).build()
                        printManager.print("إيصالات_الكشف_المجمع_$period", AggregateReceiptPrintAdapter(activity, items, normalizedPrintDate, 3, settings.marginMm), attributes)
                    }
                }
            },
            onExportSelectedPdf = { items -> aggregateExportItems = items; setExternalPickerInProgress(true); exportAggregatePdf.launch("إيصالات_الكشف_المجمع_$period.pdf") },
            onExportSelectedExcel = { items -> aggregateExportItems = items; setExternalPickerInProgress(true); exportAggregateExcel.launch("بيانات_الإيصالات_المجمعة_$period.xlsx") }
        )
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp),verticalAlignment=Alignment.CenterVertically){
            var expanded by remember{mutableStateOf(false)}
            Box(Modifier.weight(1f)){
                OutlinedButton(onClick={expanded=true},modifier=Modifier.fillMaxWidth()){Text("العقار: $propertyFilter")}
                DropdownMenu(expanded=expanded,onDismissRequest={expanded=false}){
                    DropdownMenuItem(text={Text("كل العقارات")},onClick={propertyFilter="الكل";selected=emptySet();expanded=false})
                    properties.forEach{p->DropdownMenuItem(text={Text(p)},onClick={propertyFilter=p;selected=emptySet();expanded=false})}
                }
            }
            Text("${selected.size} محدد",fontWeight=FontWeight.Bold)
        }
        Row(verticalAlignment=Alignment.CenterVertically){
            Checkbox(checked=displayedUnits.isNotEmpty()&&displayedUnits.all{it.id in selected},onCheckedChange={checked->selected=if(checked)displayedUnits.map{it.id}.toSet() else selected-displayedUnits.map{it.id}.toSet()})
            Text("تحديد كل الوحدات (${displayedUnits.size})")
            Spacer(Modifier.weight(1f))
            TextButton(onClick={selected=emptySet()}){Text("إلغاء التحديد")}
        }
        displayedUnits.forEach{u->
            Card(Modifier.fillMaxWidth(), shape=androidx.compose.foundation.shape.RoundedCornerShape(18.dp), border=androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha=.35f)), elevation=CardDefaults.cardElevation(defaultElevation=1.dp), colors=CardDefaults.cardColors(containerColor=if(u.id in selected)MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surface)){
                Row(Modifier.fillMaxWidth().padding(horizontal=8.dp,vertical=2.dp),verticalAlignment=Alignment.CenterVertically){
                    Checkbox(checked=u.id in selected,onCheckedChange={checked->selected=if(checked)selected+u.id else selected-u.id})
                    Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(1.dp)){
                        Text("${u.code} • ${u.tenant}",fontWeight=FontWeight.SemiBold)
                        Text("${u.property} • ${u.rent?.let{formatCollectionMoney(it)}?:"القيمة غير محددة"}",fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
        Button(onClick={
            try {
                val oldBatchIds = batches.map { it.id }.toSet()
                val id = prepareMonthlyCollection(period, ReceiptDateFormat.toStorage(issuedDate), selected, if(propertyFilter=="الكل")"" else propertyFilter)
                activeBatch = id
                // Match only exact tenant-name equivalents. Ambiguous or approximate matches stay unassigned.
                val renderer = OriginalReceiptTemplateRenderer(context)
                repository.getBatchReceipts(id).filter { it.template.isBlank() }.forEach { receipt ->
                    renderer.uniqueExactTemplateIdForTenant(receipt.tenant)?.let { templateId ->
                        repository.updateBatchReceiptTemplate(receipt.id, templateId)
                    }
                }
                refresh++
                val reopened = id in oldBatchIds
                message = if (reopened) "تم فتح دفعة محفوظة سابقًا بدل إنشاء نسخة مكررة. راجع القوالب غير المحددة ثم صدّر." else "تم تجهيز الدفعة. عُيّنت القوالب المطابقة للاسم بدقة تلقائيًا؛ راجع أي قالب متبقٍ قبل PDF."
            } catch(e:Exception) { message=e.message?:"تعذر تجهيز الدفعة" }
        },enabled=selected.isNotEmpty(),modifier=Modifier.fillMaxWidth()) { Text("إعداد الطباعة وتجهيز الإيصالات (${selected.size})") }
        activeBatch?.let { quickBatchId ->
            val quickBatch=batches.firstOrNull{it.id==quickBatchId}
            Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.secondaryContainer)) {
                Column(Modifier.fillMaxWidth().padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                    Text("إجراءات الإيصالات للدفعة المحددة",fontWeight=FontWeight.Bold)
                    Text("عدد الإيصالات في الدفعة: ${aggregateExportDigits(batchReceipts.size.toString())}",fontSize=12.sp)
                    val missingTemplates = batchReceipts.count { receipt -> batchTemplateOptions.none { it.first == receipt.template } }
                    Text("قوالب غير محددة: ${aggregateExportDigits(missingTemplates.toString())}",fontSize=12.sp,color=if(missingTemplates==0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                    Text(quickBatch?.title.orEmpty(),fontSize=12.sp)
                    Text("اختر قالب الإيصال الأصلي لكل مستأجر قبل الطباعة أو التصدير:",fontSize=12.sp,color=MaterialTheme.colorScheme.primary)
                    batchReceipts.forEach { receipt ->
                        Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(receipt.tenant,fontWeight=FontWeight.Medium,fontSize=12.sp)
                                Text(receipt.unitCode.ifBlank { receipt.property },fontSize=10.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Box {
                                OutlinedButton(onClick={templateMenuFor=receipt.id},enabled=batchTemplateOptions.isNotEmpty()) {
                                    Text(batchTemplateOptions.firstOrNull{it.first==receipt.template}?.first ?: "اختر القالب",fontSize=11.sp)
                                }
                                DropdownMenu(expanded=templateMenuFor==receipt.id,onDismissRequest={templateMenuFor=null}) {
                                    batchTemplateOptions.forEach { option -> DropdownMenuItem(text={Text(option.second,fontSize=11.sp)},onClick={
                                        try { repository.updateBatchReceiptTemplate(receipt.id,option.first); refresh++; message="تم حفظ قالب ${option.first} لهذا الإيصال." }
                                        catch(e:Exception){message=e.message?:"تعذر حفظ القالب"}; templateMenuFor=null
                                    }) }
                                }
                            }
                        }
                    }
                    Button(onClick={val receipts=repository.getBatchReceipts(quickBatchId);if(receipts.isEmpty())message="لا توجد إيصالات للطباعة في هذه الدفعة" else if(receipts.any{r->r.amount==null})message="توجد قيمة إيجار غير محددة؛ راجع بيانات المستأجر قبل الطباعة" else if(receipts.any{r->batchTemplateOptions.none{it.first==r.template}})message="اختر قالب نوفمبر الصحيح لكل إيصال أولًا" else printManager.print("إيصالات_${aggregateExportDigits(quickBatch?.period?:"")}",AggregateReceiptPrintAdapter(activity,receipts.map{r->AggregateReceiptItem(statementId=0L,tenant=r.tenant,amount=r.amount?:error("قيمة الإيجار غير محددة للمستأجر ${r.tenant}"),property=r.property,unitCode="",description="",address="",templateId=r.template,notes=r.notes)},issuedDate,3,settings.marginMm),PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).setResolution(android.print.PrintAttributes.Resolution("rentals","طباعة",300,300)).setMinMargins(PrintAttributes.Margins.NO_MARGINS).build())},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.Print,null);Spacer(Modifier.width(6.dp));Text("طباعة الإيصالات — ٣ في A4")}
                    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(enabled=!exportBusy,onClick={
                            val rs=repository.getBatchReceipts(quickBatchId)
                            when {
                                rs.isEmpty() -> message="هذه الدفعة لا تحتوي إيصالات؛ لم يتم فتح الحفظ."
                                rs.any{it.amount==null} -> message="توجد قيمة إيجار ناقصة؛ راجع بيانات الوحدة قبل PDF."
                                rs.any{r->batchTemplateOptions.none{it.first==r.template}} -> message="لم يتم إنشاء PDF: توجد إيصالات بلا قالب محدد. اختر القالب الصحيح لكل اسم أولًا."
                                else -> { exportBatchId=quickBatchId;setExternalPickerInProgress(true);exportReceiptsPdf.launch("إيصالات_${aggregateExportDigits(quickBatch?.period?:"الدفعة")}.pdf") }
                            }
                        },modifier=Modifier.weight(1f)){Text("حفظ PDF")}
                        OutlinedButton(enabled=!exportBusy,onClick={
                            val rs=repository.getBatchReceipts(quickBatchId)
                            when {
                                rs.isEmpty() -> message="هذه الدفعة لا تحتوي إيصالات؛ لم يتم فتح الحفظ."
                                rs.any{it.amount==null} -> message="توجد قيمة إيجار ناقصة؛ راجع بيانات الوحدة قبل Excel."
                                else -> { exportBatchId=quickBatchId;setExternalPickerInProgress(true);exportReceiptsXlsx.launch("إيصالات_${aggregateExportDigits(quickBatch?.period?:"الدفعة")}.xlsx") }
                            }
                        },modifier=Modifier.weight(1f)){Text("تصدير Excel")}
                    }
                }
            }
        }
        if(message.isNotBlank())Text(message,color=MaterialTheme.colorScheme.primary,fontSize=12.sp)
        HorizontalDivider()
        Text("دفعات التحصيل المحفوظة",fontWeight=FontWeight.Bold)
        batches.forEach{b->
            Card(Modifier.fillMaxWidth()){
                Row(Modifier.fillMaxWidth().padding(10.dp),verticalAlignment=Alignment.CenterVertically){
                    Column(Modifier.weight(1f)){
                        Text(b.title,fontWeight=FontWeight.SemiBold)
                        Text("${aggregateExportDigits(b.itemCount.toString())} وحدة • ${if(b.propertyFilter.isBlank())"كل العقارات" else b.propertyFilter}",fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    TextButton(onClick={activeBatch=b.id;refresh++}){Text("عرض")}
                    IconButton(onClick={
                        activeBatch=b.id
                        val rs=repository.getBatchReceipts(b.id)
                        when {
                            rs.isEmpty() -> message="الدفعة ${b.id} لا تحتوي إيصالات."
                            rs.any{it.amount==null} -> message="الدفعة ${b.id}: توجد قيمة إيجار ناقصة؛ لا يمكن إنشاء الإيصالات."
                            rs.any{r->batchTemplateOptions.none{it.first==r.template}} -> message="الدفعة ${b.id}: توجد قوالب غير محددة. افتح الدفعة واختر القالب لكل إيصال."
                            else -> printManager.print("إيصالات_${aggregateExportDigits(b.period)}",AggregateReceiptPrintAdapter(activity,rs.map{r->AggregateReceiptItem(statementId=0L,tenant=r.tenant,amount=r.amount?:error("قيمة الإيجار غير محددة للمستأجر ${r.tenant}"),property=r.property,unitCode="",description="",address="",templateId=r.template,notes=r.notes)},issuedDate,3,settings.marginMm),PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).setResolution(android.print.PrintAttributes.Resolution("rentals","طباعة",300,300)).setMinMargins(PrintAttributes.Margins.NO_MARGINS).build())
                        }
                    }){Icon(Icons.Default.Print,"طباعة الإيصالات")}
                }
            }
        }
        activeBatch?.let{batchId->
            val b=batches.firstOrNull{it.id==batchId}
            HorizontalDivider()
            Text(b?.title?:"دفعة التحصيل",fontWeight=FontWeight.Bold)
            Text("كشف المحصّل يضم عناصر هذه الدفعة المختارة فقط، ولا يشمل الوحدات غير المختارة.",fontSize=12.sp)
            repository.getBatchItems(batchId).forEach{row->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.fillMaxWidth().padding(10.dp),verticalArrangement=Arrangement.spacedBy(4.dp)) {
                        Text("${row[1]} • ${row[3]}",fontWeight=FontWeight.SemiBold)
                        Text("${row[2]} • الإيجار: ${row[4].ifBlank{"غير محدد"}} جنيه",fontSize=12.sp)
                        Text("الحالة: ${collectionStatusArabic(row[5])} • المحصل فعليًا: ${row[6].ifBlank{"—"}} جنيه",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
                        if(row[8].isNotBlank()) Text("ملاحظة: ${row[8]}",fontSize=12.sp)
                        TextButton(onClick={editingCollectionItem=row}){Text("تسجيل / تعديل نتيجة مرور المحصّل")}
                    }
                }
            }
            OutlinedButton(onClick={
                val rs=repository.getBatchReceipts(batchId)
                if(rs.isNotEmpty() && rs.all{r->r.amount!=null && batchTemplateOptions.any{it.first==r.template}})printManager.print("إيصالات_${aggregateExportDigits(b?.period?:"")}",AggregateReceiptPrintAdapter(activity,rs.map{r->AggregateReceiptItem(statementId=0L,tenant=r.tenant,amount=r.amount?:error("قيمة الإيجار غير محددة للمستأجر ${r.tenant}"),property=r.property,unitCode="",description="",address="",templateId=r.template,notes=r.notes)},issuedDate,3,settings.marginMm),PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).setResolution(android.print.PrintAttributes.Resolution("rentals","طباعة",300,300)).setMinMargins(PrintAttributes.Margins.NO_MARGINS).build())
            },modifier=Modifier.fillMaxWidth()){Text("طباعة إيصالات هذه الدفعة – ٣ في A4")}
            Text("تصدير إيصالات الإيجار (مستند مستقل عن كشف المحصّل)",fontWeight=FontWeight.SemiBold)
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
                OutlinedButton(enabled=!exportBusy,onClick={exportBatchId=batchId;setExternalPickerInProgress(true);exportReceiptsPdf.launch("إيصالات_${aggregateExportDigits(b?.period?:"الدفعة")}.pdf")},modifier=Modifier.weight(1f)){Text("إيصالات PDF")}
                OutlinedButton(enabled=!exportBusy,onClick={exportBatchId=batchId;setExternalPickerInProgress(true);exportReceiptsXlsx.launch("بيانات_الإيصالات_${aggregateExportDigits(b?.period?:"الدفعة")}.xlsx")},modifier=Modifier.weight(1f)){Text("إيصالات Excel")}
            }
            Text("كشف المحصّل (بيانات المرور والتحصيل الفعلي)",fontWeight=FontWeight.SemiBold)
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
                OutlinedButton(enabled=!exportBusy,onClick={exportBatchId=batchId;setExternalPickerInProgress(true);exportCollectorPdf.launch("${b?.title?:"كشف_التحصيل"}.pdf")},modifier=Modifier.weight(1f)){Text("كشف PDF")}
                OutlinedButton(enabled=!exportBusy,onClick={exportBatchId=batchId;setExternalPickerInProgress(true);exportCollectorXlsx.launch("${b?.title?:"كشف_التحصيل"}.xlsx")},modifier=Modifier.weight(1f)){Text("كشف Excel")}
            }
        }
    }
    editingCollectionItem?.let { row ->
        var status by remember(row[0]) { mutableStateOf(row[5].ifBlank { "not_recorded" }) }
        var amount by remember(row[0]) { mutableStateOf(row[6]) }
        var date by remember(row[0]) { mutableStateOf(ReceiptDateFormat.toSheet(row[7].ifBlank { java.time.LocalDate.now().toString() })) }
        var notes by remember(row[0]) { mutableStateOf(row[8]) }
        var statusMenu by remember { mutableStateOf(false) }
        AlertDialog(onDismissRequest={editingCollectionItem=null},title={Text("نتيجة التحصيل — ${row[1]}")},text={
            Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
                Text("${row[3]} • ${row[2]}")
                Box { OutlinedButton(onClick={statusMenu=true},modifier=Modifier.fillMaxWidth()){Text("الحالة: ${collectionStatusArabic(status)}")};DropdownMenu(expanded=statusMenu,onDismissRequest={statusMenu=false}){listOf("not_recorded","paid","partial","unpaid","unreachable").forEach{v->DropdownMenuItem(text={Text(collectionStatusArabic(v))},onClick={status=v;statusMenu=false})}} }
                OutlinedTextField(amount,{amount=it},label={Text("المبلغ المحصل فعليًا (جنيه)")},singleLine=true,modifier=Modifier.fillMaxWidth())
                OutlinedTextField(date,{date=it},label={Text("تاريخ المرور (سنة/شهر/يوم)")},singleLine=true,modifier=Modifier.fillMaxWidth())
                OutlinedTextField(notes,{notes=it},label={Text("ملاحظات المحصّل")},minLines=2,modifier=Modifier.fillMaxWidth())
                Text("تسجيل النتيجة لا ينشئ إيصال سداد أو قيدًا ماليًا تلقائيًا.",fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },confirmButton={TextButton(onClick={try{val value=amount.trim().takeIf{it.isNotEmpty()}?.toDouble();repository.recordCollectorResult(row[0].toLong(),status,value,ReceiptDateFormat.toStorage(date),notes.trim());message="تم حفظ نتيجة مرور المحصّل دون إنشاء قيد مالي.";refresh++}catch(e:Exception){message=e.message?:"تعذر حفظ النتيجة"};editingCollectionItem=null}){Text("حفظ النتيجة")}},dismissButton={TextButton(onClick={editingCollectionItem=null}){Text("إلغاء")}})
    }
}

private fun collectionStatusArabic(status:String):String = when(status){"not_recorded"->"لم تسجل بعد";"paid"->"تم التحصيل";"partial"->"تحصيل جزئي";"unpaid"->"لم يتم التحصيل";"unreachable"->"تعذر الوصول";else->status}

