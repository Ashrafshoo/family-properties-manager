package com.example.rentals.printing

import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextUtils
import android.text.TextPaint
import android.util.LruCache
import androidx.core.content.res.ResourcesCompat
import com.example.rentals.R
import com.example.rentals.data.AggregateReceiptItem
import org.json.JSONObject
import java.util.Locale
import kotlin.math.max

/** Renders one receipt from the workbook-derived cell/style catalog; it never writes to the ledger. */
internal class OriginalReceiptTemplateRenderer(private val context: Context) {
    private val catalog: JSONObject by lazy {
        context.assets.open("receipt_templates/receipt_template_catalog_v1.json").bufferedReader().use { JSONObject(it.readText()) }
    }
    // A small bounded cache avoids decoding the same signature strip for every
    // receipt in a large monthly print/export batch.
    private val sideImageCache = object : LruCache<String, android.graphics.Bitmap>(4 * 1024) {
        override fun sizeOf(key: String, value: android.graphics.Bitmap): Int = (value.byteCount / 1024).coerceAtLeast(1)
    }

    private fun sideImage(file: String): android.graphics.Bitmap? {
        sideImageCache.get(file)?.let { return it }
        val decoded = context.assets.open("receipt_templates/$file").use { BitmapFactory.decodeStream(it) } ?: return null
        sideImageCache.put(file, decoded)
        return decoded
    }
    private val templates: Map<String, JSONObject> by lazy {
        val array = catalog.getJSONArray("templates")
        buildMap { for (i in 0 until array.length()) { val item = array.getJSONObject(i); put(item.getString("template_id"), item) } }
    }

    fun templateIds(): List<Pair<String, String>> = templateIds(monthlyOnly = false)

    fun templateIds(monthlyOnly: Boolean): List<Pair<String, String>> = templates.values
        .filter { !monthlyOnly || it.optBoolean("monthlyEligible", true) }
        .map {
            val sampleTenant = it.optString("tenant_text").trim().takeIf(String::isNotBlank)
            val label = listOf(it.getString("template_id"), it.optString("sheet"), it.optString("legal_variant"), sampleTenant)
                .filterNotNull().filter(String::isNotBlank).joinToString(" — ")
            it.getString("template_id") to label
        }

    /** Returns a template only when the tenant text matches exactly after conservative Arabic normalization. */
    fun uniqueExactTemplateIdForTenant(tenant: String): String? {
        fun key(value: String): String = java.text.Normalizer.normalize(value, java.text.Normalizer.Form.NFD)
            .replace(Regex("\\p{Mn}+"), "")
            .replace('ـ', ' ')
            .replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا')
            .replace('ى', 'ي')
            .lowercase(Locale.ROOT)
            .replace(Regex("^(السيد|السادة|السيدة|مدام|م|ا)\\s*/?\\s*"), "")
            .replace(Regex("[^\\p{L}\\p{N}]+"), "")
        val target = key(tenant)
        if (target.isBlank()) return null
        val matches = templates.values.filter { template ->
            template.optBoolean("monthlyEligible", true) && key(template.optString("tenant_text")) == target
        }
        return matches.singleOrNull()?.optString("template_id")?.takeIf(String::isNotBlank)
    }

    private data class TextCell(val text: String, val x: Float, val y: Float, val width: Float, val height: Float, val style: JSONObject)

    fun draw(canvas: Canvas, target: RectF, item: AggregateReceiptItem, issuedDate: String) {
        require(item.templateId.isNotBlank()) { "يجب تحديد نموذج الإيصال قبل المعاينة أو الطباعة" }
        val template = templates[item.templateId]
            ?: error("نموذج الإيصال ${item.templateId} غير موجود في فهرس قوالب نوفمبر")
        val grid = template.getJSONObject("grid")
        val columns = grid.getJSONObject("columnWidths")
        val rows = grid.getJSONObject("rowHeights")
        val colKeys = columns.keys().asSequence().toList().sortedBy { colKeyToIndex(it) }
        val rowKeys = rows.keys().asSequence().toList().sortedBy { it.toIntOrNull() ?: 0 }
        // Excel stores column width in character units, not points. Convert using
        // Excel's pixel-width rule (Calibri 11 maximum digit width ~= 7 px),
        // including the cell padding before converting CSS-like pixels to points.
        val colWidths = colKeys.associateWith { key ->
            val chars = columns.optDouble(key, 10.0).coerceAtLeast(0.0)
            val pixels = kotlin.math.floor((256.0 * chars + kotlin.math.floor(128.0 / 7.0)) / 256.0 * 7.0 + 5.0)
            max(1f, (pixels * 0.75).toFloat())
        }
        val rowHeights = rowKeys.associateWith { max(1f, rows.optDouble(it, 18.0).toFloat()) }
        val totalWidth = colKeys.sumOf { colWidths[it]!!.toDouble() }.toFloat().coerceAtLeast(1f)
        val totalHeight = rowKeys.sumOf { rowHeights[it]!!.toDouble() }.toFloat().coerceAtLeast(1f)
        // Preserve the workbook's aspect ratio; never stretch the receipt to fill a print slot.
        val scale = minOf(target.width() / totalWidth, target.height() / totalHeight)
        val offsetX = (target.width() - totalWidth * scale) / 2f
        val offsetY = (target.height() - totalHeight * scale) / 2f
        canvas.save()
        try {
        // A grouped workbook picture may extend beyond the nominal cell grid.
        // Keep that overflow inside this receipt slot so it cannot paint over
        // the next receipt on the same A4 page.
        canvas.clipRect(target)
        canvas.translate(target.left + offsetX, target.top + offsetY)
        canvas.scale(scale, scale)
        canvas.drawRect(0f, 0f, totalWidth, totalHeight, Paint().apply { color = android.graphics.Color.WHITE })

        val styles = catalog.getJSONArray("styles")
        val fonts = catalog.getJSONArray("fonts")
        val fills = catalog.getJSONArray("fills")
        val borders = catalog.getJSONArray("borders")
        val alignments = catalog.getJSONArray("alignments")
        val cells = grid.getJSONArray("cells")
        val cellMap = HashMap<String, JSONObject>()
        for (i in 0 until cells.length()) {
            val cell = cells.getJSONObject(i)
            cellMap["${cell.optInt("r")},${cell.optInt("c")}"] = cell
        }
        val merged = grid.optJSONArray("merged")
        val mergedStarts = HashMap<String, JSONObject>()
        val mergedCovered = HashSet<String>()
        if (merged != null) for (i in 0 until merged.length()) {
            val m = merged.getJSONObject(i)
            mergedStarts["${m.optInt("r1")},${m.optInt("c1")}"] = m
            for (r in m.optInt("r1")..m.optInt("r2")) for (c in m.optInt("c1")..m.optInt("c2")) {
                if (r != m.optInt("r1") || c != m.optInt("c1")) mergedCovered += "$r,$c"
            }
        }
        val overrides = fieldOverrides(template, item, issuedDate)
        val textCells = mutableListOf<TextCell>()
        var y = 0f
        rowKeys.forEachIndexed { ri, rowKey ->
            val rowIndex = rowKey.toIntOrNull() ?: ri
            val h = rowHeights[rowKey]!!
            colKeys.forEach { colKey ->
                val colIndex = colKeyToIndex(colKey)
                val key = "$rowIndex,$colIndex"
                val cell = cellMap[key]
                if (key !in mergedCovered) {
                    val merge = mergedStarts[key]
                    val endRow = merge?.optInt("r2", rowIndex) ?: rowIndex
                    val endCol = merge?.optInt("c2", colIndex) ?: colIndex
                    val spanColumns = colKeys.filter { key ->
                val index = colKeyToIndex(key)
                index >= colIndex && index <= endCol
            }
                    val w = spanColumns.sumOf { colWidths[it]!!.toDouble() }.toFloat()
                    val rightToLeft = template.optBoolean("rightToLeft", true)
                    val x = if (rightToLeft) {
                        totalWidth - colKeys.filter { colKeyToIndex(it) <= endCol }.sumOf { colWidths[it]!!.toDouble() }.toFloat()
                    } else {
                        colKeys.filter { colKeyToIndex(it) < colIndex }.sumOf { colWidths[it]!!.toDouble() }.toFloat()
                    }
                    val hh = if (merge == null) h else (rowIndex..endRow).sumOf { r -> rowHeights[rowKeys.getOrNull(r)]?.toDouble() ?: 0.0 }.toFloat()
                    if (cell != null) {
                        val styleId = cell.optInt("styleId", 0)
                        val style = styles.optJSONObject(styleId) ?: JSONObject()
                        drawCellBackground(canvas, x, y, w, hh, style, fills)
                        val address = cell.optString("addr")
                        val raw = overrides[address] ?: cell.opt("value")?.takeUnless { it == JSONObject.NULL }?.toString().orEmpty()
                        if (raw.isNotBlank() && !raw.startsWith("=")) textCells += TextCell(raw, x, y, w, hh, style)
                    }
                }
            }
            y += h
        }
        // Keep workbook cell fills behind embedded signature/stamp images. Repaint
        // cell borders above images, then text, so neither images nor borders hide values.
        drawSideImages(canvas, grid, colKeys, rowKeys, colWidths, rowHeights, totalWidth, totalHeight)
        for (cellIndex in 0 until cells.length()) {
            val cell = cells.getJSONObject(cellIndex)
            val rowIndex = cell.optInt("r")
            val colIndex = cell.optInt("c")
            val key = "$rowIndex,$colIndex"
            if (key in mergedCovered) continue
            val merge = mergedStarts[key]
            val endRow = merge?.optInt("r2", rowIndex) ?: rowIndex
            val endCol = merge?.optInt("c2", colIndex) ?: colIndex
            val styleId = cell.optInt("styleId", 0)
            val style = styles.optJSONObject(styleId) ?: JSONObject()
            val spanColumns = colKeys.filter { key ->
                val index = colKeyToIndex(key)
                index >= colIndex && index <= endCol
            }
            val w = spanColumns.sumOf { colWidths[it]!!.toDouble() }.toFloat()
            val rightToLeft = template.optBoolean("rightToLeft", true)
            val x = if (rightToLeft) totalWidth - colKeys.filter { colKeyToIndex(it) <= endCol }.sumOf { colWidths[it]!!.toDouble() }.toFloat()
                else colKeys.filter { colKeyToIndex(it) < colIndex }.sumOf { colWidths[it]!!.toDouble() }.toFloat()
            val y = rowKeys.takeWhile { (it.toIntOrNull() ?: 0) < rowIndex }.sumOf { rowHeights[it]!!.toDouble() }.toFloat()
            val heightTotal = (rowIndex..endRow).fold(0.0) { total, row ->
                total + (rowHeights[rowKeys.getOrNull(row)]?.toDouble() ?: 0.0)
            }
            val h = heightTotal.toFloat()
            drawCellBorders(canvas, x, y, w, h, style, borders)
        }
        textCells.forEach { cell ->
            drawCellText(canvas, cell.text, cell.x, cell.y, cell.width, cell.height, cell.style, fonts, alignments)
        }
        } finally {
            canvas.restore()
        }
    }

    private fun fieldOverrides(template: JSONObject, item: AggregateReceiptItem, date: String): Map<String, String> {
        val out = HashMap<String, String>()
        val grid = template.getJSONObject("grid")
        val cells = grid.getJSONArray("cells")
        val editable = template.optJSONObject("editableFields") ?: JSONObject()
        fun declared(name: String): MutableList<String> {
            val a = editable.optJSONArray(name) ?: return mutableListOf()
            return (0 until a.length()).mapNotNull { a.optJSONObject(it)?.optString("address")?.takeIf(String::isNotBlank) }.toMutableList()
        }
        fun address(cell: JSONObject): String = cell.optString("addr")
        fun addIfMissing(list: MutableList<String>, candidate: String?) {
            if (!candidate.isNullOrBlank() && candidate !in list) list += candidate
        }
        val tenantAddresses = declared("tenant")
        val amountAddresses = declared("amount")
        val wordsAddresses = declared("amountInWords")
        val dateAddresses = declared("dateLiterals")
        val descriptionAddresses = declared("description")
        val locationAddresses = declared("location")
        require(tenantAddresses.size == 1) { "موضع اسم المستأجر غير محدد بدقة في القالب ${item.templateId}" }
        require(amountAddresses.size == 1) { "موضع المبلغ غير محدد بدقة في القالب ${item.templateId}" }
        require(descriptionAddresses.size == 1) { "موضع وصف العين غير محدد بدقة في القالب ${item.templateId}" }
        require(locationAddresses.size == 1) { "موضع العنوان غير محدد بدقة في القالب ${item.templateId}" }
        (tenantAddresses + amountAddresses + descriptionAddresses + locationAddresses + dateAddresses).forEach { addr ->
            require(findCell(template, addr) != null) { "خلية $addr غير موجودة في فهرس القالب ${item.templateId}" }
        }

        // Recover only the amount/tenant/amount-words positions when workbook metadata
        // is incomplete. Date positions remain explicit: a period-start date can be
        // historical and must never be replaced just because it looks like a date.
        var amountReference: String? = null
        var wordsRow: Int? = null
        for (i in 0 until cells.length()) {
            val cell = cells.getJSONObject(i)
            val value = cell.opt("value")?.toString().orEmpty()
            val addr = address(cell)
            if (value.contains("وصلنا من")) addIfMissing(tenantAddresses, addr)
            if (value.startsWith("=Monitize(", ignoreCase = true)) {
                addIfMissing(wordsAddresses, addr)
                Regex("=Monitize\\(([A-Z]+[0-9]+)\\)", RegexOption.IGNORE_CASE).find(value)?.groupValues?.getOrNull(1)?.let { amountReference = it }
            }
            if (value.contains("المبلغ المرقوم")) wordsRow = cell.optInt("r")
        }
        if (amountReference != null) addIfMissing(amountAddresses, amountReference)
        // One original form intentionally has a blank tenant cell; its styled cell
        // immediately precedes the amount-in-words label and remains editable.
        if (tenantAddresses.isEmpty()) wordsRow?.let { row ->
            for (i in 0 until cells.length()) {
                val cell = cells.getJSONObject(i)
                if (cell.optInt("r") == row - 1 && cell.optInt("c") == 1) addIfMissing(tenantAddresses, address(cell))
            }
        }
        // Older forms contain literal amount-in-words cells instead of Monitize formulas.
        wordsRow?.let { row ->
            for (i in 0 until cells.length()) {
                val cell = cells.getJSONObject(i)
                if (cell.optInt("r") == row && cell.optInt("c") == 2) addIfMissing(wordsAddresses, address(cell))
            }
        }

        tenantAddresses.forEach { out[it] = " وصلنا من  : -  ${item.tenant}" }
        amountAddresses.forEach { addr ->
            val amountCell = findCell(template, addr)
            val styleId = amountCell?.optInt("styleId", 0) ?: 0
            val numberFormatId = catalog.getJSONArray("styles").optJSONObject(styleId)?.optInt("numFmtId", 0) ?: 0
            out[addr] = formatMoney(item.amount, numberFormatId)
        }
        wordsAddresses.forEach { out[it] = VbaMonitize.amountWords(item.amount) }
        // Only catalog-declared issue-date cells are editable. This deliberately
        // preserves period-start dates and any dates embedded in legal text.
        dateAddresses.forEach { addr ->
            val old = findCellValue(template, addr)
            require(old.contains("2026/11/01")) { "تاريخ القالب غير متوقع في الخلية $addr (${item.templateId})" }
            out[addr] = old.replace("2026/11/01", date)
        }

        // Optional property details use explicit per-template cell addresses from the
        // catalog. Never infer a legal/property field by fuzzy text search at runtime.
        descriptionAddresses.forEach { addr ->
            val original = findCellValue(template, addr)
            val supplied = listOf(item.description, item.property).filter(String::isNotBlank).joinToString(" / ")
            if (supplied.isNotBlank()) {
                val rentLabelEnd = original.indexOf("إيجار") + "إيجار".length
                val numberLabelStart = original.indexOf("رقم", rentLabelEnd)
                require(rentLabelEnd >= "إيجار".length && numberLabelStart > rentLabelEnd) {
                    "صيغة وصف العين غير متوافقة مع القالب ${item.templateId}"
                }
                out[addr] = original.substring(0, rentLabelEnd) + " : -  " + supplied + "   " + original.substring(numberLabelStart)
            }
        }
        locationAddresses.forEach { addr ->
            var value = findCellValue(template, addr)
            if (item.unitCode.isNotBlank()) {
                val numberStart = value.indexOf("رقم")
                val streetStart = value.indexOf("شارع", numberStart.coerceAtLeast(0))
                require(numberStart >= 0 && streetStart > numberStart) {
                    "صيغة رقم الوحدة غير متوافقة مع القالب ${item.templateId}"
                }
                value = value.substring(0, numberStart + "رقم".length) + " : -  ${item.unitCode}   " + value.substring(streetStart)
            }
            if (item.address.isNotBlank()) {
                val streetStart = value.indexOf("شارع")
                require(streetStart >= 0) { "موضع الشارع غير موجود في القالب ${item.templateId}" }
                value = value.substring(0, streetStart + "شارع".length) + " : -  ${item.address}"
            }
            if (value != findCellValue(template, addr)) out[addr] = value
        }
        return out
    }

    private fun findCell(template: JSONObject, address: String): JSONObject? {
        val cells = template.getJSONObject("grid").getJSONArray("cells")
        for (i in 0 until cells.length()) { val cell = cells.getJSONObject(i); if (cell.optString("addr") == address) return cell }
        return null
    }

    private fun findCellValue(template: JSONObject, address: String): String =
        findCell(template, address)?.opt("value")?.toString().orEmpty()

    private fun drawCellBackground(c: Canvas, x: Float, y: Float, w: Float, h: Float, style: JSONObject, fills: org.json.JSONArray) {
        val fill = fills.optJSONObject(style.optInt("fillId")) ?: JSONObject()
        val color = fill.optJSONObject("fgColor")?.optString("rgb").orEmpty()
        if (fill.optString("fillType") == "solid" && color.length >= 6) {
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = parseColor(color) }
            c.drawRect(x, y, x + w, y + h, p)
        }
    }

    private fun drawCellBorders(c: Canvas, x: Float, y: Float, w: Float, h: Float, style: JSONObject, borders: org.json.JSONArray) {
        val border = borders.optJSONObject(style.optInt("borderId")) ?: return
        listOf("left" to (x to y), "right" to (x + w to y), "top" to (x to y), "bottom" to (x to y + h)).forEach { (side, point) ->
            val spec = border.optJSONObject(side) ?: return@forEach
            val kind = spec.optString("style")
            if (kind.isBlank() || kind == "null") return@forEach
            val borderColor = spec.optJSONObject("color")?.optString("rgb").orEmpty()
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = if (borderColor.length >= 6) parseColor(borderColor) else android.graphics.Color.BLACK
                this.style = Paint.Style.STROKE
                strokeWidth = when {
                    kind.contains("thick") -> 1.6f
                    kind.contains("medium") -> 1.0f
                    kind == "hair" -> .25f
                    else -> .45f
                }
            }
            if (kind == "double") {
                p.strokeWidth = .35f
                when (side) {
                    "left" -> { c.drawLine(x + .35f, y, x + .35f, y + h, p); c.drawLine(x + 1.1f, y, x + 1.1f, y + h, p) }
                    "right" -> { c.drawLine(x + w - .35f, y, x + w - .35f, y + h, p); c.drawLine(x + w - 1.1f, y, x + w - 1.1f, y + h, p) }
                    "top" -> { c.drawLine(x, y + .35f, x + w, y + .35f, p); c.drawLine(x, y + 1.1f, x + w, y + 1.1f, p) }
                    "bottom" -> { c.drawLine(x, y + h - .35f, x + w, y + h - .35f, p); c.drawLine(x, y + h - 1.1f, x + w, y + h - 1.1f, p) }
                }
            } else when (side) {
                "left" -> c.drawLine(point.first, y, point.first, y + h, p)
                "right" -> c.drawLine(point.first, y, point.first, y + h, p)
                "top" -> c.drawLine(x, point.second, x + w, point.second, p)
                "bottom" -> c.drawLine(x, point.second, x + w, point.second, p)
            }
        }
    }

    private fun drawCellText(c: Canvas, text: String, x: Float, y: Float, w: Float, h: Float, style: JSONObject, fonts: org.json.JSONArray, alignments: org.json.JSONArray) {
        val font = fonts.optJSONObject(style.optInt("fontId")) ?: JSONObject()
        val alignment = alignments.optJSONObject(style.optInt("alignmentId")) ?: JSONObject()
        val size = font.optDouble("size", 11.0).toFloat().coerceIn(6f, 28f)
        val bold = font.optBoolean("bold")
        val color = font.optJSONObject("color")?.optString("rgb").orEmpty()
        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = size
            this.color = if (color.length >= 6) parseColor(color) else android.graphics.Color.BLACK
            val styleBits = (if (bold) Typeface.BOLD else Typeface.NORMAL) or
                (if (font.optBoolean("italic")) Typeface.ITALIC else Typeface.NORMAL)
            val sourceFont = font.optString("name").lowercase(Locale.ROOT)
            // Keep serif families serif; use the bundled Arabic-capable Noto family
            // for workbook sans families whose Windows fonts are not installed on Android.
            // This avoids silently substituting a generic device font with unstable metrics.
            val baseTypeface = when {
                sourceFont.contains("times new roman") -> Typeface.SERIF
                // ae_AlMohanad is not bundled or licensed as an app asset. Use the
                // same bundled Arabic-capable Noto family as the other missing
                // workbook sans fonts instead of a device-dependent generic face.
                sourceFont.contains("ae_almohanad") -> ResourcesCompat.getFont(context, R.font.noto_sans_arabic_regular) ?: Typeface.DEFAULT
                sourceFont.contains("lohit devanagari") -> ResourcesCompat.getFont(context, R.font.noto_sans_arabic_regular) ?: Typeface.DEFAULT
                sourceFont.contains("arial") || sourceFont.contains("calibri") -> ResourcesCompat.getFont(context, R.font.noto_sans_arabic_regular) ?: Typeface.DEFAULT
                else -> ResourcesCompat.getFont(context, R.font.noto_sans_arabic_regular) ?: Typeface.DEFAULT
            }
            typeface = Typeface.create(baseTypeface, styleBits)
        }
        val displayText = ReceiptDateFormat.toArabicDigits(text)
        val horizontal = alignment.optString("horizontal", "general")
        // Numeric values in Arabic receipts must retain left-to-right digit order.
        // Applying RTL to Arabic-Indic digits plus a decimal separator can shift the
        // visual run outside a centered Excel amount cell on Android's StaticLayout.
        val numericOnly = displayText.isNotEmpty() && displayText.all {
            it.isDigit() || it in ".٫٬,-+() "
        }
        val isRtl = !numericOnly && (alignment.optInt("readingOrder") == 2 || displayText.any { it in '\u0600'..'\u06ff' })
        val align = when (horizontal) {
            "center" -> Layout.Alignment.ALIGN_CENTER
            "left" -> if (isRtl) Layout.Alignment.ALIGN_OPPOSITE else Layout.Alignment.ALIGN_NORMAL
            "right" -> if (isRtl) Layout.Alignment.ALIGN_NORMAL else Layout.Alignment.ALIGN_OPPOSITE
            else -> if (isRtl) Layout.Alignment.ALIGN_NORMAL else Layout.Alignment.ALIGN_OPPOSITE
        }
        val direction = if (isRtl) TextDirectionHeuristics.RTL else TextDirectionHeuristics.LTR
        val wraps = alignment.optBoolean("wrapText")
        // Excel cells with wrapText=false remain on one line. Android's StaticLayout
        // otherwise wraps long Arabic tenant names and can make them collide with the
        // next printed row. Shrink only these single-line cells, preserving all text.
        if (!wraps) {
            val available = (w - 3f).coerceAtLeast(8f)
            while (paint.measureText(displayText) > available && paint.textSize > 8f) {
                paint.textSize = (paint.textSize - 0.5f).coerceAtLeast(8f)
            }
        }
        val effectiveSize = paint.textSize
        val maxLines = if (wraps) (h / (effectiveSize * 1.15f)).toInt().coerceAtLeast(1).coerceAtMost(24) else 1
        val layout = StaticLayout.Builder.obtain(displayText, 0, displayText.length, paint, w.toInt().coerceAtLeast(8))
            .setAlignment(align).setTextDirection(direction).setIncludePad(false)
            .setMaxLines(maxLines)
            .setEllipsize(if (wraps) null else TextUtils.TruncateAt.END)
            .setBreakStrategy(Layout.BREAK_STRATEGY_HIGH_QUALITY)
            .setHyphenationFrequency(Layout.HYPHENATION_FREQUENCY_NONE)
            .build()
        val vertical = alignment.optString("vertical", "center").lowercase(Locale.ROOT)
        val textY = when (vertical) {
            "top" -> y + 1f
            "bottom" -> y + max(0f, h - layout.height - 1f)
            else -> y + max(0f, (h - layout.height) / 2f)
        }
        c.save()
        try {
            c.clipRect(x, y, x + w, y + h)
            c.translate(x + 1.5f, textY)
            layout.draw(c)
        } finally {
            c.restore()
        }
    }

    private fun drawSideImages(c: Canvas, grid: JSONObject, colKeys: List<String>, rowKeys: List<String>, widths: Map<String, Float>, heights: Map<String, Float>, totalWidth: Float, totalHeight: Float) {
        val images = grid.optJSONArray("images") ?: return
        fun columnStart(index: Int): Float = colKeys.take(index.coerceIn(0, colKeys.size)).sumOf { widths[it]!!.toDouble() }.toFloat()
        fun rowStart(index: Int): Float = rowKeys.take(index.coerceIn(0, rowKeys.size)).sumOf { heights[it]!!.toDouble() }.toFloat()
        for (i in 0 until images.length()) {
            val img = images.getJSONObject(i)
            val file = img.optString("file")
            if (file.isBlank()) continue
            runCatching {
                    val bitmap = sideImage(file) ?: return@runCatching
                    val hasAnchor = img.has("fromColOffEmu") && img.has("toColOffEmu")
                    val anchorRect = if (hasAnchor) {
                        val rawLeft = columnStart(img.optInt("fromCol")) + img.optDouble("fromColOffEmu").toFloat() / 12700f
                        val top = rowStart(img.optInt("fromRow")) + img.optDouble("fromRowOffEmu").toFloat() / 12700f
                        val rawRight = columnStart(img.optInt("toCol")) + img.optDouble("toColOffEmu").toFloat() / 12700f
                        val bottom = rowStart(img.optInt("toRow")) + img.optDouble("toRowOffEmu").toFloat() / 12700f
                        if (grid.optBoolean("rightToLeft", true)) RectF(totalWidth - rawRight, top, totalWidth - rawLeft, bottom)
                        else RectF(rawLeft, top, rawRight, bottom)
                    } else {
                        val col = img.optInt("col")
                        val row = img.optInt("row")
                        val x = columnStart(col)
                        val y = rowStart(row)
                        val imageWidth = widths[colKeys.getOrNull(col)] ?: totalWidth * .12f
                        val left = if (grid.optBoolean("rightToLeft", true)) totalWidth - x - imageWidth else x
                        RectF(left, y, left + imageWidth, totalHeight)
                    }
                    // Some source pictures are nested inside a grouped Excel drawing.
                    // The outer two-cell anchor describes the whole group, not the
                    // picture itself. Scale the picture's inner transform into that
                    // anchor so the narrow signature strip is not stretched across
                    // the entire receipt width.
                    val group = img.optJSONObject("groupPictureTransform")
                    val rect = if (group != null && anchorRect.width() > 0f && anchorRect.height() > 0f) {
                        val groupWidth = group.optDouble("groupChildExtentXEmu").toFloat()
                        val groupHeight = group.optDouble("groupChildExtentYEmu").toFloat()
                        if (groupWidth > 0f && groupHeight > 0f) {
                            val scaleX = anchorRect.width() / groupWidth
                            val scaleY = anchorRect.height() / groupHeight
                            val left = anchorRect.left + (group.optDouble("pictureOffsetXEmu").toFloat() - group.optDouble("groupChildOffsetXEmu").toFloat()) * scaleX
                            val top = anchorRect.top + (group.optDouble("pictureOffsetYEmu").toFloat() - group.optDouble("groupChildOffsetYEmu").toFloat()) * scaleY
                            val width = group.optDouble("pictureExtentXEmu").toFloat() * scaleX
                            val height = group.optDouble("pictureExtentYEmu").toFloat() * scaleY
                            RectF(left, top, left + width, top + height)
                        } else anchorRect
                    } else anchorRect
                    if (rect.width() > 0f && rect.height() > 0f) {
                        c.drawBitmap(bitmap, null, rect, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
                    }
            }
        }
    }

    private fun colKeyToIndex(key: String): Int { var n = 0; key.forEach { n = n * 26 + (it.uppercaseChar() - 'A' + 1) }; return n - 1 }
    private fun parseColor(raw: String): Int = runCatching { android.graphics.Color.parseColor("#${raw.takeLast(6)}") }.getOrDefault(android.graphics.Color.BLACK)
    private fun formatMoney(value: Double, numberFormatId: Int): String {
        val decimals = when (numberFormatId) {
            0, 1 -> 0
            2, 4, 165 -> 2
            10, 166, 169 -> 1
            else -> 0
        }
        val pattern = "%.${decimals}f"
        return ReceiptDateFormat.toArabicDigits(String.format(Locale.US, pattern, value))
    }


}
