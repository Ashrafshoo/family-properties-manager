#!/usr/bin/env python3
from pathlib import Path
source = (Path(__file__).resolve().parents[1] / 'app/src/main/java/com/example/rentals/printing/CollectorSheetPdfExporter.kt').read_text(encoding='utf-8')
assert 'style = Paint.Style.STROKE' in source, 'cell border paint must be stroke-only so it cannot cover row text'
assert 'c.drawRect(left, y, x, y + rowH, linePaint)' in source
assert 'c.drawRect(left, top, x, top + rowH, linePaint)' in source
assert 'headerPaint' in source and 'drawRtl(c, value' in source
print('PASS: collector-sheet cell borders are stroke-only and cannot paint over header or row text')
