from pathlib import Path
root=Path(__file__).resolve().parents[1]
s=(root/'app/src/main/java/com/example/rentals/features/contracts/ContractsArchiveScreen.kt').read_text(encoding='utf-8')
checks={
 'camera capture supported':'ActivityResultContracts.TakePicture()' in s and 'تصوير صفحة العقد بالكاميرا' in s,
 'multiple file selection supported':'ActivityResultContracts.OpenMultipleDocuments()' in s,
 'file categories available':all(x in s for x in ['عقد أساسي','صفحة من العقد','ملحق عقد','تجديد عقد','إنذار / إخطار']),
 'attachment notes persisted':'attachmentNote' in s and 'attachmentCategory' in s and 'addAttachment(attachOwnerType,attachOwnerId,stored.uri,stored.displayName,stored.mimeType,note,attachmentCategory)' in s,
 'private app storage for camera':'attachments/archive/$attachOwnerType/$attachOwnerId' in s,
 'failed camera capture removes incomplete file':'file?.delete()' in s,
 'multiple attachment errors surfaced':'تعذر حفظ $errors ملف' in s,
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+': '+k)
if not all(checks.values()): raise SystemExit(1)
