from pathlib import Path
root=Path(__file__).resolve().parents[1]
s=(root/'app/src/main/java/com/example/rentals/data/RentalsDb.kt').read_text(encoding='utf-8')
checks={
 'lease edit reads prior unit and tenant snapshot':'SELECT unit_id,COALESCE(tenant_name_snapshot' in s,
 'unit change updates tenant snapshot':'if(changedUnit){' in s and 'v.put("tenant_name_snapshot",tenantSnapshot)' in s,
 'unit change updates tenant id':'if(tenantId==null)v.putNull("tenant_id") else v.put("tenant_id",tenantId)' in s,
 'lease update is transactional':'db.beginTransaction()' in s[s.index('if(id>0){',s.index('fun saveLease')):s.index('    @Synchronized fun attachments()')],
 'unit relink is audited':'نقل العقد إلى وحدة أخرى باختيار المستخدم' in s,
 'tenant snapshot change is audited':'تحديث اسم المستأجر التاريخي بعد تغيير الوحدة صراحةً' in s,
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+': '+k)
if not all(checks.values()): raise SystemExit(1)
