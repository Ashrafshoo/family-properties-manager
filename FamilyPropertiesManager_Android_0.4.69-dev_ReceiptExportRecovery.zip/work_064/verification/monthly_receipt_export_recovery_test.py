from pathlib import Path
import json
root=Path(__file__).resolve().parents[1]
db=(root/"app/src/main/java/com/example/rentals/data/RentalsDb.kt").read_text()
ui=(root/"app/src/main/java/com/example/rentals/features/printing/MonthlyCollectionScreen.kt").read_text()
renderer=(root/"app/src/main/java/com/example/rentals/printing/OriginalReceiptTemplateRenderer.kt").read_text()
catalog=json.loads((root/"app/src/main/assets/receipt_templates/receipt_template_catalog_v1.json").read_text())
assert 'if(existing==selectedUnitIds)' in db and 'return existingId' in db
assert 'oldBatchIds = batches.map { it.id }.toSet()' in ui
assert 'uniqueExactTemplateIdForTenant(receipt.tenant)' in ui
assert 'description="",address="",templateId=r.template' in ui
assert 'لم يتم إنشاء PDF: توجد إيصالات بلا قالب محدد' in ui
assert 'الدفعة ${b.id}: توجد قوالب غير محددة' in ui
assert 'هذه الدفعة لا تحتوي إيصالات؛ لم يتم فتح الحفظ.' in ui
assert 'fun uniqueExactTemplateIdForTenant(tenant: String): String?' in renderer
# Conservative exact matching must never silently choose between duplicate tenant templates.
keys={}
import re, unicodedata
def key(v):
    v=unicodedata.normalize('NFD',v)
    v=''.join(c for c in v if unicodedata.category(c)!='Mn')
    v=v.replace('ـ',' ').replace('أ','ا').replace('إ','ا').replace('آ','ا').replace('ى','ي').lower()
    v=re.sub(r'^(السيد|السادة|السيدة|مدام|م|ا)\s*/?\s*','',v)
    return re.sub(r'[^\w]','',v,flags=re.UNICODE)
for t in catalog['templates']:
    if t.get('monthlyEligible',True): keys.setdefault(key(t.get('tenant_text','')),[]).append(t['template_id'])
assert len(catalog['templates'])==88
assert any(len(v)>1 for k,v in keys.items() if k), 'test fixture should include ambiguous duplicate names'
print('PASS: duplicate-batch recovery, conservative template suggestions, and original receipt detail preservation')
