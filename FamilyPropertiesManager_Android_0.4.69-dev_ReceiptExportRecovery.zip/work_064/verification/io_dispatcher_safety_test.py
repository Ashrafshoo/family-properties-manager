from pathlib import Path

root = Path(__file__).resolve().parents[1]
settings = (root / "app/src/main/java/com/example/rentals/features/settings/SettingsScreen.kt").read_text()
monthly = (root / "app/src/main/java/com/example/rentals/features/printing/MonthlyCollectionScreen.kt").read_text()
finance = (root / "app/src/main/java/com/example/rentals/features/finance/FinanceScreen.kt").read_text()
main = (root / "app/src/main/java/com/example/rentals/MainActivity.kt").read_text()
workbook_export = (root / "app/src/main/java/com/example/rentals/io/WorkbookExporter.kt").read_text()

heavy_settings = [
    "WorkbookExporter.exportAll", "WorkbookImporter.preview", "WorkbookImporter.importAppend",
    "DatabasePdfExporter.exportReport", "XlsxManager.import", "DatabaseTransfer.export",
    "DatabaseTransfer.import", "BackupManager.create", "BackupManager.restore",
    "EncryptedBackup.create", "EncryptedBackup.restore",
]
for operation in heavy_settings:
    pos = settings.find(operation)
    assert pos >= 0, f"missing operation: {operation}"
    window = settings[max(0, pos - 500):pos + 250]
    assert "withContext(Dispatchers.IO)" in window, f"operation not dispatched to IO: {operation}"

for operation in ["CollectorSheetPdfExporter.export", "WorkbookExporter.exportRows"]:
    pos = monthly.find(operation)
    assert pos >= 0, f"missing monthly operation: {operation}"
    window = monthly[max(0, pos - 500):pos + 250]
    assert "withContext(Dispatchers.IO)" in window, f"monthly export not dispatched to IO: {operation}"

assert "zip.putNextEntry(ZipEntry(\"xl/worksheets/sheet${index+1}.xml\"))" in workbook_export
assert "writeRow(zip, rowNumber++, values)" in workbook_export
assert "versionCode = 92" in (root / "app/build.gradle.kts").read_text()
assert 'versionName = "0.4.68-dev"' in (root / "app/build.gradle.kts").read_text()
print("PASS: Initial unit loading, Finance reads/writes, Excel, PDF, database transfer, backup/restore, and monthly exports are dispatched off the UI thread.")
