from pathlib import Path
p = Path(__file__).resolve().parents[1] / '.github/workflows/android-build.yml'
s = p.read_text(encoding='utf-8')
assert "name: family-properties-manager-0.4.68-dev-debug" in s
for pattern in ("'**/*.json'", "'**/*.xlsx'", "'**/*.png'", "'**/*.webp'", "'**/*.ttf'"):
    assert pattern in s, f"workflow path filter missing {pattern}"
assert "./gradlew --no-daemon assembleDebug" in s
print('PASS: workflow tracks receipt-template assets and labels the 0.4.68-dev APK correctly')
