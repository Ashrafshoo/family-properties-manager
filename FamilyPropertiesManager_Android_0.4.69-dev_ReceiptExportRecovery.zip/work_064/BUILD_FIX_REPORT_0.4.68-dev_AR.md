# تقرير إصلاح البناء – 0.4.68-dev

## سبب الفشل السابق
كان `ContractsArchiveScreen` يمرر سبع معاملات إلى `AddContractAttachment` بينما كانت واجهة حالة الاستخدام تقبل خمسًا فقط، رغم أن `ContractRepository.addAttachment` يدعم الملاحظات والتصنيف كمعاملين اختياريين.

## الإصلاح
تم توسيع `AddContractAttachment.invoke` لقبول `notes` و`category` وتمريرهما إلى المستودع. بذلك تتطابق الشاشة وحالة الاستخدام والمستودع، وتحفظ بيانات التصنيف والملاحظة بدل إسقاطها.

## الإصدار
`0.4.68-dev` / `versionCode 92`، دون تغيير `applicationId` أو مخطط SQLite.

## حدود التحقق
يجب تشغيل اختبارات المصدر وبناء `assembleDebug` في GitHub Actions. لا يُعلن نجاح APK قبل ظهور نتيجة بناء ناجحة فعلية. لم يتم تعديل أو حذف `rentals_local.db`.
