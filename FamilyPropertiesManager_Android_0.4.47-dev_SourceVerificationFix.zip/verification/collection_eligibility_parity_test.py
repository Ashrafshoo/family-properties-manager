from pathlib import Path

root = Path(__file__).resolve().parents[1]
helper = (root / 'app/src/main/java/com/example/rentals/domain/collection/CollectionEligibility.kt').read_text(encoding='utf-8')
db = (root / 'app/src/main/java/com/example/rentals/data/RentalsDb.kt').read_text(encoding='utf-8')
ui = (root / 'app/src/main/java/com/example/rentals/features/printing/MonthlyCollectionScreen.kt').read_text(encoding='utf-8')

blocked = ['متوقف', 'مباع', 'مغلق', 'مستبعد', 'مكرر', 'غير محسومة', 'تغيير مستأجر']
for status in blocked:
    assert f'value.contains("{status}")' in helper, f'missing blocked status: {status}'
assert 'collectionIneligibilityReason(it.status)==null' in ui
assert 'collectionIneligibilityReason(it.status)!=null' in ui
assert 'collectionIneligibilityReason(unit.status)' in db
assert 'لم يتم إنشاء الدفعة. راجع الوحدات التالية ثم أعد الاختيار' in db
assert 'عرض السجلات وأسباب الاستبعاد' in ui
assert 'عدد الإيصالات الجاهزة' in ui
assert 'طباعة الإيصالات وحفظها PDF أو Excel' in ui
print('PASS: UI and SQLite share one eligibility rule')
print('PASS: stopped, sold, closed, excluded, duplicate, unresolved, and tenant-change statuses are consistently blocked')
print('PASS: detailed unit-level reasons are surfaced instead of a generic failure')
print('PASS: collection screen explains receipt actions and reports prepared receipt count')
