package com.example.rentals.features.printing

import android.print.PrintAttributes
import android.print.PrintManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.fragment.app.FragmentActivity
import com.example.rentals.domain.collection.MonthlyCollectionRepository
import com.example.rentals.domain.collection.PrepareMonthlyCollection
import com.example.rentals.domain.collection.collectionIneligibilityReason
import com.example.rentals.data.UnitRecord
import com.example.rentals.ui.UiSettings
import com.example.rentals.printing.ReceiptPrintAdapter
import com.example.rentals.printing.ReceiptPdfExporter
import com.example.rentals.printing.CollectorSheetPdfExporter
import com.example.rentals.ui.components.PremiumScreenHeader
import com.example.rentals.io.WorkbookExporter
import java.text.NumberFormat
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private fun formatCollectionMoney(value: Double): String =
    NumberFormat.getNumberInstance(Locale("ar", "EG")).format(value) + " ج.م"

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun MonthlyCollectionScreen(activity:FragmentActivity,repository:MonthlyCollectionRepository,units:List<UnitRecord>,settings:UiSettings){
    val prepareMonthlyCollection = remember(repository) { PrepareMonthlyCollection(repository) }
    var period by remember { mutableStateOf(java.time.YearMonth.now().toString()) }
    var issuedDate by remember { mutableStateOf(java.time.LocalDate.now().toString()) }
    var propertyFilter by remember { mutableStateOf("الكل") }
    var selected by remember { mutableStateOf<Set<Long>>(emptySet()) }
    var refresh by remember { mutableIntStateOf(0) }
    var activeBatch by remember { mutableStateOf<Long?>(null) }
    var message by remember { mutableStateOf("") }
    val properties=remember(units){units.map{it.property}.filter{it.isNotBlank()}.distinct().sorted()}
    val eligible=remember(units,propertyFilter){units.filter{collectionIneligibilityReason(it.status)==null&&(propertyFilter=="الكل"||it.property==propertyFilter)}}
    val excluded=remember(units,propertyFilter){units.filter{collectionIneligibilityReason(it.status)!=null&&(propertyFilter=="الكل"||it.property==propertyFilter)}}
    var showExcluded by remember { mutableStateOf(false) }
    LaunchedEffect(eligible) { selected = selected.intersect(eligible.map { it.id }.toSet()) }
    val batches=remember(refresh){repository.getBatches()}
    val batchReceipts=remember(activeBatch,refresh){activeBatch?.let{repository.getBatchReceipts(it)}?: emptyList()}
    val printManager=activity.getSystemService(android.content.Context.PRINT_SERVICE) as PrintManager
    val context= LocalContext.current
    val exportScope= rememberCoroutineScope()
    var exportBusy by remember { mutableStateOf(false) }
    var exportBatchId by remember{mutableLongStateOf(0L)}
    var editingCollectionItem by remember{mutableStateOf<Array<String>?>(null)}
    val exportCollectorPdf=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")){uri->if(uri!=null&&exportBatchId>0&&!exportBusy){exportBusy=true;val id=exportBatchId;exportScope.launch{try{withContext(Dispatchers.IO){val b=repository.getBatches().first{it.id==id};val rows=repository.getBatchItems(id).map{arrayOf(it[1],it[2],it[3],it[4],collectionStatusArabic(it[5]),it[6],it[8])};CollectorSheetPdfExporter.export(context.contentResolver,uri,b.title,rows)};message="تم إنشاء كشف المحصّل PDF للوحدات المحددة فقط."}catch(e:Exception){message="تعذر إنشاء PDF: ${e.message}"}finally{exportBusy=false}}}}
    val exportCollectorXlsx=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")){uri->if(uri!=null&&exportBatchId>0&&!exportBusy){exportBusy=true;val id=exportBatchId;exportScope.launch{try{withContext(Dispatchers.IO){val b=repository.getBatches().first{it.id==id};val data=repository.getBatchItems(id);WorkbookExporter.exportRows(context.contentResolver,uri,b.title,listOf("كود الوحدة","العقار","المستأجر","قيمة الإيجار","حالة التحصيل","المبلغ المحصل فعليًا","تاريخ التحصيل","ملاحظات"),data.map{listOf(it[1],it[2],it[3],it[4],collectionStatusArabic(it[5]),it[6],it[7],it[8])})};message="تم تصدير كشف المحصّل Excel للوحدات المحددة فقط."}catch(e:Exception){message="تعذر إنشاء Excel: ${e.message}"}finally{exportBusy=false}}}}
    val exportReceiptsPdf=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")){uri->if(uri!=null&&exportBatchId>0&&!exportBusy){exportBusy=true;val id=exportBatchId;exportScope.launch{try{withContext(Dispatchers.IO){val receipts=repository.getBatchReceipts(id);ReceiptPdfExporter.export(activity,context.contentResolver,uri,receipts,3,settings.marginMm,true)};message="تم إنشاء PDF يضم إيصالات الدفعة نفسها، ثلاثة إيصالات في صفحة A4."}catch(e:Exception){message="تعذر إنشاء PDF للإيصالات: ${e.message}"}finally{exportBusy=false}}}}
    val exportReceiptsXlsx=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")){uri->if(uri!=null&&exportBatchId>0&&!exportBusy){exportBusy=true;val id=exportBatchId;exportScope.launch{try{withContext(Dispatchers.IO){val receipts=repository.getBatchReceipts(id);WorkbookExporter.exportRows(context.contentResolver,uri,"إيصالات الدفعة",listOf("رقم الإيصال","كود الوحدة","العقار","المستأجر","المبلغ","تاريخ الإصدار","الفترة","الحالة"),receipts.map{listOf(it.receiptNo,it.unitCode,it.property,it.tenant,it.amount?.toString().orEmpty(),it.paidDate,it.period,it.status)})};message="تم تصدير بيانات إيصالات الدفعة إلى Excel."}catch(e:Exception){message="تعذر إنشاء Excel للإيصالات: ${e.message}"}finally{exportBusy=false}}}}
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal=12.dp, vertical=10.dp),verticalArrangement=Arrangement.spacedBy(9.dp)) {
        PremiumScreenHeader("التحصيل الشهري والإيصالات", "اختر الوحدات التي ستُسلّم للمحصّل. بعد إنشاء الدفعة ستظهر إجراءات طباعة الإيصالات وحفظها PDF أو Excel. إنشاء الدفعة لا يثبت السداد الفعلي ولا ينشئ قيدًا ماليًا.", Icons.Default.ReceiptLong)
        Text("مكان الإيصالات: تظهر أزرار الطباعة وPDF وExcel داخل بطاقة الدفعة بعد إنشائها، أو بعد الضغط على «عرض» بجوار دفعة محفوظة.",fontSize=12.sp,color=MaterialTheme.colorScheme.primary)
        OutlinedTextField(value=period,onValueChange={period=it},label={Text("شهر التحصيل بصيغة YYYY-MM")},singleLine=true,modifier=Modifier.fillMaxWidth())
        OutlinedTextField(value=issuedDate,onValueChange={issuedDate=it},label={Text("تاريخ إصدار الإيصالات YYYY-MM-DD")},singleLine=true,modifier=Modifier.fillMaxWidth())
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp),verticalAlignment=Alignment.CenterVertically){
            var expanded by remember{mutableStateOf(false)}
            Box(Modifier.weight(1f)){
                OutlinedButton(onClick={expanded=true},modifier=Modifier.fillMaxWidth()){Text("العقار: $propertyFilter")}
                DropdownMenu(expanded=expanded,onDismissRequest={expanded=false}){
                    DropdownMenuItem(text={Text("كل العقارات")},onClick={propertyFilter="الكل";selected=emptySet();expanded=false})
                    properties.forEach{p->DropdownMenuItem(text={Text(p)},onClick={propertyFilter=p;selected=emptySet();expanded=false})}
                }
            }
            Text("${selected.size} محدد",fontWeight=FontWeight.Bold)
        }
        Row(verticalAlignment=Alignment.CenterVertically){
            Checkbox(checked=eligible.isNotEmpty()&&eligible.all{it.id in selected},onCheckedChange={checked->selected=if(checked)eligible.map{it.id}.toSet() else selected-eligible.map{it.id}.toSet()})
            Text("تحديد كل الوحدات المؤهلة (${eligible.size})")
            Spacer(Modifier.weight(1f))
            TextButton(onClick={selected=emptySet()}){Text("إلغاء التحديد")}
        }
        if(excluded.isNotEmpty()) {
            Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.errorContainer)) {
                Column(Modifier.fillMaxWidth().padding(10.dp),verticalArrangement=Arrangement.spacedBy(4.dp)) {
                    Text("يوجد ${excluded.size} سجل غير مؤهل للتحصيل حاليًا؛ لن يختاره البرنامج ولن يمنع إنشاء دفعة للوحدات المؤهلة.",fontWeight=FontWeight.SemiBold,color=MaterialTheme.colorScheme.onErrorContainer,fontSize=12.sp)
                    TextButton(onClick={showExcluded=!showExcluded}){Text(if(showExcluded)"إخفاء تفاصيل السجلات" else "عرض السجلات وأسباب الاستبعاد")}
                    if(showExcluded) excluded.forEach { u ->
                        Text("${u.code} • ${u.tenant}: ${collectionIneligibilityReason(u.status)} (الحالة: ${u.status})",fontSize=11.sp,color=MaterialTheme.colorScheme.onErrorContainer)
                    }
                }
            }
        }
        eligible.forEach{u->
            Card(Modifier.fillMaxWidth(), shape=androidx.compose.foundation.shape.RoundedCornerShape(18.dp), border=androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha=.35f)), elevation=CardDefaults.cardElevation(defaultElevation=1.dp), colors=CardDefaults.cardColors(containerColor=if(u.id in selected)MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surface)){
                Row(Modifier.fillMaxWidth().padding(horizontal=8.dp,vertical=2.dp),verticalAlignment=Alignment.CenterVertically){
                    Checkbox(checked=u.id in selected,onCheckedChange={checked->selected=if(checked)selected+u.id else selected-u.id})
                    Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(1.dp)){
                        Text("${u.code} • ${u.tenant}",fontWeight=FontWeight.SemiBold)
                        Text("${u.property} • ${u.rent?.let{formatCollectionMoney(it)}?:"القيمة غير محددة"}",fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
        Button(onClick={
            try{val id=prepareMonthlyCollection(period,issuedDate,selected,if(propertyFilter=="الكل")"" else propertyFilter);activeBatch=id;refresh++;message="تم تجهيز دفعة التحصيل. استخدم أزرار طباعة الإيصالات أو PDF أو Excel التي ستظهر أسفل هذه الرسالة."}
            catch(e:Exception){message=e.message?:"تعذر تجهيز الدفعة"}
        },enabled=selected.isNotEmpty(),modifier=Modifier.fillMaxWidth()) { Text("إنشاء دفعة التحصيل وتجهيز الإيصالات (${selected.size})") }
        activeBatch?.let { quickBatchId ->
            val quickBatch=batches.firstOrNull{it.id==quickBatchId}
            Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.secondaryContainer)) {
                Column(Modifier.fillMaxWidth().padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                    Text("إجراءات الإيصالات للدفعة المحددة",fontWeight=FontWeight.Bold)
                    Text("عدد الإيصالات الجاهزة: ${batchReceipts.size}",fontSize=12.sp)
                    Text(quickBatch?.title.orEmpty(),fontSize=12.sp)
                    Button(onClick={val receipts=repository.getBatchReceipts(quickBatchId);if(receipts.isEmpty())message="لا توجد إيصالات للطباعة في هذه الدفعة" else printManager.print("إيصالات_${quickBatch?.period?:""}",ReceiptPrintAdapter(activity,receipts,3,settings.marginMm,true),PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).setResolution(android.print.PrintAttributes.Resolution("rentals","طباعة",300,300)).setMinMargins(PrintAttributes.Margins.NO_MARGINS).build())},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.Print,null);Spacer(Modifier.width(6.dp));Text("طباعة الإيصالات — 3 في A4")}
                    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(enabled=!exportBusy,onClick={exportBatchId=quickBatchId;exportReceiptsPdf.launch("إيصالات_${quickBatch?.period?:"الدفعة"}.pdf")},modifier=Modifier.weight(1f)){Text("حفظ PDF")}
                        OutlinedButton(enabled=!exportBusy,onClick={exportBatchId=quickBatchId;exportReceiptsXlsx.launch("إيصالات_${quickBatch?.period?:"الدفعة"}.xlsx")},modifier=Modifier.weight(1f)){Text("تصدير Excel")}
                    }
                }
            }
        }
        if(message.isNotBlank())Text(message,color=MaterialTheme.colorScheme.primary,fontSize=12.sp)
        HorizontalDivider()
        Text("دفعات التحصيل المحفوظة",fontWeight=FontWeight.Bold)
        batches.forEach{b->
            Card(Modifier.fillMaxWidth()){
                Row(Modifier.fillMaxWidth().padding(10.dp),verticalAlignment=Alignment.CenterVertically){
                    Column(Modifier.weight(1f)){
                        Text(b.title,fontWeight=FontWeight.SemiBold)
                        Text("${b.itemCount} وحدة • ${if(b.propertyFilter.isBlank())"كل العقارات" else b.propertyFilter}",fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    TextButton(onClick={activeBatch=b.id;refresh++}){Text("عرض")}
                    IconButton(onClick={
                        val rs=repository.getBatchReceipts(b.id)
                        if(rs.isNotEmpty())printManager.print("إيصالات_${b.period}",ReceiptPrintAdapter(activity,rs,3,settings.marginMm,true),PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).setResolution(android.print.PrintAttributes.Resolution("rentals","طباعة",300,300)).setMinMargins(PrintAttributes.Margins.NO_MARGINS).build())
                    }){Icon(Icons.Default.Print,"طباعة الإيصالات")}
                }
            }
        }
        activeBatch?.let{batchId->
            val b=batches.firstOrNull{it.id==batchId}
            HorizontalDivider()
            Text(b?.title?:"دفعة التحصيل",fontWeight=FontWeight.Bold)
            Text("كشف المحصّل يضم عناصر هذه الدفعة المختارة فقط، ولا يشمل الوحدات غير المختارة.",fontSize=12.sp)
            repository.getBatchItems(batchId).forEach{row->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.fillMaxWidth().padding(10.dp),verticalArrangement=Arrangement.spacedBy(4.dp)) {
                        Text("${row[1]} • ${row[3]}",fontWeight=FontWeight.SemiBold)
                        Text("${row[2]} • الإيجار: ${row[4].ifBlank{"غير محدد"}} جنيه",fontSize=12.sp)
                        Text("الحالة: ${collectionStatusArabic(row[5])} • المحصل فعليًا: ${row[6].ifBlank{"—"}} جنيه",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
                        if(row[8].isNotBlank()) Text("ملاحظة: ${row[8]}",fontSize=12.sp)
                        TextButton(onClick={editingCollectionItem=row}){Text("تسجيل / تعديل نتيجة مرور المحصّل")}
                    }
                }
            }
            OutlinedButton(onClick={
                val rs=repository.getBatchReceipts(batchId)
                if(rs.isNotEmpty())printManager.print("إيصالات_${b?.period?:""}",ReceiptPrintAdapter(activity,rs,3,settings.marginMm,true),PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).setResolution(android.print.PrintAttributes.Resolution("rentals","طباعة",300,300)).setMinMargins(PrintAttributes.Margins.NO_MARGINS).build())
            },modifier=Modifier.fillMaxWidth()){Text("طباعة إيصالات هذه الدفعة – 3 في A4")}
            Text("تصدير إيصالات الإيجار (مستند مستقل عن كشف المحصّل)",fontWeight=FontWeight.SemiBold)
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
                OutlinedButton(enabled=!exportBusy,onClick={exportBatchId=batchId;exportReceiptsPdf.launch("إيصالات_${b?.period?:"الدفعة"}.pdf")},modifier=Modifier.weight(1f)){Text("إيصالات PDF")}
                OutlinedButton(enabled=!exportBusy,onClick={exportBatchId=batchId;exportReceiptsXlsx.launch("بيانات_الإيصالات_${b?.period?:"الدفعة"}.xlsx")},modifier=Modifier.weight(1f)){Text("إيصالات Excel")}
            }
            Text("كشف المحصّل (بيانات المرور والتحصيل الفعلي)",fontWeight=FontWeight.SemiBold)
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
                OutlinedButton(enabled=!exportBusy,onClick={exportBatchId=batchId;exportCollectorPdf.launch("${b?.title?:"كشف_التحصيل"}.pdf")},modifier=Modifier.weight(1f)){Text("كشف PDF")}
                OutlinedButton(enabled=!exportBusy,onClick={exportBatchId=batchId;exportCollectorXlsx.launch("${b?.title?:"كشف_التحصيل"}.xlsx")},modifier=Modifier.weight(1f)){Text("كشف Excel")}
            }
        }
    }
    editingCollectionItem?.let { row ->
        var status by remember(row[0]) { mutableStateOf(row[5].ifBlank { "not_recorded" }) }
        var amount by remember(row[0]) { mutableStateOf(row[6]) }
        var date by remember(row[0]) { mutableStateOf(row[7].ifBlank { java.time.LocalDate.now().toString() }) }
        var notes by remember(row[0]) { mutableStateOf(row[8]) }
        var statusMenu by remember { mutableStateOf(false) }
        AlertDialog(onDismissRequest={editingCollectionItem=null},title={Text("نتيجة التحصيل — ${row[1]}")},text={
            Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
                Text("${row[3]} • ${row[2]}")
                Box { OutlinedButton(onClick={statusMenu=true},modifier=Modifier.fillMaxWidth()){Text("الحالة: ${collectionStatusArabic(status)}")};DropdownMenu(expanded=statusMenu,onDismissRequest={statusMenu=false}){listOf("not_recorded","paid","partial","unpaid","unreachable").forEach{v->DropdownMenuItem(text={Text(collectionStatusArabic(v))},onClick={status=v;statusMenu=false})}} }
                OutlinedTextField(amount,{amount=it},label={Text("المبلغ المحصل فعليًا (جنيه)")},singleLine=true,modifier=Modifier.fillMaxWidth())
                OutlinedTextField(date,{date=it},label={Text("تاريخ المرور YYYY-MM-DD")},singleLine=true,modifier=Modifier.fillMaxWidth())
                OutlinedTextField(notes,{notes=it},label={Text("ملاحظات المحصّل")},minLines=2,modifier=Modifier.fillMaxWidth())
                Text("تسجيل النتيجة لا ينشئ إيصال سداد أو قيدًا ماليًا تلقائيًا.",fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },confirmButton={TextButton(onClick={try{val value=amount.trim().takeIf{it.isNotEmpty()}?.toDouble();repository.recordCollectorResult(row[0].toLong(),status,value,date.trim(),notes.trim());message="تم حفظ نتيجة مرور المحصّل دون إنشاء قيد مالي.";refresh++}catch(e:Exception){message=e.message?:"تعذر حفظ النتيجة"};editingCollectionItem=null}){Text("حفظ النتيجة")}},dismissButton={TextButton(onClick={editingCollectionItem=null}){Text("إلغاء")}})
    }
}

private fun collectionStatusArabic(status:String):String = when(status){"not_recorded"->"لم تسجل بعد";"paid"->"تم التحصيل";"partial"->"تحصيل جزئي";"unpaid"->"لم يتم التحصيل";"unreachable"->"تعذر الوصول";else->status}

