package com.example.rentals.features.settings

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.DisposableEffect
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.fragment.app.FragmentActivity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import android.print.PrintAttributes
import android.print.PrintManager
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import android.provider.OpenableColumns
import java.io.File
import java.util.UUID
import com.example.rentals.backup.BackupManager
import com.example.rentals.backup.DatabaseTransfer
import com.example.rentals.backup.EncryptedBackup
import com.example.rentals.backup.RecoveryInspector
import com.example.rentals.backup.RecoveryReport
import com.example.rentals.data.RentalsDb
import com.example.rentals.data.LegacyUnitReviewAnalyzer
import com.example.rentals.data.LegacyReceiptMatchAnalyzer
import com.example.rentals.data.UnitRecord
import com.example.rentals.data.ReceiptRecord
import com.example.rentals.data.PropertyRecord
import com.example.rentals.data.TenantRecord
import com.example.rentals.io.XlsxManager
import com.example.rentals.io.WorkbookExporter
import com.example.rentals.io.WorkbookImporter
import com.example.rentals.io.ReviewedRentalsWorkbookImporter
import com.example.rentals.printing.DatabasePdfExporter
import com.example.rentals.printing.ReceiptPrintAdapter
import com.example.rentals.security.AppSecurity
import com.example.rentals.ui.SettingsStore
import com.example.rentals.ui.components.AppField
import com.example.rentals.ui.components.MetricCard
import com.example.rentals.ui.components.SettingSwitchRow
import com.example.rentals.ui.components.PremiumScreenHeader
import com.example.rentals.navigation.AppTab
import com.example.rentals.design.appColorScheme
import com.example.rentals.design.appTypography
import com.example.rentals.ui.UiSettings
import java.text.NumberFormat
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable fun SettingsScreen(activity:FragmentActivity,db:RentalsDb,s:UiSettings,onChange:(UiSettings)->Unit,onRefresh:()->Unit,onImportComplete:(String)->Unit,setExternalPickerInProgress:(Boolean)->Unit){val ctx= LocalContext.current;val security= remember{AppSecurity(ctx)};var bio by remember{mutableStateOf(security.biometricEnabled() && security.biometricAvailable(ctx))};var includeDb by remember{mutableStateOf(true)};var includeFiles by remember{mutableStateOf(true)};var restoreDb by remember{mutableStateOf(true)};var restoreFiles by remember{mutableStateOf(true)};var msg by remember{mutableStateOf("")};var changePin by remember{mutableStateOf(false)};var editShares by remember{mutableStateOf(false)};var showRecoveryRecords by remember{mutableStateOf(false)};var confirmRawImport by remember{mutableStateOf(false)};var backupPasswordDialog by remember{mutableStateOf(false)};var restorePasswordDialog by remember{mutableStateOf(false)};var backupPassword by remember{mutableStateOf("")};var restorePassword by remember{mutableStateOf("")};var recoveryReport by remember{mutableStateOf<RecoveryReport?>(null)};var recoveryBusy by remember{mutableStateOf(false)};var pendingImport by remember{mutableStateOf<List<UnitRecord>?>(null)};var pendingWorkbookUri by remember{mutableStateOf<Uri?>(null)};var pendingWorkbookPreview by remember{mutableStateOf<WorkbookImporter.Preview?>(null)};var pendingQ022Uri by remember{mutableStateOf<Uri?>(null)};var pendingQ022Preview by remember{mutableStateOf<ReviewedRentalsWorkbookImporter.Preview?>(null)};var q022Busy by remember{mutableStateOf(false)};val importScope= rememberCoroutineScope();var selectedPdfReport by remember{mutableStateOf("units")};var reportPeriod by remember{mutableStateOf("")};var reportHeirName by remember{mutableStateOf("")}
 val exportExcel=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")){uri->if(uri!=null&&!recoveryBusy){recoveryBusy=true;importScope.launch{try{withContext(Dispatchers.IO){WorkbookExporter.exportAll(ctx.contentResolver,uri,db.readableDatabase)};msg="تم تصدير جداول قاعدة البيانات إلى Excel في أوراق منفصلة";val send=Intent(Intent.ACTION_SEND).apply{type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";putExtra(Intent.EXTRA_STREAM,uri);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)};ctx.startActivity(Intent.createChooser(send,"مشاركة ملف Excel"))}catch(e:Exception){msg="فشل التصدير: ${e.message}"}finally{recoveryBusy=false}}}}
 val importAllExcel=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->if(uri!=null&&!recoveryBusy){recoveryBusy=true;importScope.launch{try{val p=withContext(Dispatchers.IO){WorkbookImporter.preview(ctx.contentResolver,uri,db.readableDatabase)};pendingWorkbookUri=uri;pendingWorkbookPreview=p;msg="تم تحليل ملف Excel وتجهيز ملخص الاستيراد"}catch(e:Exception){msg="تعذر تحليل ملف Excel: ${e.message}"}finally{recoveryBusy=false}}}}
 val importQ022=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->setExternalPickerInProgress(false);if(uri!=null){q022Busy=true;importScope.launch{try{val p=withContext(Dispatchers.IO){ReviewedRentalsWorkbookImporter.preview(ctx.contentResolver,uri)};pendingQ022Uri=uri;pendingQ022Preview=p;msg="تم التعرف على ملف Q022 وتجهيز ملخص الاستيراد"}catch(e:Exception){msg="تعذر قراءة ملف Q022: ${e.message}"}finally{q022Busy=false}}}}
 val exportPdf=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")){uri->if(uri!=null&&!recoveryBusy){recoveryBusy=true;importScope.launch{try{withContext(Dispatchers.IO){DatabasePdfExporter.exportReport(ctx.contentResolver,uri,db.readableDatabase,selectedPdfReport,reportPeriod,reportHeirName)};msg="تم إنشاء تقرير PDF متخصص"}catch(e:Exception){msg="فشل إنشاء PDF: ${e.message}"}finally{recoveryBusy=false}}}}
 val importExcel=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->if(uri!=null&&!recoveryBusy){recoveryBusy=true;importScope.launch{try{val list=withContext(Dispatchers.IO){XlsxManager.import(ctx.contentResolver,uri)};pendingImport=list;msg="تمت قراءة ${list.size} وحدة. راجع الملخص قبل اعتماد الاستيراد."}catch(e:Exception){msg="تعذر الاستيراد: ${e.message}"}finally{recoveryBusy=false}}}}
 val exportDb=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.sqlite3")){uri->if(uri!=null&&!recoveryBusy){recoveryBusy=true;importScope.launch{try{withContext(Dispatchers.IO){DatabaseTransfer.export(ctx,uri)};msg="تم تصدير قاعدة البيانات بصيغة SQLite"}catch(e:Exception){msg="فشل تصدير قاعدة البيانات: ${e.message}"}finally{recoveryBusy=false}}}}
 val importDb=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->if(uri!=null&&!recoveryBusy){recoveryBusy=true;importScope.launch{try{withContext(Dispatchers.IO){DatabaseTransfer.import(ctx,uri)};msg="تم استيراد قاعدة البيانات. أعد فتح التطبيق لتحديث جميع الشاشات.";onRefresh()}catch(e:Exception){msg="رفض استيراد قاعدة البيانات: ${e.message}"}finally{recoveryBusy=false}}}}
 val backup=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")){uri->if(uri!=null&&!recoveryBusy){recoveryBusy=true;importScope.launch{try{withContext(Dispatchers.IO){BackupManager.create(ctx,uri,includeDb,includeFiles)};msg="تم إنشاء النسخة الاحتياطية"}catch(e:Exception){msg="فشل النسخ: ${e.message}"}finally{recoveryBusy=false}}}}
 val encryptedBackup=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")){uri->if(uri!=null&&!recoveryBusy){recoveryBusy=true;val password=backupPassword;importScope.launch{try{withContext(Dispatchers.IO){EncryptedBackup.create(ctx,uri,includeDb,includeFiles,password)};msg="تم إنشاء نسخة احتياطية مشفرة؛ احتفظ بكلمة المرور";backupPassword=""}catch(e:Exception){msg="فشل إنشاء النسخة المشفرة: ${e.message}"}finally{recoveryBusy=false}}}}
 val encryptedRestore=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->if(uri!=null&&!recoveryBusy){recoveryBusy=true;val password=restorePassword;importScope.launch{try{withContext(Dispatchers.IO){EncryptedBackup.restore(ctx,uri,restoreDb,restoreFiles,password)};msg="تمت استعادة النسخة المشفرة؛ أعد فتح التطبيق";restorePassword="";onRefresh()}catch(e:Exception){msg="فشلت الاستعادة: ${e.message}"}finally{recoveryBusy=false}}}}
 val restore=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->if(uri!=null&&!recoveryBusy){recoveryBusy=true;importScope.launch{try{withContext(Dispatchers.IO){BackupManager.restore(ctx,uri,restoreDb,restoreFiles)};msg="تمت الاستعادة؛ أعد فتح التطبيق للتأكد من البيانات";onRefresh()}catch(e:Exception){msg="فشلت الاستعادة: ${e.message}"}finally{recoveryBusy=false}}}}
 Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){PremiumScreenHeader("الإعدادات والتخصيص", "المظهر والحماية والتقارير والاستيراد والنسخ الاحتياطي", Icons.Default.Tune);Text("المظهر وراحة العين",fontWeight=FontWeight.Bold);SettingSwitchRow("الوضع الليلي",s.dark){onChange(s.copy(dark=it))};Text("حجم الخط: ${(s.fontScale*100).toInt()}%");Slider(value=s.fontScale, onValueChange={onChange(s.copy(fontScale=it))},valueRange=.85f..1.35f);Text("نوع الخط");Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){listOf("sans" to "واضح", "serif" to "تقليدي", "mono" to "ثابت").forEach{(v,l)->FilterChip(selected=s.fontFamily==v,onClick={onChange(s.copy(fontFamily=v))},label={Text(l)})}};Text("لون الواجهة");Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){listOf("teal" to "فيروزي","blue" to "أزرق","olive" to "زيتوني","sand" to "رملي","purple" to "بنفسجي","rose" to "وردي","navy" to "كحلي").forEach{(v,l)->FilterChip(selected=s.accent==v,onClick={onChange(s.copy(accent=v))},label={Text(l)})}};SettingSwitchRow("عرض مضغوط للقوائم",s.compact){onChange(s.copy(compact=it))};Text("عدد الإيصالات في ورقة A4: ${s.receiptsPerPage}");Slider(value=s.receiptsPerPage.toFloat(),onValueChange={onChange(s.copy(receiptsPerPage=it.toInt().coerceIn(1,3)))},valueRange=1f..3f,steps=1);Text("هامش الطباعة: ${s.marginMm.toInt()} مم");Slider(value=s.marginMm,onValueChange={onChange(s.copy(marginMm=it))},valueRange=2f..12f);HorizontalDivider();Text("الحماية",fontWeight=FontWeight.Bold);SettingSwitchRow("قفل التطبيق تلقائيًا عند مغادرته",s.lockOnBackground){onChange(s.copy(lockOnBackground=it))};SettingSwitchRow("تفعيل البصمة / قفل الجهاز",bio){if(it&&!security.biometricAvailable(ctx)){msg="هذا الهاتف لا يوفر بصمة/قفل جهاز متوافقًا حاليًا";bio=false;security.setBiometricEnabled(false)}else{bio=it;security.setBiometricEnabled(it)}};Text("يمكنك تحديث رمز الدخول في أي وقت.",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant);OutlinedButton(onClick={changePin=true},modifier=Modifier.fillMaxWidth()){Text("تغيير رمز الدخول")};HorizontalDivider();Text("التقارير والاستيراد والتصدير",fontWeight=FontWeight.Bold);Text("ملف Q022 هو مرجع البيانات الحالي. مستورد Q023 الشامل لم يُعتمد بعد؛ لذلك أوقفنا مؤقتًا استيراد Q022 القديم حتى لا تُنقل بيانات من إصدار سابق بالخطأ. ملف 11 2026(1).xls هو نموذج إيصالات قديم وليس ملف استيراد.",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant);OutlinedButton(enabled=!q022Busy,onClick={setExternalPickerInProgress(true);importQ022.launch(arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet","application/zip"))},modifier=Modifier.fillMaxWidth()){Text(if(q022Busy)"جارٍ تجهيز استيراد Q022…" else "اختيار ملف Q022 الحالي وحفظه للمراجعة")};Button(onClick={exportExcel.launch("تصدير_كامل_بيانات_الإيجارات.xlsx")},modifier=Modifier.fillMaxWidth()){Text("تصدير جميع جداول النظام إلى Excel")};OutlinedButton(onClick={exportPdf.launch("تقرير_كامل_بيانات_الإيجارات.pdf")},modifier=Modifier.fillMaxWidth()){Text("تصدير تقرير شامل إلى PDF")};Text("تقارير PDF المتخصصة",fontWeight=FontWeight.Bold);AppField("تصفية التقرير بالفترة: YYYY أو YYYY-MM أو غير محددة (اتركه فارغًا للكل)",reportPeriod,onChange={reportPeriod=it});AppField("اسم الوارث لكشف حساب فردي (اختياري — مطابق للاسم المسجل)",reportHeirName,onChange={reportHeirName=it});listOf("units" to "كشف الوحدات", "receipts" to "تقرير الإيصالات", "ledger" to "كشف حركة الحسابات", "expenses" to "تقرير المصروفات", "collections" to "استلامات المحصّل", "heirs" to "أنصبة وتوزيعات الورثة", "financial" to "كشف الحركة المالية الموحد", "heir_statement" to "كشف الدفعات الفعلية للورثة").forEach{(key,label)->OutlinedButton(onClick={selectedPdfReport=key;exportPdf.launch("${label.replace(' ','_')}.pdf")},modifier=Modifier.fillMaxWidth()){Text(label)}};Text("يحتوي Excel وPDF على أوراق/جداول قاعدة البيانات الحالية. التصدير لا يغيّر البيانات الأصلية.",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant);OutlinedButton(onClick={importAllExcel.launch(arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet","application/zip"))},modifier=Modifier.fillMaxWidth()){Text("استيراد جميع أقسام النظام من Excel (قالب التطبيق)")};OutlinedButton(enabled=false,onClick={},modifier=Modifier.fillMaxWidth()){Text("استيراد Q023 الشامل — قيد التجهيز، غير متاح بعد")};OutlinedButton(onClick={importExcel.launch(arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))},modifier=Modifier.fillMaxWidth()){Text("استيراد وحدات من ملف Excel خارجي / كشف الوحدات")};Text("الاستيراد الشامل مخصص لملف XLSX صادر من التطبيق وبنفس أسماء الأعمدة. يضيف سجلات جديدة فقط ولا يعدّل السجلات القائمة؛ أي تعارض يوقف العملية كاملة.",fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant);Text("النسخ الاحتياطي والاسترداد",fontWeight=FontWeight.Bold);Text("للاحتفاظ بكل بياناتك، اترك خياري قاعدة البيانات والمرفقات مفعّلين معًا. النسخة الكاملة تحفظ السجلات والعقود والإيصالات والحركات المالية والمرفقات وإعدادات الواجهة. لا تتضمن رمز الدخول أو أسرار المصادقة. ملف ZIP العادي غير مشفّر؛ استخدم النسخة المشفّرة عند الحاجة إلى حماية المحتوى.",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant);OutlinedButton(enabled=!recoveryBusy,onClick={recoveryBusy=true;importScope.launch{try{recoveryReport=withContext(Dispatchers.IO){RecoveryInspector.inspect(ctx)};msg="اكتمل فحص جاهزية البيانات للاسترداد"}catch(e:Exception){msg="تعذر فحص البيانات: ${e.message}"}finally{recoveryBusy=false}}},modifier=Modifier.fillMaxWidth()){Text(if(recoveryBusy)"جارٍ فحص البيانات…" else "فحص سلامة البيانات وجاهزية الاسترداد")};recoveryReport?.let{r->Card(Modifier.fillMaxWidth()){Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(4.dp)){Text(if(r.healthy)"فحص قاعدة البيانات سليم" else "توجد ملاحظات تحتاج مراجعة",fontWeight=FontWeight.Bold,color=if(r.healthy)MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error);Text("سلامة SQLite: ${r.integrity} • مخالفات العلاقات: ${r.foreignKeyViolations}");Text("ملفات المرفقات: ${r.attachmentFiles} • الحجم: ${r.attachmentBytes/1024} كيلوبايت");Text("مرفقات داخلية مفقودة: ${r.missingManagedFiles}");Text("مراجع ملفات خارجية غير مضمونة في النسخة: ${r.externalReferences}");Text("السجلات المفحوصة: ${r.tableCounts.values.sum()}");}}};SettingSwitchRow("تضمين قاعدة البيانات",includeDb){includeDb=it};SettingSwitchRow("تضمين المرفقات",includeFiles){includeFiles=it};OutlinedButton(onClick={exportDb.launch("قاعدة_بيانات_الإيجارات.db")},modifier=Modifier.fillMaxWidth()){Text("تصدير قاعدة البيانات SQLite (بدون ملفات المرفقات)")};OutlinedButton(onClick={confirmRawImport=true},modifier=Modifier.fillMaxWidth()){Text("استيراد قاعدة بيانات SQLite")};Button(onClick={backup.launch("نسخة_احتياطية_كاملة.zip")},modifier=Modifier.fillMaxWidth()){Text("إنشاء نسخة احتياطية كاملة (ZIP)")};Button(onClick={backupPasswordDialog=true},modifier=Modifier.fillMaxWidth()){Text("إنشاء نسخة احتياطية كاملة مشفرة بكلمة مرور")};Text("عند الاستعادة الكاملة، فعّل قاعدة البيانات والمرفقات معًا. الاستعادة تستبدل البيانات الحالية بالنسخة المختارة؛ احتفظ بنسخة من الحالة الحالية أولًا.",fontWeight=FontWeight.Bold);SettingSwitchRow("استعادة قاعدة البيانات",restoreDb){restoreDb=it};SettingSwitchRow("استعادة المرفقات",restoreFiles){restoreFiles=it};OutlinedButton(onClick={restore.launch(arrayOf("application/zip","application/octet-stream","*/*"))},modifier=Modifier.fillMaxWidth()){Text("استعادة نسخة احتياطية ZIP")};OutlinedButton(onClick={restorePasswordDialog=true},modifier=Modifier.fillMaxWidth()){Text("استعادة نسخة احتياطية مشفرة")};OutlinedButton(onClick={editShares=true},modifier=Modifier.fillMaxWidth()){Text("إدارة أنصبة الورثة")};HorizontalDivider();Text("حماية السجلات والتاريخ",fontWeight=FontWeight.Bold);Text("الحذف من العقارات والمستأجرين والعقود والمستندات ومصروفات الدفتر ينقل السجل إلى السلة بدل محوه نهائيًا. الملفات الأصلية للمستندات لا تُحذف. السجلات المالية والإيصالات لا تُحذف من خلال السلة.",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant);OutlinedButton(onClick={showRecoveryRecords=true},modifier=Modifier.fillMaxWidth()){Text("سلة المحذوفات وسجل التعديلات")};HorizontalDivider();Text("الذكاء الاصطناعي والخصوصية",fontWeight=FontWeight.Bold);SettingSwitchRow("أسمح بتفعيل ميزات AI عبر الإنترنت عند الطلب فقط",s.aiConsent){onChange(s.copy(aiConsent=it))};Text("الوظائف الأساسية محلية. لا توجد أي عملية إرسال بيانات في هذه النسخة؛ الموافقة هنا تحفظ تفضيلك فقط.",fontSize=12.sp);if(msg.isNotBlank())Text(msg,color=MaterialTheme.colorScheme.primary,fontWeight=FontWeight.SemiBold)}
 if(backupPasswordDialog) AlertDialog(onDismissRequest={backupPasswordDialog=false},title={Text("حماية النسخة الاحتياطية")},text={Column{Text("أنشئ كلمة مرور لا تقل عن 8 أحرف. لن تُحفظ داخل التطبيق؛ احتفظ بها لاستعادة النسخة.");OutlinedTextField(backupPassword,{backupPassword=it},label={Text("كلمة مرور النسخة")},visualTransformation=PasswordVisualTransformation())}},confirmButton={TextButton(onClick={if(backupPassword.length>=8){backupPasswordDialog=false;encryptedBackup.launch("نسخة_إيجارات_مشفرة.rntbak")}else msg="كلمة المرور يجب ألا تقل عن 8 أحرف"}){Text("إنشاء النسخة")}},dismissButton={TextButton(onClick={backupPasswordDialog=false}){Text("إلغاء")}})
 if(restorePasswordDialog) AlertDialog(onDismissRequest={restorePasswordDialog=false},title={Text("استعادة نسخة مشفرة")},text={Column{Text("أدخل كلمة المرور التي استخدمتها عند إنشاء النسخة.");OutlinedTextField(restorePassword,{restorePassword=it},label={Text("كلمة المرور")},visualTransformation=PasswordVisualTransformation())}},confirmButton={TextButton(onClick={if(restorePassword.isNotBlank()){restorePasswordDialog=false;encryptedRestore.launch(arrayOf("application/octet-stream","application/zip","*/*"))}else msg="أدخل كلمة المرور أولًا"}){Text("اختيار النسخة")}},dismissButton={TextButton(onClick={restorePasswordDialog=false}){Text("إلغاء")}})
 if(pendingQ022Uri!=null && pendingQ022Preview!=null) { val preview=pendingQ022Preview!!; AlertDialog(onDismissRequest={if(!q022Busy){pendingQ022Uri=null;pendingQ022Preview=null}},title={Text("مراجعة ملف الإيجارات قبل الاستيراد")},text={Column(Modifier.heightIn(max=420.dp).verticalScroll(rememberScrollState())){Text("الملف: ${preview.workbookName}");Text("إجمالي السجلات التي تم التعرف عليها: ${preview.totalRows}",fontWeight=FontWeight.SemiBold);preview.counts.forEach{Text("${it.sheet}: ${it.rows} سجل")};Spacer(Modifier.height(8.dp));Text("سيحفظ التطبيق أوراق Q022 ومصادرها في سجل مراجعة غير تشغيلي، ثم ينقل فقط الوحدات التي تجتاز ضوابط المطابقة المصدرية الفريدة إلى قائمة الوحدات بحالة تحتاج اعتمادًا. ورقة مطابقة Q022 (78 مرشحًا فريدًا و8 أسماء مكررة وحالة بلا مطابقة) دليل مراجعة وليست قرار ربط نهائيًا. لن ينشئ هذا الاستيراد إيصالات مدفوعة أو تحصيلات أو قيودًا مالية أو قيمًا حالية مفترضة. أنشئ نسخة احتياطية قبل الاعتماد.");if(q022Busy){Spacer(Modifier.height(10.dp));Row(verticalAlignment=Alignment.CenterVertically){CircularProgressIndicator(Modifier.size(20.dp),strokeWidth=2.dp);Text(" جارٍ استيراد البيانات، اترك التطبيق مفتوحًا…")}}}},confirmButton={TextButton(enabled=!q022Busy,onClick={val selectedUri=pendingQ022Uri;if(selectedUri!=null){q022Busy=true;importScope.launch{var completedSummary:String?=null;try{val result=withContext(Dispatchers.IO){val staged=ReviewedRentalsWorkbookImporter.stage(ctx.contentResolver,selectedUri,db.writableDatabase);val migrated=db.migrateUniquelyMatchedLegacyUnitsToReview();staged to migrated};val staged=result.first;val migrated=result.second;msg="اكتمل الاستيراد: ${migrated.inserted} وحدة أضيفت، ${migrated.alreadyMigrated} موجودة سابقًا، ${migrated.blocked} تحتاج مراجعة. حُفظ ${staged.inserted} سجلًا مصدريًا جديدًا.";completedSummary=msg;onRefresh()}catch(e:Exception){msg="تعذر إكمال الاستيراد: ${e.message}"}finally{q022Busy=false;pendingQ022Uri=null;pendingQ022Preview=null};if(completedSummary!=null)onImportComplete(completedSummary!!)}}}){Text(if(q022Busy)"جارٍ الاستيراد…" else "استيراد الآن")}},dismissButton={TextButton(enabled=!q022Busy,onClick={pendingQ022Uri=null;pendingQ022Preview=null}){Text("إلغاء")}}) }
 if(pendingWorkbookUri!=null && pendingWorkbookPreview!=null) { val preview=pendingWorkbookPreview!!; AlertDialog(onDismissRequest={pendingWorkbookUri=null;pendingWorkbookPreview=null},title={Text("معاينة استيراد Excel الشامل")},text={Column(Modifier.heightIn(max=420.dp).verticalScroll(rememberScrollState())){Text("عدد السجلات المقروءة: ${preview.totalRows}");preview.tables.forEach{(table,count)->Text("$table: $count سجل")};if(preview.ignoredSheets.isNotEmpty())Text("أوراق غير مستوردة: ${preview.ignoredSheets.joinToString()}");Spacer(Modifier.height(8.dp));Text("سيتم إضافة السجلات الجديدة فقط مع الحفاظ على المعرّفات والعلاقات. لن يتم تعديل أو حذف أي سجل موجود. إذا ظهر تعارض في رقم أو قيد فريد أو علاقة، ستُلغى العملية كلها دون اعتماد أي جزء. أنشئ نسخة احتياطية قبل المتابعة.")}},confirmButton={TextButton(enabled=!recoveryBusy,onClick={val selectedUri=pendingWorkbookUri;if(selectedUri!=null){recoveryBusy=true;importScope.launch{try{val result=withContext(Dispatchers.IO){WorkbookImporter.importAppend(ctx.contentResolver,selectedUri,db.writableDatabase)};msg="تمت معالجة ${result.totalRows} سجلًا من ${result.tables.size} جدول؛ أضيفت السجلات الجديدة وتُركت السجلات المطابقة كما هي.";onRefresh()}catch(e:Exception){msg="لم يعتمد الاستيراد: ${e.message}"}finally{recoveryBusy=false;pendingWorkbookUri=null;pendingWorkbookPreview=null}}}}){Text(if(recoveryBusy)"جارٍ الاعتماد…" else "اعتماد الإضافة")}},dismissButton={TextButton(onClick={pendingWorkbookUri=null;pendingWorkbookPreview=null}){Text("إلغاء")}}) }
 if(pendingImport!=null) { val incoming=pendingImport!!; val existingCodes=db.units().map{it.code}.filter{it.isNotBlank()}.toSet(); val duplicates=incoming.count{it.code.isNotBlank()&&it.code in existingCodes}; val repeatedInFile=incoming.filter{it.code.isNotBlank()}.groupingBy{it.code}.eachCount().values.sumOf{(it-1).coerceAtLeast(0)}; AlertDialog(onDismissRequest={pendingImport=null},title={Text("مراجعة استيراد Excel")},text={Text("عدد السجلات المقروءة: ${incoming.size}\nسجلات لها كود موجود مسبقًا: $duplicates\nأكواد مكررة داخل الملف نفسه: $repeatedInFile\n${if(repeatedInFile>0)"لن نسمح بالاستيراد قبل إزالة تكرار الأكواد داخل الملف حتى لا يستبدل سجلٌ سجلًا آخر دون قصد." else "السجلات المتطابقة بالكود ستحدّث بيانات الوحدة الحالية بعد موافقتك مع تسجيل التعديل في سجل المراجعة. الاستيراد أصبح عملية واحدة: إذا فشل أي سجل فلن يُعتمد أي جزء من الملف."}\nهل تعتمد الاستيراد؟")},confirmButton={TextButton(enabled=repeatedInFile==0,onClick={try{db.importUnitsAtomically(incoming);msg="تم استيراد ${incoming.size} سجل وحدة بعد المراجعة في عملية واحدة";onRefresh()}catch(e:Exception){msg="فشل الاستيراد: ${e.message}"};pendingImport=null}){Text(if(repeatedInFile==0)"اعتماد الاستيراد" else "عالج التكرارات أولًا")}},dismissButton={TextButton(onClick={pendingImport=null}){Text("إلغاء")}}) }
 if(confirmRawImport) AlertDialog(onDismissRequest={confirmRawImport=false},title={Text("تأكيد استبدال قاعدة البيانات")},text={Text("سيؤدي الاستيراد إلى استبدال قاعدة البيانات فقط. ملف SQLite المنفرد لا يتضمن المرفقات أو إعدادات الواجهة، وقد لا يتطابق مع ملفات التطبيق الحالية. للاستعادة الكاملة استخدم نسخة ZIP أو النسخة المشفرة التي تضم قاعدة البيانات والمرفقات. أنشئ نسخة احتياطية أولًا. هل تريد المتابعة؟")},confirmButton={TextButton(onClick={confirmRawImport=false;importDb.launch(arrayOf("application/vnd.sqlite3","application/octet-stream","*/*"))}){Text("اختيار ملف والمتابعة")}},dismissButton={TextButton(onClick={confirmRawImport=false}){Text("إلغاء")}})
 if(showRecoveryRecords) RecoveryRecordsDialog(db,onClose={showRecoveryRecords=false},onMessage={msg=it},onRestored=onRefresh)
 if(changePin) ChangePinDialog(security,onClose={changePin=false},onSaved={msg="تم تحديث رمز الدخول";changePin=false})
 if(editShares) HeirSharesDialog(db,onClose={editShares=false},onSaved={msg="تم حفظ الأنصبة وتسجيل التعديل في السجل التاريخي";editShares=false})
}
@Composable
private fun ChangePinDialog(sec: AppSecurity, onClose: () -> Unit, onSaved: () -> Unit) {
    var old by remember { mutableStateOf("") }
    var fresh by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("تغيير رمز الدخول") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(old, { old = it }, label = { Text("الرمز الحالي") }, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword))
                OutlinedTextField(fresh, { fresh = it }, label = { Text("الرمز الجديد") }, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword))
                OutlinedTextField(confirm, { confirm = it }, label = { Text("تأكيد الرمز الجديد") }, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword))
                if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                when {
                    !sec.verifyPin(old) -> error = "الرمز الحالي غير صحيح"
                    fresh.length < 4 -> error = "الرمز الجديد يجب ألا يقل عن 4 أرقام"
                    fresh != confirm -> error = "تأكيد الرمز غير مطابق"
                    else -> { sec.setPin(fresh); onSaved() }
                }
            }) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("إلغاء") } }
    )
}
@Composable
private fun HeirSharesDialog(db: RentalsDb, onClose: () -> Unit, onSaved: () -> Unit) {
    val heirs = remember { db.heirs() }
    val values = remember { androidx.compose.runtime.mutableStateMapOf<Long, String>() }
    var error by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { heirs.forEach { (id, _, share) -> values[id] = String.format(Locale.US, "%.4f", share * 100.0) } }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("أنصبة الورثة") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("النسب الافتراضية: الذكر 2/7 والأنثى 1/7. يمكنك تعديلها يدويًا؛ يجب أن يكون المجموع 100٪.", fontSize = 12.sp)
                heirs.forEach { (id, name, _) ->
                    OutlinedTextField(values[id] ?: "", { values[id] = it }, label = { Text("نصيب $name (%)") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                }
                Text("المجموع: ${heirs.sumOf { values[it.first]?.toDoubleOrNull() ?: 0.0 }}٪")
                if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val map = heirs.associate { it.first to (values[it.first]?.toDoubleOrNull() ?: 0.0) }
                try { db.updateHeirShares(map); onSaved() } catch (e: Exception) { error = e.message ?: "تعذر حفظ الأنصبة" }
            }) { Text("حفظ الأنصبة") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("إلغاء") } }
    )
}

