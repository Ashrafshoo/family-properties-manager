from pathlib import Path

root = Path(__file__).resolve().parents[1]
backup = (root / "app/src/main/java/com/example/rentals/backup/BackupManager.kt").read_text()
build = (root / "app/build.gradle.kts").read_text()

assert 'validateDatabase(liveDb)' in backup
assert 'verifyDirectoryMirror(candidateAttachments, liveAttachments)' in backup
assert 'private fun verifyDirectoryMirror' in backup
assert 'private fun sha256(file: File)' in backup
assert 'val rollbackFailures = mutableListOf<String>()' in backup
assert 'preserveRollbackFiles = true' in backup
assert 'if (!preserveRollbackFiles)' in backup
assert 'versionCode = 64' in build
assert 'versionName = "0.4.39-dev"' in build
print("PASS: installed database and attachments are verified; independent rollback attempts preserve recovery material on failure; version is incremented.")
