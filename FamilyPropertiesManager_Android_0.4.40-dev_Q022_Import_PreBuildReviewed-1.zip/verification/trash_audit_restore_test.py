from pathlib import Path

root = Path(__file__).resolve().parents[1]
db = (root / "app/src/main/java/com/example/rentals/data/RentalsDb.kt").read_text()
settings = (root / "app/src/main/java/com/example/rentals/features/settings/SettingsScreen.kt").read_text()
dialog = (root / "app/src/main/java/com/example/rentals/features/settings/RecoveryRecordsDialog.kt").read_text()
build = (root / "app/build.gradle.kts").read_text()

checks = {
    "SQLite schema migration increments to 16": "SQLiteOpenHelper(context, \"rentals_local.db\", null, 16)" in db and "if (oldVersion < 16) createRecoveryTables(db)" in db,
    "trash bin stores full row snapshot": "snapshot_json TEXT NOT NULL" in db and "SELECT * FROM $table WHERE id=?" in db,
    "only explicit safe tables may enter trash": '"properties","tenants","leases","attachments","personal_rent_expenses"' in db,
    "delete and snapshot are one transaction": "db.beginTransaction()" in db and "db.setTransactionSuccessful()" in db and "db.endTransaction()" in db,
    "property links are protected": "لا يمكن حذف عقار مرتبط بوحدات" in db,
    "tenant links are protected": "لا يمكن حذف مستأجر مرتبط بوحدة أو عقد" in db,
    "attachments physical files are not removed": "الملف الأصلي لا يُحذف" in db,
    "restore preserves original id": 'values.containsKey("id") && values.getAsString("id")==recordId' in db,
    "restore failure keeps trash row": "db.insertOrThrow(table,null,values)" in db and 'db.delete("trash_bin"' in db,
    "audit log records delete and restore": "'active', 'trash'" in db and "'trash', 'restored'" in db,
    "audit history can be filtered": "fun auditHistory(recordType:String?=null, recordId:String?=null" in db,
    "UI exposes trash and audit history": "سلة المحذوفات وسجل التعديلات" in settings and "سجل التعديلات" in dialog,
    "UI offers restore action": "db.restoreFromTrash(entry.id)" in dialog and "onRestored()" in dialog,
    "version incremented": 'versionCode = 64' in build and 'versionName = "0.4.39-dev"' in build,
}
for label, ok in checks.items():
    print(("PASS" if ok else "FAIL") + ": " + label)
assert all(checks.values())
